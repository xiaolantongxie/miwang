! function() {
    var b, d, n, t, r, A = ["zh_CN", "en_US"],
        e = "en_US",
        a = /(msie\s|trident.*rv:)([\w.]+)/.test(navigator.userAgent.toLowerCase()),
        o = (n = [/&quot;/g, /&lt;/g, /&gt;/g, /&amp;/g], function(e) {
            return String(e).replace(n[0], '"').replace(n[1], "<").replace(n[2], ">").replace(n[3], "&")
        }),
        i = (t = [/&/g, /</g, />/g, /"/g], function(e) {
            return String(e).replace(t[0], "&amp;").replace(t[1], "&lt;").replace(t[2], "&gt;").replace(t[3], "&quot;")
        }),
        l = (r = [/&lt;/g, /&gt;/g, /&amp;/g], function(e) {
            return String(e).replace(r[0], "<").replace(r[1], ">").replace(r[2], "&")
        });

    function _init() {
        if (window.LANG || (window.LANG = {}), window.LanguageExpand && "object" == typeof window.LanguageExpand) {
            var e = window.LanguageExpand[window.language];
            if (e && "object" == typeof e)
                for (var n in e) e.hasOwnProperty(n) && (window.LANG[n] = e[n]);
            delete window.LanguageExpand
        }
    }

    function _setLang() {
        if (document.body) {
            for (var e = document.body.className, n = 0, t = A.length; n < t; n++) e = e.replace(A[n], "");
            e += " " + window.language, document.body.className = e
        }
        var r = document.getElementsByTagName("*"),
            a = ["html", "value", "title", "alt"],
            o = [];
        for (n = 0, t = r.length; n < t; n++) o[n] = r[n];
        for (n = 0, t = o.length; n < t; n++)
            for (var i = o[n], l = 0, g = a.length; l < g; l++) {
                var u = a[l],
                    c = "_" + u,
                    d = c + "FormatArgs",
                    w = 0,
                    s = null,
                    f = null,
                    h = null,
                    p = null;
                if (i.getAttribute(c)) {
                    if (i.getAttribute(d) && null == (f = b[i.getAttribute(d)]) && (p = document.getElementById(i.getAttribute(d))) && 0 < p.childNodes.length) {
                        f = [];
                        for (var m = w = 0, v = p.childNodes.length; m < v; m++)(s = p.childNodes[m]) && s.tagName && (f[w] = s.innerHTML, w++)
                    }
                    h = null != f ? "[object Array]" === Object.prototype.toString.apply(f) ? htmltr.apply(window, [i.getAttribute(c)].concat(f)) : htmltr(i.getAttribute(c), f) : htmltr(i.getAttribute(c)), "html" === u ? i.innerHTML = h : i.setAttribute(u, h)
                }
            }
        var L = document.getElementById("titleInnerHTML");
        L && (document.title = tr(L.innerHTML))
    }

    function _request(e) {
        if (!d) {
            for (var n = window.location.search.substr(1), t = {}, r = 0, a = n.length; r < a;) {
                var o, i, l, g, u = n.indexOf("&", r);
                if (-1 !== u ? (g = n.substr(r, u - r), r = u + "&".length) : (g = n.substr(r), r = n.length), -1 !== (l = g.indexOf("="))) {
                    o = g.substr(0, l), i = g.substr(l + "=".length);
                    try {
                        t[o.toLowerCase()] = decodeURIComponent(i)
                    } catch (c) {
                        t[o.toLowerCase()] = i
                    }
                }
            }
            d = t
        }
        return e ? d[String(e).toLowerCase()] : d
    }

    function _getCookie(e) {
        for (var n = e + "=", t = n.length, r = document.cookie.length, a = "", o = 0; o < r;) {
            var i = o + t;
            if (document.cookie.substring(o, i) === n) {
                var l = document.cookie.indexOf(";", i); - 1 === l && (l = r), a = unescape(document.cookie.substring(i, l))
            }
            if (0 === (o = document.cookie.indexOf(" ", o) + 1)) break
        }
        return a
    }

    function _setCookie(e, n) {
        var t = arguments,
            r = arguments.length,
            a = 2 < r ? t[2] : null,
            o = 3 < r ? t[3] : "/",
            i = 4 < r ? t[4] : null,
            l = 5 < r && t[5];
        document.cookie = e + "=" + escape(n) + (null === a ? "" : "; expires=" + a.toGMTString()) + (null === o ? "" : "; path=" + o) + (null === i ? "" : "; domain=" + i) + (!0 === l ? "; secure" : "")
    }
    if (window.tr = function(e) {
            if (!e) return e;
            _init();
            var n = window.LANG[e];
            if (null == n && 16 < e.length && (n = window.LANG[e.substr(0, 8) + "+" + e.substr(e.length - 8)]), null == n && (n = e), n = n.replace(/\{#[\d]+\}/g, ""), 1 < arguments.length) {
                var t = Array.prototype.slice.call(arguments, 1);
                return o(n.replace(/\{(\d+)\}/g, function(e, n) {
                    return null == t[n] ? "" : t[n]
                }))
            }
            return o(n)
        }, window.htmltr = function(e) {
            _init();
            var n = i(e),
                t = window.LANG[n];
            if (null == t && 16 < n.length && (t = window.LANG[n.substr(0, 8) + "+" + n.substr(n.length - 8)]), null == t && (t = e), t = t.replace(/\{#[\d]+\}/g, ""), 1 < arguments.length) {
                var r = Array.prototype.slice.call(arguments, 1);
                return l(t.replace(/\{(\d+)\}/g, function(e, n) {
                    return null == r[n] ? "" : r[n]
                }))
            }
            return l(t)
        }, window.format = function(e) {
            if (1 < arguments.length) {
                var t = Array.prototype.slice.call(arguments, 1);
                return e.replace(/\{(\d+)\}/g, function(e, n) {
                    return null == t[n] ? "" : t[n]
                })
            }
            return e
        }, window.setLang = function(e) {
            b = e || {}, _getCookie("language") && !window.LANG ? window.attachEvent ? window.attachEvent("onload", _setLang) : window.addEventListener("load", _setLang, !1) : _setLang()
        }, window.toLang = function(e) {
            if (window.LANG_RELOAD) _setCookie("language", e, new Date(2999, 1, 1), "/", null, !0), window.location.reload();
            else {
                var n = window.location.pathname;
                if (-1 !== n.indexOf("login_token.csp") && (n = "/por/login_psw.csp"), 1 < window.location.search.length) {
                    var t = _request(),
                        r = [];
                    for (var a in t) t.hasOwnProperty(a) && "language" !== a && r.push(a + "=" + encodeURIComponent(t[a]));
                    r.push("language=" + e), window.location.href = n + "?" + r.join("&")
                } else window.location.href = n + "?language=" + e
            }
        }, !window.DISABLE_LANGUAGE) {
        var g = _request("language");
        if (g || (g = _getCookie("language")), !g && a) {
            var u = null;
            try {
                u = new ActiveXObject("CSClientManagerPrj.CSClientManager.1")
            } catch (h) {
                u = null
            }
            if (u) try {
                var c = String(u.doQueryService("QUERY LANG"));
                "" !== c && (!(c = c.deSerialize()).argument || "zh_CN" !== c.argument && "en_US" !== c.argument || (g = c.argument))
            } catch (h) {
                g = null
            }
            u = null
        }
        if (!g) switch (g = String(window.navigator.language || window.navigator.systemLanguage || window.navigator.userLanguage || window.navigator.browserLanguage).toLowerCase()) {
            case "zh-cn":
            case "zh":
                g = "zh_CN";
                break;
            case "":
                g = window.LANG_VERSION && window.LANG_VERSION.isInternational ? "en_US" : "zh_CN";
                break;
            default:
                g = e
        }
        for (var w = e, s = 0, f = A.length; s < f; s++)
            if (A[s] === g) {
                w = A[s];
                break
            }
        _setCookie("language", window.language = w, new Date(2999, 1, 1), "/", null, !0)
    }
}();