define(["common/index"], function(n) {
    "use strict";
    var t, e, o = {};
    SFLOG;
    return o.getVModelConfig = function() {
        return {
            $id: "common_message",
            btnText: "确定",
            loading: !1,
            toggle: !1,
            title: "",
            subtitle: "",
            closeBtn: !0,
            $onRendered: function(n) {
                var o = n || {};
                t.toggle || (t.toggle = !is.bool(o.isDialog) || o.isDialog, t.closeBtn = !is.bool(o.closeBtn) || o.closeBtn, t.btnText = o.btnText || tr("确定"), t.title = o.title || tr("错误提示"), t.subtitle = o.subtitle || tr("错误提示"), t.loading = o.loading || !1, e = o.clickAction || function() {}, n.fireEvent && t.$fire("all!onHideLoading", !0))
            },
            $onSessionEvent: function(n) {
                "logout" === n && (t.toggle = !1)
            },
            onSubmit: function() {
                var n;
                t.loading = !0, (n = e(t)) && is.fn(n.then) && n.then(function() {
                    t.toggle = !1, t.loading = !1
                })
            },
            onDialogClose: function() {
                t.loading = !1
            },
            $onBeforeUnload: function() {}
        }
    }, t = o.vmodel = avalon.define(o.getVModelConfig()), o
});