define(["common/index"], function(t) {
    "use strict";
    var l, d, c, s, a, f, m, b, h, o, r, v, e = {},
        n = t.utils,
        u = SFConfig,
        i = n.isClient,
        w = SFLOG,
        D = "♂♀☺♪♫◙♂♀",
        g = function() {},
        L = !1,
        S = "ui:password",
        A = tr("域单点登录中"),
        P = !1,
        C = SF.setting.getGlobal(KEY_GLOBAL_LANG, ""),
        p = !1;

    function init() {
        var n, t, s, o, r, e, u, i, g;
        f = SF.vpnInfo.createInstance(), r = SF.setting.getGlobal(KEY_GLOBAL_INIT_GET_INIT_CONFIG_DATA, null), s = SF.setting.getGlobal(KEY_GLOBAL_IS_USER_LOGOUT, !1), w.assert(null !== r, "loginAuthData is null"), n = f.getLoginInfo(), o = f.getTempLoginInfo(), e = r.enableSavePwd, i = r.enableAutoLogin, v = 1 === r.anonymous && 1 === r.denyNormalUser, is.WebClient && v && !s ? l.isAnonymousLogin = !0 : (P = 1 === (u = n).savePwd, u.userName = u.userName || "", g = n.hasOwnProperty("password") && is.set(n.password), t = g && (!l.isFirstAuth && "auth/_key" === a || l.isFirstAuth || !l.isFirstAuth && o.userName && u.userName === o.userName), l.enableSavePwd = 1 === e && (l.isFirstAuth || !l.isFirstAuth && !o.autoLogin || !l.isFirstAuth && "auth/_key" === a), l.enableAutoLogin = 1 === i && (l.isFirstAuth || !l.isFirstAuth && !o.autoLogin && 0 !== o.autoLogin || !l.isFirstAuth && "auth/_key" === a)), l.resetPassWord = r.resetPassWord, l.isDialog || (l.softKey = r.softKey), SF.auth.getLoginConfig({
            onGetPswConfig: function(n) {
                l.enableRandCode = 1 === n.enableRandCode, l.enableRandCode && l.initImage(), l.loading = !1, changeBtnText(l.isDisabled = !1), m && (L = !0)
            },
            onHaveMidAttack: function(n) {
                l.errorData = !0 === n ? tr("服务器启动防中间人攻击检测，不允许使用IE代理登陆") : tr("你访问的SSL VPN正遭受中间人攻击，将不能使用用户名/密码认证！")
            },
            onSaveUserInfo: function(n) {
                saveUserInfo(n)
            },
            onAutoLogin: function(n) {
                saveUserInfo(n), l.autoLogin = !0, login()
            },
            onInitLoginInfo: function() {
                var n, o, e, i, a = "";
                (function getDomainConfig() {
                    return w.info(S, "start check domainSSOEnable"), new Promise(function(n, o) {
                        d.domainSSOEnable ? (l.isPrivacy && (w.info(S, "is web, domainSSOEnable exist"), n()), !l.isPrivacy && is.Win() && (w.info(S, "is Windows EC,domainSSOEnable exist"), n())) : (w.info(S, "web did not set privacy or is not Windows EC"), o())
                    })
                })().then(function checkDomain() {
                    return w.info(S, "start check inDomain"), new Promise(function(n, o) {
                        SFAPI.checkDomain({
                            success: function(n) {
                                1 !== n.data.inDomain ? o() : !SFCommon.getCookie("privacy") && l.isPrivacy ? (w.info(S, "is web, domainSSOEnable exist, but not allow Privacy Policy"), l.errorData = tr("请勾选《免责声明》后再刷新页面登录"), o()) : (w.info(S, "check inDomain success, inDomain is " + n.data.inDomain), l.isDisabled = !0, l.loading = !0, l.buttonText = A, login({
                                    loginDomain: !0
                                }))
                            },
                            error: function() {
                                w.info(S, "check inDomain failed"), o()
                            }
                        })
                    })
                })["catch"](function() {
                    w.info(S, "login domian failed, now AnonymousLogin or auoLogin"),
                        function otherLogin() {
                            l.isAnonymousLogin && !is.System().isMobile ? login({
                                username: "Anonymous"
                            }) : (l.username = t ? u.userName : "", l.password = "", o = r.enableSavePwd, n = r.enableAutoLogin, i = !!u.savePwd, e = !!u.autoLogin, o && (i && t && (w.info(S, "enable save pwd"), c = u.password || "", a = D, l.password = a), l.savePwd = i && g, b = l.username, h = l.password), n && (w.assert(o, "enableSavePwd must be true when enableAutoLogin is true"), w.info(S, "autoLogin start"), l.autoLogin = e && g, e && !s && t && login({
                                auto: !0
                            })))
                        }()
                })
            },
            error: function(n) {
                l.loading = !1, l.isDisabled = !1, w.error(S, "init failed", "model init failed. %s", n.msg)
            }
        })
    }

    function saveUserInfo(n) {
        var o;
        c = n.password, o = D, l.password = o, l.savePwd = !0
    }

    function loginAuth(i) {
        var e, a = d.domainSSOUrl;

        function auth() {
            SF.auth.authPsw({
                isReset: u.FIRST_LOGIN,
                userName: l.username,
                password: e,
                randCode: l.randCode,
                preventOnError: !0,
                success: function(n) {
                    var o;
                    SFCommon.isWeb() || ((o = f.getTempLoginInfo()).userName = l.username, o.password = e, l.$isClient && l.enableAutoLogin && (o.autoLogin = l.autoLogin ? 1 : 0), l.$isClient && l.enableSavePwd && (o.savePwd = l.savePwd ? 1 : 0), is.set(o.savePwd) && (o.autoLogin = 1 === o.savePwd ? o.autoLogin : 0), is.set(o.autoLogin) && (o.savePwd = 1 === o.autoLogin ? 1 : o.savePwd), w.info(S, "loginPsw() success"), f.saveTempLoginInfo(o)), t.auth.codeHandler(n, {
                        mapKey: s,
                        onBefore: function() {
                            l.isDisabled = !0, l.loading = !1, changeBtnText(!(avalon.vmodels.login.loginLoading = !0))
                        },
                        success: function(n) {
                            l.toggle = !1, i && i.callback && i.callback(!0)
                        },
                        error: function() {
                            l.enableRandCode && l.initImage(), i && i.callback && i.callback(!1), l.loading = !1, l.isDisabled = !1
                        }
                    })
                },
                error: function(n) {
                    var o = !1,
                        e = n.code === ERROR_NETWORK_REQUEST_FAILED;
                    l.loading = !1, l.isDisabled = !1, e || !l.enableRandCode && n.code !== ERRCODE_EAUTH_RANDCODE_ON && n.code !== ERRCODE_EAUTH_RAND_CODE || (l.maxEnableRandCode = !0, l.initImage(), o = !0), i && "Anonymous" === i.username ? (l.username = "", l.errorData = n.msg || tr("匿名登录失败，请确定是否开启匿名登录"), w.info(S, "anonymous login failed")) : (l.errorData = n.msg, o || e || l.initImage()), changeBtnText(!1)
                }
            })
        }
        i && i.loginDomain && !p ? function loginDomain() {
            return new Promise(function(o, n) {
                SFAPI.loginDomain({
                    domainSSOUrl: a,
                    success: function(n) {
                        t.auth.codeHandler(n, {
                            mapKey: s,
                            success: function() {
                                o()
                            },
                            error: function() {
                                w.info(S, "loginDomain failed"), changeBtnText(!1), l.loading = !1, l.isDisabled = !1, l.errorData = tr("域单点登录失败")
                            }
                        })
                    },
                    error: function(n) {
                        w.info(S, "loginDomain failed"), changeBtnText(!1), l.loading = !1, l.isDisabled = !1, l.errorData = tr("域单点登录失败")
                    }
                })
            })
        }().then(function() {
            w.info(S, "loginDomain success"), l.loading = !1, changeBtnText(!(l.isDisabled = !0))
        })["catch"](function() {
            p = !0
        }) : (e = l.password === D ? c : l.password, SFConfig.isExistEC ? new Promise(function(n, o) {
            n()
        }).then(function() {
            return function checkReLogin() {
                return new Promise(function(e, n) {
                    SFAPI.checkReLogin({
                        preventOnError: !0,
                        success: function(n) {
                            var o = n.code;
                            1 !== o && 2 !== o && 3 !== o && 4 !== o ? (w.info(S, "not user login, status is " + o), e()) : (w.info(S, " other user login, status is " + o), t.loader.renderPage({
                                name: PORTAL_MAP["other/_relogin"]
                            }), resetData())
                        },
                        error: function(n) {
                            var o = SFCommon.formatString("api init fail, code:{0}, msg:{1}", n.code, n.msg);
                            w.debug(S, o), e()
                        }
                    })
                })
            }()
        }).then(function() {
            return function initECAgent() {
                return new Promise(function(n, o) {
                    SFAPI.initECAgent({
                        success: function() {
                            n()
                        },
                        error: function() {
                            w.info(S, "init ecagent error before login"), n()
                        }
                    })
                })
            }()
        }).then(function(n) {
            auth()
        }) : auth())
    }

    function changeBtnText(n) {
        l.buttonText = n ? r : o
    }

    function login(n) {
        if (!SFCommon.isWeb() || "1" === SFCommon.getCookie("privacy") && l.setPrivacy) {
            var o, e = n && "Anonymous" === n.username,
                i = n && n.loginDomain,
                a = r;
            if (l.errorData = "", e && (l.isAnonymousLogin = !0, l.username = n.username, l.password = "", a = tr("匿名登录中")), l.username = l.username.trim(), "" === l.username && !i) return l.errorData = tr("请输入用户名,否则无法登录"), changeBtnText(!1), l.loading = !1, void(l.isDisabled = !1);
            if (l.enableRandCode && !e && !i && (/([\u4E00-\u9FA5])+/.test(l.randCode) || 4 !== l.randCode.length)) return l.errorData = tr("请输入正确的图形验证码"), changeBtnText(!1), l.loading = !1, void(l.isDisabled = !1);
            l.buttonText = i ? A : a, l.loading = !0, l.isDisabled = !0, o = "", o += e ? "anonymous " : "un/pwd ", n && n.auto ? o += "auto login" : o += "manual login", w.info(S, o), SF.init.setLang({
                lang: C,
                switchLang: !0,
                success: function() {
                    w.debug(S, "setLang is success")
                },
                error: function(n) {
                    w.debug(S, "setLang is fail, error message is " + JSON.stringify(n))
                }
            }), L ? loginAuth(n) : (l.loading = !0, l.isDisabled = !0, g = function() {
                loginAuth(n), g = function() {}
            })
        } else l.errorData = tr("请先阅读并同意《免责声明》")
    }

    function initWatch() {
        l.$watch("initState", function(n) {
            ! function onInitStateChange(n) {
                "finished" === n && (L = !0, w.debug(S, "onInitStateChange, state:" + n), g())
            }(n)
        })
    }

    function resetData() {
        l.username = "", l.password = "", l.randCode = "", l.errorData = "", l.savePwd = !1, l.autoLogin = !1, l.loading = !1, l.isDisabled = !1, changeBtnText(l.autoFocus = !1)
    }
    return e.getVModelConfig = function() {
        return {
            $id: "password",
            username: "",
            password: "",
            randCode: "",
            buttonText: "",
            image: "",
            errorData: "",
            loading: !0,
            isDisabled: !1,
            autoFocus: !1,
            toggle: !1,
            enableSavePwd: !1,
            savePwd: !1,
            resetPassWord: !1,
            softKey: !1,
            enableAutoLogin: !1,
            autoLogin: !1,
            enableRandCode: !1,
            maxEnableRandCode: !1,
            setPrivacy: !1,
            isDialog: !1,
            isFirstAuth: !0,
            isAnonymousLogin: !1,
            $isClient: i,
            isMinHeight: !1,
            $isMobile: head.mobile,
            isPrivacy: !1,
            otherPrivacy: "zh_CN" === C || "" === C ? [{
                label: tr("《免责声明》"),
                moduleName: PORTAL_MAP["privacy/zh_CN"]
            }] : [{
                label: tr("《免责声明》"),
                moduleName: PORTAL_MAP["privacy/en_US"]
            }],
            initImage: function(n) {
                l.isDisabled && l.loading && n || SF.auth.getRandCode({
                    success: function(n) {
                        l.image = n.data.url
                    },
                    error: function() {
                        l.initImage(), w.debug(S, "get rand code error")
                    }
                })
            },
            fire: function(n, o, e) {
                t.trigger.fire(l, n, o, e)
            },
            $onEnter: function() {
                SF.setting.getGlobal(KEY_GLOBAL_DISABLED_AUTO_RELOGIN, "")
            },
            $onRendered: function(n) {
                resetData(), C = SF.setting.getGlobal(KEY_GLOBAL_LANG, ""), l.isPrivacy = SFCommon.isWeb() && !n.isDialog, initWatch(), L = !!L || !!n.isInitFinished || !!n.isDialog, t.i18n.change(e.vmodel, C, function() {
                    o = tr("登录"), r = tr("登录中"), l.otherPrivacy[0].label = tr("《免责声明》"), l.buttonText = o, l.autoFocus = !0, n.isDialog && (l.isDialog = n.isDialog), l.isAnonymousLogin = !!n.isAnonymousLogin, d = SF.setting.getGlobal(KEY_GLOBAL_INIT_GET_INIT_CONFIG_DATA, {}), w.debug(S, "current first auth status is " + n.isFirstAuth), l.isFirstAuth = !is.bool(n.isFirstAuth) || n.isFirstAuth, s = n.mapKey, a = n.lastAuth, init(), l.isMinHeight = is.empty(l.errorData), n.isDialog || (initSoftboard("loginPwd"), addKeyboardEvent()), l.toggle = !!n.isDialog, l.setPrivacy = "1" === SFCommon.getCookie("privacy")
                })
            },
            $onBeforeUnload: function() {},
            login: function(n) {
                login(n)
            },
            resetPwd: function() {
                var n = "/com/forgetPassword.html";
                i && (n = location.origin + n + "?language=" + C), SFCommon.openWindow({
                    url: n,
                    target: "_blank"
                })
            },
            resetData: resetData,
            changeBtnText: changeBtnText,
            $onSessionEvent: function(n) {
                "vpn_openresource" === n && (l.toggle = !1)
            },
            showKeyboard: function(n) {
                d && 0 <= d.softKey && !l.loading && !l.isDisabled && (l.enableSavePwd && P && (l.password = "", P = !1), window.g_soft_kb = d.softKey, 0 < window.g_soft_kb && (n || (n = window.event), is.IE() <= 8 ? (window.event || n).cancelBubble = !0 : n.stopPropagation(), showkeyboard()))
            },
            onDialogClose: function() {
                resetData()
            },
            onSavePwdChange: function() {
                l.savePwd || (l.autoLogin = !1)
            },
            onSetPrivacy: function() {
                SFCommon.getCookie("privacy") || SFCommon.setCookie("privacy", "1", new Date(2999, 1, 1))
            },
            onAutoLoginChange: function() {
                l.autoLogin && (l.savePwd = !0)
            },
            filterInputInfo: function(n) {
                var o, e = l.password;
                if (l.enableSavePwd && P && (l.username !== b || l.password !== h)) {
                    for (o = 0; o < D.length; o++) 0 <= e.indexOf(D[o]) && (e = e.replace(D[o], ""));
                    l.password = e, P = !1
                }
            },
            openPrivacy: function() {
                var n = location.href.split("/"),
                    o = n.splice(0, n.length - 1).join("/"),
                    e = o + "/privacy_CN",
                    i = o + "/privacy_EN";
                l.isPrivacy && ("zh_CN" === C || "" === C ? SFCommon.openWindow({
                    url: e
                }) : SFCommon.openWindow({
                    url: i
                }))
            }
        }
    }, e._loaderTplPretreatment = function(n, o) {
        var e;
        return o.isDialog ? (m = o.isDialog, e = '<div ms-widget="dialog" data-dialog-ctr="password" data-dialog-ctr-toggle="toggle" data-dialog-on-close="onDialogClose">' + n + "</div>") : e = n, e
    }, l = e.vmodel = avalon.define(e.getVModelConfig()), e
});