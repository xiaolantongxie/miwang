define("views/login/login", ["common/index"], function(l) {
    "use strict";
    var e, g, r, d, c, o, a, t, s = {},
        i = l.utils,
        u = i.isClient,
        n = i.isWinClient,
        m = is.Win() || n,
        h = i.isLinuxClient,
        f = {
            loadPlugin: !1,
            initSDK: !1
        },
        L = SFLOG,
        _ = "ui:login",
        w = {},
        v = !1,
        A = document.getElementById("loadingDialog"),
        N = SFCommon,
        p = new Function,
        T = !1,
        P = {},
        b = "欢迎使用EasyConnect，让您的系统接入更安全，体验更好！",
        E = "下载USB-KEY驱动",
        S = SFConfig.PAGE_SIZE;

    function getLoginTypeList() {
        return [{
            label: tr("USB-KEY登录"),
            _label: "USB-KEY登录",
            moduleName: PORTAL_MAP["auth/_key"],
            clsName: "uk"
        }, {
            label: tr("证书登录"),
            _label: "证书登录",
            moduleName: PORTAL_MAP["auth/logincert"],
            clsName: "cert"
        }, {
            label: tr("账号登录"),
            _label: "账号登录",
            moduleName: PORTAL_MAP["auth/psw"],
            clsName: "account"
        }, {
            label: tr("匿名登录"),
            _label: "匿名登录",
            moduleName: "anonymous",
            clsName: "ano"
        }]
    }

    function initThemeConfig(e) {
        var n;
        e && (n = e.rand ? "?r=" + e.rand : "", d.logo = e.logo ? "theme/images/" + e.logo + n : "theme/images/logo.png", d.title = e.organizeName || "", d.tipsLogin = e.tipsLogin || "", d.tipsLogin === b && (d.tipsLogin = tr(b)), t = e.tipsLogin || "", document.title = i.getTitle(e.title), d.themeLoadStatus = !0)
    }

    function getBodyHeight() {
        var e = document.body.clientHeight,
            n = document.documentElement.clientHeight ? document.documentElement.clientHeight : e,
            o = u ? 82 : 59;
        return n < e && (n = e), Math.max(478, n - o)
    }

    function getContentTop() {
        return head.mobile ? 30 : .4 * (getBodyHeight() - 440)
    }

    function getWinHeight() {
        var e = document.body.clientHeight,
            n = document.documentElement.clientHeight ? document.documentElement.clientHeight : e;
        return n < e && (n = e), n
    }

    function onStartAuth(e, n, o) {
        var t = e === PORTAL_MAP["auth/_key"],
            i = e === PORTAL_MAP["auth/logincert"],
            a = e === PORTAL_MAP["auth/psw"];
        P.moduleName = e, L.assert(void 0 !== e, "first auth type is undefined"), t ? r = "usb_key" : i ? r = "certificate_login" : a && (r = "password"),
            function setOtherListByStartAuth(e) {
                var n, o, t = getLoginTypeList();
                for (g = SF.setting.getGlobal(KEY_GLOBAL_INIT_GET_INIT_CONFIG_DATA, {}), (s.vmodel.$isMobile || is.Mac || is.Linux) && t.splice(0, 1), (o = SF.setting.getGlobal(KEY_GLOBAL_INIT_GET_INIT_CONFIG_DATA, null)).anonymous || t.splice(t.length - 1, 1), o.enableWechatQrcode && !is.phone() && (s.vmodel.wechatStatus = !0), c = [].concat(t), n = t.length - 1; 0 <= n; n--)
                    if (t[n].moduleName === e) {
                        t.splice(n, 1);
                        break
                    }
                s.vmodel.otherLogin = t
            }(e), is.Win() && t && d.downloadLinkData.push({
                label: tr(E),
                _label: E,
                click: d.usbkeyDevice
            }), l.loader.renderPlugin({
                name: e,
                isFirstAuth: !0,
                containerID: "sangfor_main_auth_container",
                data: {
                    isDomainSSO: n,
                    isAnonymousLogin: o
                },
                onAfter: function() {
                    s.vmodel.loginLoadStatus = !0, saveMainVModel()
                },
                success: function() {
                    L.info(_, "trigger mainWindowReady event"), SF.windowMgr.triggerEvent(EVENT_MAIN_WINDOW_READY, {}), f.loadPlugin = !0, updateInitState(), addLoadingWatch()
                }
            })
    }

    function saveMainVModel() {
        !w[r] && avalon.vmodels[r] && (w[r] = avalon.vmodels[r])
    }

    function addLoadingWatch() {
        is.set(r) && avalon.vmodels[r] && avalon.vmodels[r].$watch("loading", function() {
            s.vmodel.loginLoading = avalon.vmodels[r].loading
        })
    }

    function updateInitState() {
        f.loadPlugin && f.initSDK && (d.$fire("all!initState", "finished"), d.isInitLogin = !0)
    }

    function handleDialogClose() {
        w[r] && w[r].isDisabled && (w[r].isDisabled = !1, s.vmodel.loginLoading = !1, is.fn(w[r].changeBtnText) && w[r].changeBtnText(!1)), "usb_key" === r && w[r] && w[r].detectKey && w[r].detectKey()
    }

    function errorTip(e) {
        N.onError({
            subTitle: N.getMessage(e),
            isReload: !0,
            closeBtn: !1
        })
    }

    function getCurLang() {
        d = s.vmodel, SF.init.getLang({
            success: function(e) {
                L.assert(SFConfig.LANGUAGE_LIST.hasOwnProperty(e.data), "get invalid lang data,data:" + e.data), a = e.data, s.vmodel.languageType = s.vmodel.language[a], l.i18n.change(s.vmodel, a, function() {
                    ! function init(e) {
                        var n = String(window.navigator.language || window.navigator.systemLanguage || window.navigator.userLanguage || window.navigator.browserLanguage).toLowerCase();
                        if ((d = s.vmodel).downloadLinkData = [], N.isWeb() || SF.windowMgr.registEvents("onWindowShouldClose", function() {
                                SF.windowMgr.exit()
                            }), d.isShowSwitch = "zh-cn" === n, s.vmodel.wechatAuthItem.label = "zh_CN" === e ? tr(s.vmodel.wechatAuthItem._label) : "Wechat", u || d.downloadLinkData.push({
                                label: tr("下载客户端"),
                                _label: "下载客户端",
                                click: d.downClient
                            }), N.isWeb() && (is.IE(6) || is.IE(7, !0))) return L.debug(_, "Linux not suport login by browser"), void l.loader.renderPage({
                            name: "vpn_refuse_login"
                        });
                        v = !0, o && initThemeConfig(o), d.$watch("anyDialogClose", function(e, n) {
                            n && handleDialogClose()
                        }), SF.init.initSDK({
                            lang: e,
                            onGetInitConfig: function(e) {
                                SF.windowMgr.configGMMode(2 === e.sslAlgor)
                            },
                            onReLogin: function() {
                                var e = PORTAL_MAP["other/_service"].split("/")[1];
                                L.debug(_, "onReLogin enter"), SF.windowMgr.triggerEvent(EVENT_MAIN_WINDOW_READY, {}), avalon.router.go(e)
                            },
                            onOtherLogin: function() {
                                L.debug(_, "onOtherLogin enter"), SF.windowMgr.triggerEvent(EVENT_MAIN_WINDOW_READY, {}), l.loader.renderPage({
                                    name: PORTAL_MAP["other/_relogin"]
                                })
                            },
                            onStartAuth: onStartAuth,
                            onExistProxy: function() {
                                T = !0
                            },
                            onUpdating: function(e, n) {
                                p = function() {
                                    T && location.reload()
                                }, e.code === SFConfig.IS_UPDATE.NEED_UPDATE ? l.loader.renderPlugin({
                                    name: PORTAL_MAP["other/isupdate"],
                                    data: {
                                        enableExit: !is.WebClient,
                                        data: e,
                                        onContinue: n
                                    }
                                }) : n()
                            },
                            onCompleteUpdate: function(e) {
                                p(), p = new Function, e()
                            },
                            onCheckSecurityDeny: function(e, n) {
                                var o = SF.setting.getGlobal(KEY_GLOBAL_INIT_GET_INIT_CONFIG_DATA, {});
                                SF.windowMgr.triggerEvent(EVENT_MAIN_WINDOW_READY, {}), l.loader.renderPlugin({
                                    name: PORTAL_MAP["other/reject_login"],
                                    data: {
                                        strategies: o.securityCheck.list,
                                        ids: e,
                                        resolve: n,
                                        checkType: "before"
                                    }
                                })
                            },
                            onCheckSecurityPass: function(e) {
                                SF.windowMgr.triggerEvent(EVENT_MAIN_WINDOW_READY, {})
                            },
                            onMustInstallClient: function(e, n) {
                                var o;
                                SF.windowMgr.triggerEvent(EVENT_MAIN_WINDOW_READY, {}), L.error(_, "must install client", e), n && "update" === n.process && (o = is.Win() ? tr("客户端更新失败，请重新下载并安装客户端") : tr("客户端与服务器版本不一致，为了避免使用异常，请立即更新")), l.loader.renderPlugin({
                                    name: PORTAL_MAP["other/install"],
                                    data: {
                                        isAutoClose: !0,
                                        message: o
                                    }
                                })
                            },
                            onProxyError: function(e) {
                                SF.windowMgr.triggerEvent(EVENT_MAIN_WINDOW_READY, {}), errorTip(e.code)
                            },
                            onErrorTip: function(e) {
                                SF.windowMgr.triggerEvent(EVENT_MAIN_WINDOW_READY, {}), errorTip(e)
                            },
                            success: function(e) {
                                L.info(_, "init login process success"), f.initSDK = !0, updateInitState()
                            },
                            error: function(e) {
                                SF.windowMgr.triggerEvent(EVENT_MAIN_WINDOW_READY, {}), N.onError({
                                    subTitle: tr("初始化失败, 请刷新重试"),
                                    isReload: !0,
                                    closeBtn: !1
                                }), L.warn(_, "initSDK error", "Please try agin after refreshing or clearing the cache")
                            }
                        })
                    }(a)
                }), SF.init.setLang({
                    lang: e.data,
                    success: function() {
                        L.info(_, "setLang is success, lang is： " + a)
                    },
                    error: function(e) {
                        L.info(_, "setLang is fail, error message is " + JSON.stringify(e))
                    }
                })
            }
        })
    }

    function switchOtherLogin(e) {
        var n;
        for (n = 0; n < s.vmodel.otherLogin.length; n++) s.vmodel.otherLogin[n].label = "zh_CN" === e ? tr(s.vmodel.otherLogin[n]._label) : tr(s.vmodel.otherLogin[n].label);
        s.vmodel.wechatAuthItem.label = "zh_CN" === e ? tr(s.vmodel.wechatAuthItem._label) : "Wechat"
    }
    return u && (document.body.className = document.body.className.replace("bg-f8", ""), document.documentElement.className = document.documentElement.className.replace("bg-f8", ""), A && A.remove()),
        function loadThemeConfig() {
            is.WebClient || SF.windowMgr.resize(SFConfig.CONTAINER_WINDOW_ID.MAIN_WINDOW, S.LOGIN_WIDTH, S.LOGIN_HEIGHT), N.getThemeConfigInfo(function(e) {
                e = e || {}, v ? initThemeConfig(e) : o = e
            })
        }(), e = avalon(window).bind("resize", function throttle(o, t, i) {
            var a, l = null;
            return function() {
                var e = this,
                    n = +new Date;
                clearTimeout(l), a || (a = n), i <= n - a ? (o.apply(e), a = n) : l = setTimeout(function() {
                    o.apply(e)
                }, t)
            }
        }(function() {
            s.vmodel.bodyHeight = getBodyHeight() + "px", s.vmodel.contentTop = getContentTop(), s.vmodel.winHeight = getWinHeight() + "px"
        }, 50, 100)), s.getVModelConfig = function() {
            return {
                $id: "login",
                $isMobile: head.mobile,
                $isClient: u,
                $isWin: m,
                $isLinuxClient: h,
                bodyHeight: getBodyHeight() + "px",
                contentTop: getContentTop(),
                logo: "",
                title: "",
                tipsLogin: "",
                themeLoadStatus: !1,
                wechatStatus: !1,
                downloadLinkData: [],
                otherLogin: [],
                loginLoadStatus: !1,
                showAuth: !1,
                preLoginType: "",
                currLoginType: "",
                wechatAuthItem: {
                    label: tr("微信扫码登录"),
                    _label: "微信扫码登录",
                    moduleName: PORTAL_MAP["auth/wechat"],
                    clsName: "wechat"
                },
                loginLoading: !1,
                isShowSwitch: !0,
                language: {
                    zh_CN: "简体中文",
                    en_US: "English"
                },
                languageType: "简体中文",
                isLanguageItem: !0,
                isInitLogin: !1,
                winHeight: getWinHeight() + "px",
                $isIE8: is.IE() && is.IE() <= 8,
                $onRendered: function() {
                    L.debug(_, "login onRendered"), getCurLang()
                },
                $onBeforeUnload: function() {
                    avalon(window).unbind("resize", e)
                },
                isInitSDKOK: function() {
                    return f.initSDK
                },
                goWechatLogin: function() {
                    var e = document.getElementById("qrcode_iframe");
                    avalon.vmodels.wechat && e.contentDocument.location.reload(), d.goOtherLogin({
                        label: tr("wechat"),
                        _label: "wechat",
                        moduleName: PORTAL_MAP["auth/wechat"],
                        clsName: "wechat"
                    })
                },
                goOtherLogin: function(n) {
                    var o, t, i = [].concat(c),
                        e = r;

                    function gotoPlugin() {
                        w[r = e] && (avalon.vmodels[r] = w[r]), l.loader.renderPlugin({
                            name: n.moduleName,
                            isFirstAuth: !0,
                            containerID: "sangfor_main_auth_container",
                            data: {
                                isInitFinished: !0
                            },
                            onBefore: function() {
                                d.loginLoadStatus = !1
                            },
                            onAfter: function() {
                                d.loginLoadStatus = !0, saveMainVModel(), addLoadingWatch()
                            },
                            success: function() {
                                var e = !1;
                                for (o = 0; o < i.length; o++)
                                    if (i[o].moduleName === n.moduleName) {
                                        i.splice(o, 1);
                                        break
                                    }
                                for (t = 0; t < d.downloadLinkData.length; t++)
                                    if (d.downloadLinkData[t]._label === E && (e = !0, PORTAL_MAP["auth/_key"] !== n.moduleName)) {
                                        d.downloadLinkData.splice(t, 1);
                                        break
                                    }
                                PORTAL_MAP["auth/_key"] !== n.moduleName || e || d.downloadLinkData.push({
                                    label: tr(E),
                                    _label: E,
                                    click: d.usbkeyDevice
                                }), s.vmodel.otherLogin.removeAll(), s.vmodel.otherLogin = i, switchOtherLogin(a)
                            }
                        })
                    }
                    d.loginLoading ? L.debug(_, "Some login is loading, can not open new dialog") : "anonymous" !== n.moduleName ? f.initSDK || n.moduleName === PORTAL_MAP["auth/wechat"] ? (SF.auth.cancelTimer("detectKeyTimer"), n.moduleName === PORTAL_MAP["auth/_key"] ? (e = "usb_key", P.moduleName = PORTAL_MAP["auth/_key"]) : n.moduleName === PORTAL_MAP["auth/logincert"] ? (e = "certificate_login", P.moduleName = PORTAL_MAP["auth/logincert"]) : n.moduleName === PORTAL_MAP["auth/psw"] && (e = "password", P.moduleName = PORTAL_MAP["auth/psw"]), n.moduleName === PORTAL_MAP["auth/wechat"] ? (d.preLoginType = P.moduleName, d.currLoginType = "wechat", e = "wechat", P.moduleName = PORTAL_MAP["auth/wechat"]) : d.currLoginType = "", function resetLogin() {
                        SFAPI.getInitConfig({
                            isRefreshLogin: !0,
                            success: function(e) {
                                L.info(_, "reset auth chain success，continue!"), gotoPlugin()
                            },
                            error: function(e) {
                                L.info(_, "reset auth chain failed，continue!"), gotoPlugin()
                            }
                        })
                    }()) : L.info(_, "SDK init not finished, can not do this login type") : function anonymousLogin() {
                        g && g.anonymous && ("password" !== r ? onStartAuth(PORTAL_MAP["auth/psw"], !1, !0) : avalon.vmodels.password.login({
                            username: "Anonymous"
                        }))
                    }()
                },
                switchLang: function(e) {
                    s.vmodel.loginLoading ? L.debug(_, "Some login is loading, can not open new dialog") : (a = e, s.vmodel.languageType = s.vmodel.language[a], s.vmodel.isLanguageItem = !0, l.i18n.change(s.vmodel, a, function() {
                        t === b && (d.tipsLogin = tr(b)), L.info(_, "switch language for login page success"), switchOtherLogin(a),
                            function switchDownloadLinkData(e) {
                                var n;
                                for (n = 0; n < s.vmodel.downloadLinkData.length; n++) s.vmodel.downloadLinkData[n].label = "zh_CN" === e ? tr(s.vmodel.downloadLinkData[n]._label) : tr(s.vmodel.downloadLinkData[n].label)
                            }(a),
                            function switchWechatLang(e) {
                                var n, o, t, i = !1,
                                    a = getLoginTypeList();
                                if (avalon.vmodels.wechat) {
                                    for (t = document.getElementsByTagName("iframe")[0].contentWindow, avalon.vmodels.wechat.preprivacy = tr("请先阅读并同意免责声明"), n = 0; n < a.length; n++) avalon.vmodels.wechat.preLoginType.type === a[n].moduleName && (avalon.vmodels.wechat.preLoginType.name = tr(a[n]._label));
                                    N.isWeb() && (avalon.vmodels.wechat.otherPrivacy = "zh_CN" === e || "" === e ? [{
                                        label: tr("《免责声明》"),
                                        moduleName: PORTAL_MAP["privacy/zh_CN"]
                                    }] : [{
                                        label: tr("《免责声明》"),
                                        moduleName: PORTAL_MAP["privacy/en_US"]
                                    }], avalon.vmodels.wechat.preprivacy = tr("请先阅读并同意免责声明")), t.translatePage(e), o = t.document.getElementsByTagName("iframe");
                                    try {
                                        i = !/weixin.qq/.test(o[0].contentWindow.location.href)
                                    } catch (l) {
                                        i = !1
                                    }
                                    i && o[0].contentWindow.translatePage(e)
                                }
                            }(a)
                    }), SF.init.setLang({
                        lang: a,
                        switchLang: !0,
                        success: function() {
                            L.debug(_, "switch language for local cache success")
                        },
                        onSetedECLang: function() {
                            SF.windowMgr.triggerEvent(EVENT_ON_OPEN_CONNECT, "{}")
                        },
                        error: function(e) {
                            L.debug(_, "switch language for local cache failed, error message is " + JSON.stringify(e))
                        }
                    }), P.moduleName !== PORTAL_MAP["auth/wechat"] && s.vmodel.goOtherLogin(P))
                },
                downClient: function() {
                    s.vmodel.loginLoading ? L.debug(_, "Some login is loading, can not open new dialog") : head.mobile ? N.openWindow({
                        url: "/por/phone_index.csp#from=login"
                    }) : l.loader.renderPlugin({
                        name: PORTAL_MAP["other/install"],
                        data: {
                            message: "",
                            isAutoClose: !1,
                            enableClose: !0
                        }
                    })
                },
                removeLoginWatch: function() {
                    r && (avalon.vmodels[r].$watch("loading", function() {}), avalon.vmodels[r].$watch("anyDialogClose", function(e) {}))
                },
                handleDialogClose: handleDialogClose,
                showLanguageItem: function() {
                    s.vmodel.isLanguageItem = !1
                },
                closeLanguageItem: function() {
                    s.vmodel.isLanguageItem = !0
                },
                usbkeyDevice: function() {
                    SF.auth.downloadKey()
                },
                openHelp: function() {
                    var e = "/com/help/";
                    "en_US" === a && (e = "/com/help_en/"), u && (e = location.origin + e), N.openWindow({
                        url: e
                    })
                },
                downKeyDevice: function() {
                    SF.auth.downloadKey()
                }
            }
        }, s.vmodel = avalon.define(s.getVModelConfig()), s
});