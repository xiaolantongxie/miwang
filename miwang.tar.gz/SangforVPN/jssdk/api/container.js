! function(e) {
    "use strict";
    var m = SFConfig,
        f = SFCommon,
        k = {
            ecClose: ["id"],
            ecMoveTo: ["id", "x", "y"],
            ecMinimize: [],
            ecMaximize: [],
            ecShow: ["id"],
            ecHide: ["id"],
            ecResize: ["id", "width", "height"],
            ecExit: [],
            ecCloseTray: [],
            ecStartTray: ["trayType"],
            ecChangeTrayStatus: ["status"],
            ecSerDragRect: ["x", "y"],
            ecDbgInfo: ["level", "tag", "msg"],
            ecGetGuid: [],
            ecCreateWindow: ["type", "url"],
            ecWriteConfig: ["key", "value", "callBack"],
            ecReadConfig: ["key", "callBack"],
            ecSetDragRect: ["x", "y"],
            ecLogout: [],
            ecOpenBrowser: ["url", "browserType", "callBack"],
            ecRegisterEventHandler: ["eventName", "callBack"],
            ecSelectFile: ["type", "filter", "callBack"],
            ecDownloadFile: ["url", "filePath", "callBack"],
            ecSetMenuConfig: ["menu"],
            ecRedirect: ["id", "url"],
            ecTriggerEvent: ["eventName", "eventData"]
        },
        o = {
            ecReadConfig: !0,
            ecWriteConfig: !0
        },
        p = window,
        y = SFLOG,
        h = "api:container",
        l = "ecCallBack",
        u = 1e5;

    function createCallBack(a, t) {
        var n, c, i, r = f.getResult();
        return n = l + u, u++, p[n] = function(e) {
            i && clearTimeout(i), y.debug("containerAPI:" + a, " current invoking callBackName:" + n + ",data:" + JSON.stringify(e)), c = f.handleJsonString(e), r.code = c.result || 0, r.data = c.data, 1 === r.code || (y.debug("containerAPI:callBack", " return failed result from invoking callback ", "msg:" + r.msg), r.code = 1, r.data = r.data || {}, r.msg = c.message), t(r)
        }, i = function createTimeOut(a, t, n) {
            if (!o[a]) return y.debug(h, "not need set timeout handler"), "";
            return y.debug(h, "need set timeout handler"), setTimeout(function() {
                var e = f.getResult();
                p[t] = function() {}, e.code = ERROR_SERVER_REQUEST_TIMEOUT, e.data = null, y.debug(h, " invoke method:" + a + " timeout,callBackName is " + t), n(e)
            }, 15e3)
        }(a, n, t), n
    }

    function agency() {}
    e.invokeContainerAPI = function invokeContainerAPI(e, a) {
        new SFCommon.BaseAPI(e, a, function excuting(e, a) {
            var t, n = f.getResult(),
                c = e.name,
                i = e.params || {},
                r = e.success || function() {},
                o = (e.error, []),
                l = [],
                u = 0,
                s = !1,
                d = "";
            if (y.info(h, " current method： " + c), function checkMock() {
                    m.enableContainerMock && (m.container = m.containerMockType, SFContainer.registMock())
                }(), !f.isWeb() && c && k[c] && p[c]) {
                for (y.debug(h, "current method：" + c), "ecWriteConfig" === c && (t = e.params.value || "", e.params.value = t, e.params.flag = e.params.flag || 0), o = k[c]; u < o.length; u++) "callBack" === o[u] && (s = !0), "callBack" === o[u] ? (d = createCallBack(c, r), f.isWinClient() ? l.push(d) : (y.debug(h, "typeof is " + typeof p[d]), l.push(p[d]))) : i.hasOwnProperty(o[u]) ? l.push(i[o[u]]) : l.push("");
                y.debug(h, "current method is " + c + ". callBackName " + d), y.debug(h, "params is:" + JSON.stringify(l));
                try {
                    s ? p[c].apply(agency, l) : (n.code = m.SUCCESS_CODE, n.data.data = p[c].apply(agency, l), e.success(n))
                } catch (g) {
                    y.debug(h, "method is name , invoke container failed,error:" + g.message)
                }
            } else y.error(h, "invokeContainerAPI failed", "not match rules：container environment or method is empty or config file is not configure or container is not have api"), e.error(n), a()
        }).invoke()
    }
}(SFAPI);