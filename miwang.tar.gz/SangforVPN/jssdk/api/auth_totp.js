! function(e) {
    "use strict";
    var a = SFConfig,
        i = SFCommon,
        c = SFDTO,
        u = SFLOG,
        S = "api:auth_totp";
    e.loginTotp = function loginTotp(e, t) {
        var o = SF.setting.getGlobal(KEY_GLOBAL_TWFID, "0"),
            r = e.token || "";
        new i.BaseAPI(e, t, function excuting(n, s) {
            SFRequest.createRequest({
                type: "Server",
                path: "/auth/token",
                data: {
                    twfid: o,
                    svpn_inputtoken: r
                },
                method: "post",
                success: function(e) {
                    var t, o, r = xmlToJSON.parseString(e);
                    o = (t = c.authData(r)).code, t.data.ErrMsg = i.getMessage(o, e), o === a.SUCCESS_CODE || o === a.NEXT_ACTION_CODE ? n.success(t) : n.error(t), s()
                },
                error: function(e) {
                    e = e || {}, u.error(S, "loginTotp error", "%s & %s", e.code, e.msg), n.error(e), s()
                }
            })
        }).invoke()
    }, e.totpRebind = function totpRebind(e, t) {
        var o = SF.setting.getGlobal(KEY_GLOBAL_TWFID, "0");
        new i.BaseAPI(e, t, function excuting(n, s) {
            SFRequest.createRequest({
                type: "Server",
                path: "/auth/token",
                data: {
                    twfid: o,
                    action: "rebind"
                },
                method: "post",
                success: function(e) {
                    var t, o, r = xmlToJSON.parseString(e);
                    o = (t = c.authData(r)).code, t.data.ErrMsg = i.getMessage(o, e), o === a.SUCCESS_CODE || o === a.NEXT_ACTION_CODE ? n.success(t) : n.error(t), s()
                },
                error: function(e) {
                    e = e || {}, u.error(S, "totpRebind error", "%s & %s", e.code, e.msg), n.error(e), s()
                }
            })
        }).invoke()
    }
}(SFAPI);