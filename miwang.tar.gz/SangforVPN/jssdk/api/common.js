! function(e) {
    "use strict";
    var c = SFConfig,
        u = SFCommon,
        o = "client",
        d = SFLOG,
        C = "api:common";

    function getCacheFromECAgent(t) {
        SFRequest.createRequest({
            type: "ECAgent",
            path: "Getter",
            data: [t.key],
            success: function(e) {
                var r = u.getResult(1);
                d.info(C, "invoke getCacheFromHttp success"), e.result === c.SUCCESS_CODE.toString() ? r.data = u.handleJsonString(e.data) : (r.code = 0, d.error(C, "get cache from ECAgent error", "request ECAgent success,but result is not expected ")), t.success(r)
            },
            error: function(e) {
                d.error(C, "get cache from ECAgent error", "request error,error code:%s,error msg:%s", e.code, e.msg), t.error(e)
            }
        })
    }

    function setCacheFromECAgent(t) {
        t.value = is.array(t.value) || is.object(t.value) ? JSON.stringify(t.value) : t.value, SFRequest.createRequest({
            type: "ECAgent",
            path: "Setter",
            data: [t.key, t.value, t.flag || 0],
            success: function(e) {
                var r = u.getResult(1);
                e.result === c.SUCCESS_CODE.toString() ? t.success(r) : (r.code = 0, d.error(C, "set cache to ECAgent error", "request ECAgent success,but result is not expected"), t.error(r))
            },
            error: function(e) {
                var r = u.getResult(0);
                e = e || {}, d.error(C, "request error", "error code:%s,error msg:%s", e.code, e.msg), t.error(r)
            }
        })
    }

    function getEncryptKey(t) {
        SFRequest.createRequest({
            type: "ECAgent",
            path: "GetEncryptKey",
            compat: !0,
            preventOnError: t.preventOnError,
            noSession: !0,
            success: function(e) {
                var r = u.getResult();
                e.result ? (r.code = c.SUCCESS_CODE, r.data.key = e.result, SF.setting.setGlobal({
                    key: KEY_GLOBAL_EC_KEY,
                    value: e.result
                }, 0), t.success(r)) : (d.error(C, "get encrypt key error", "ECAgent return empty key"), t.error(r))
            },
            error: function(e) {
                t.error(e)
            }
        })
    }

    function queryAndConfigEC(e, r, a, i) {
        new u.BaseAPI(e, r, function excuting(t, o) {
            var r, n, e, s, c;
            if (n = t.key, e = t.params || "", s = t.timeout || null, c = t.conCount || null, !n) return t.error({
                code: a
            }), o(), void d.debug(C, "get query or config command error,key is null");
            r = "" !== e ? u.getECCommand(n, e) : u.getECCommand(n), SFRequest.createRequest({
                type: "ECAgent",
                path: i,
                data: [r],
                timeout: s,
                conCount: c,
                success: function(e) {
                    var r = u.handleData(e);
                    1 === r.code ? t.success(r) : t.error(r), o()
                },
                error: function(e) {
                    e = e || {}, d.error(C, "query or config error,the command is " + r, "error code:%s,error msg:%s", e.code, e.msg), t.error(e), o()
                },
                ecVesionAdapter: function(e) {
                    e && "C_CERTINFO" === n && function confCertInfo(e) {
                        var r;
                        r = e.data, e.data = {}, e.data.twfID = r
                    }(e)
                }
            })
        }).invoke()
    }

    function getConcatAddr(e, r) {
        var t = "";
        return "object" == typeof r.info.link || "0" === r.info.custom ? (r.version = "_" + r.version.replace(/\./g, "_"), t = u.formatString(e, {
            dir: r.alias,
            version: r.version
        })) : t = r.info.link, t
    }

    function cookieSaveLocal(r, e) {
        (r = r || {}).success = r.success || function() {}, r.error = r.error || function() {}, SFRequest.createRequest({
            type: "Server",
            path: "/por/update_session.csp?twfid=" + e,
            headers: {
                TWFID: e
            },
            method: "get",
            success: function(e) {
                d.info(C, "change twfid success by api(update_session.csp)"), r.success(e)
            },
            error: function(e) {
                d.error(C, "switch twfid to cookie by api(update_session.csp) error", "request network error"), r.error(e)
            }
        })
    }! function initParams() {
        c.container = u.getClientType(),
            function getSystemType() {
                SFCommon.isWinClient() || is.Win() && SFCommon.isWeb() ? c.systemType = c.CLIENT_TYPE.WINDOWS : SFCommon.isMacClient() || is.Mac && SFCommon.isWeb() ? c.systemType = c.CLIENT_TYPE.MAC : (SFCommon.isLinuxClient() || is.Linux && SFCommon.isWeb()) && (c.systemType = c.CLIENT_TYPE.LINUX)
            }()
    }(), e.doQueryEC = function doQueryEC(e, r) {
        queryAndConfigEC(e, r, 35003, "DoQueryService")
    }, e.doConfigEC = function doConfigEC(e, r) {
        queryAndConfigEC(e, r, 35004, "DoConfigure")
    }, e.getEncryptKey = getEncryptKey, e.getTempData = function getTempData(e, r) {
        new SFCommon.BaseAPI(e, r, function excuting(e, r) {
            var t;
            switch (e.type) {
                case c.CACHE_TYPE.ECAGENT:
                    getCacheFromECAgent(e);
                    break;
                case c.CACHE_TYPE.LOCAL:
                    t = u.getCache(e.key, o) || "", e.success(t);
                    break;
                case c.CACHE_TYPE.TEMP:
                    t = "", c.temp.hasOwnProperty(e.key) && (t = c.temp[e.key]), e.success(t)
            }
            r()
        }).invoke()
    }, e.setTempData = function setTempData(e, r) {
        new SFCommon.BaseAPI(e, r, function excuting(e, r) {
            var t = u.getResult(1);
            switch (e.type = "undefined" == typeof e.type ? c.CACHE_TYPE.TEMP : e.type, d.info(C, "invoke setTempData success. current type is " + e.type), e.type) {
                case c.CACHE_TYPE.ECAGENT:
                    d.info(C, "cache type is ecagent"), setCacheFromECAgent(e);
                    break;
                case c.CACHE_TYPE.LOCAL:
                    u.setCache(e.key, e.value, o), e.success(t);
                    break;
                case c.CACHE_TYPE.TEMP:
                    c.temp[e.key] = e.value, e.success(t);
                    break;
                default:
                    t.code = 0, e.error(t)
            }
            r()
        }).invoke()
    }, e.setTWFID = function setTWFID(e, r) {
        new SFCommon.BaseAPI(e, r, function excuting(r, e) {
            var t, o, n = u.getResult(),
                s = SF.session.createInstance();
            t = s.getTWFID(), r.twfID ? r.twfID !== t || r.isForce ? (d.info(C, "param.twfid is not same as cache.twfid or force sync twfid "), s.setTWFID(r.twfID), getEncryptKey({
                success: function() {
                    var e = u.encryptID({
                        id: r.twfID
                    }, 0);
                    o = u.getECCommand("S_TWFID", {
                        session: e
                    }), c.isExistEC ? SFRequest.createRequest({
                        type: "ECAgent",
                        path: "DoConfigure",
                        data: [o],
                        success: function(e) {
                            d.info(C, "sync twfid to ecagent"), n.code = parseInt(e.result, 0), n.code === c.SUCCESS_CODE ? r.success(n) : (d.info(C, "EC sync twfid failed"), r.error(n))
                        },
                        error: function(e) {
                            e = e || {}, d.error(C, "set twfid error", "request module return error return,error code:" + e.code), r.error(e)
                        }
                    }) : r.success()
                },
                error: function(e) {
                    r.error(e)
                }
            })) : (d.info(C, " param.twfid is same as cache.twfid, do not sync twfid"), n.code = c.SUCCESS_CODE, r.success(n)) : r.error(n)
        }).invoke()
    }, e.getInstallAdress = function getInstallAdress(e, r) {
        new u.BaseAPI(e, r, function excuting(t, o) {
            var e, n, r = t.type || "",
                s = {};
            e = SF.setting.getGlobal(KEY_GLOBAL_VPN_URL, ""), n = {
                win: {
                    link: {
                        win: e + "/com/EasyConnectInstaller.exe"
                    }
                },
                ios: {
                    link: {
                        iosImg: e + "/com/images/ec/iosCode.png",
                        iosApp: "http://itunes.apple.com/us/app/easyconnect/id440460214?ls=1&mt=8"
                    }
                },
                android: {
                    link: {
                        phoneImg: e + "/com/images/ec/androidCode.png",
                        padImg: e + "/com/images/ec/androidPadCode.png",
                        phoneApp: "http://www.sangfor.com.cn/support/Software_Download/EasyConnectPhone.apk",
                        padApp: "http://www.sangfor.com.cn/support/Software_Download/EasyConnectTablet.apk"
                    }
                }
            }, "windows" === r || "ios" === r || "android" === r ? (s[r] = n[r], t.success({
                code: 1,
                data: s
            }), o()) : SFRequest.createRequest({
                type: "Server",
                path: "/por/ec_pkg.csp",
                apiVersion: "0",
                method: "post",
                data: {
                    type: r
                },
                success: function(e) {
                    var r;
                    (r = function analysisDownloadPath(e) {
                        var r, t = "http://download.sangfor.com.cn/download/product/sslvpn/pkg/";
                        return r = {
                            mac: {
                                link: {
                                    mac: t + "{dir}/EasyConnect{version}.dmg"
                                }
                            },
                            linux: {
                                link: {
                                    deb_x86: t + "{dir}/EasyConnect_x86{version}.deb",
                                    deb_x64: t + "{dir}/EasyConnect_x64{version}.deb",
                                    rpm_x86: t + "{dir}/EasyConnect_x86{version}.rpm",
                                    rpm_x64: t + "{dir}/EasyConnect_x64{version}.rpm"
                                }
                            }
                        }, d.assert(e.root, "get download client url error, invoke api failed or api return invalid data"), e.root ? (r.linux.link.deb_x86 = getConcatAddr(r.linux.link.deb_x86, e.root.linux.deb.x86), r.linux.link.deb_x64 = getConcatAddr(r.linux.link.deb_x64, e.root.linux.deb.x64), r.linux.link.rpm_x86 = getConcatAddr(r.linux.link.rpm_x86, e.root.linux.rpm.x86), r.linux.link.rpm_x64 = getConcatAddr(r.linux.link.rpm_x64, e.root.linux.rpm.x64), r.mac.link.mac = getConcatAddr(r.mac.link.mac, e.root.mac), r) : {
                            mac: {
                                link: {
                                    mac: ""
                                }
                            },
                            linux: {
                                link: {
                                    deb_x86: "",
                                    deb_x64: "",
                                    rpm_x86: "",
                                    rpm_x64: ""
                                }
                            }
                        }
                    }(xmlToJSON.parseString(e))).win = n.win, r.ios = n.ios, r.android = n.android, t.success({
                        code: 1,
                        data: r
                    }), o()
                },
                error: function(e) {
                    e = e || {}, d.error(C, "get instrall address error", "error code:%s,error msg:%s", e.code, e.msg), t.error(e), o()
                }
            })
        }).invoke()
    }, e.createShortcut = function createShortcut(e, r) {
        new u.BaseAPI(e, r, function excuting(t, o) {
            SFRequest.createRequest({
                type: "ECAgent",
                path: "CreateShortcut",
                success: function(e) {
                    var r = u.handleData(e);
                    1 === r.code ? t.success(r) : (t.error(r), d.error(C, "create shortcut error", "request ECAgent success,but result is not expected")), o()
                },
                error: function(e) {
                    e = e || {}, d.error(C, "create shortcut error", "request network error"), t.error(e), o()
                }
            })
        }).invoke()
    }, e.startEasyConnect = function startEasyConnect(e, r) {
        new u.BaseAPI(e, r, function excuting(r, t) {
            SFRequest.createRequest({
                type: "ECAgent",
                path: "StartEasyConnect",
                success: function() {
                    var e = SFCommon.getResult(1);
                    r.success(e), t()
                },
                error: function(e) {
                    e = e || {}, d.error(C, "create shortcut error", "request network error"), r.error(e), t()
                }
            })
        }, "startEasyConnect").invoke()
    }, e.cookieSaveLocal = cookieSaveLocal, e.handleAuthResult = function handleAuthResult(e, r, t, o) {
        var n = r.code,
            s = SF.session.createInstance();
        if (d.info(C, "[timecount] handle auth data, the code is " + r.code), n === c.SUCCESS_CODE || n === c.NEXT_ACTION_CODE || n >= c.REDIRECT_URL_START_CODE && n < c.REDIRECT_URL_END_CODE || is.fn(SFCustom.authResultFilter) && SFCustom.authResultFilter(n)) {
            if (r.data && r.data.twfID && (n !== c.SUCCESS_CODE ? s.setTWFID(r.data.twfID) : SF.setting.setGlobal({
                    key: KEY_GLOBAL_LOGIN_CLIENT_TYPE,
                    value: c.container
                }, 0), o)) return d.info(C, "need change local cookie when current auth item success "), void cookieSaveLocal({
                success: function() {
                    d.info(C, "change local cookie success when current auth item success"), e.success(r), t()
                },
                error: function() {
                    d.error(C, "change local cookie failed when current auth item success", "request server failed"), e.success(r), t()
                }
            }, r.data.twfID);
            e.success(r)
        } else e.error(r);
        t()
    }, e.openBrowser = function openBrowser(e, r) {
        new u.BaseAPI(e, r, function excuting(r, t) {
            var e = {};
            if (!r.url) return d.error(C, "open browser  failed", "params of url is empty"), void r.error();
            e.type = r.type || "default", e.url = r.url || "", e.withShortcut = 1 === r.withShortcut ? 1 : 0, SFRequest.createRequest({
                type: "ECAgent",
                path: "OpenBrowser",
                data: [JSON.stringify(e)],
                success: function() {
                    r.success(), t()
                },
                error: function(e) {
                    e = e || {}, d.error(C, "open browser error", " request by http error "), r.error(), t()
                }
            })
        }, "openBrowser").invoke()
    }, e.getCacheFromECAgent = getCacheFromECAgent, e.setCacheFromECAgent = setCacheFromECAgent
}(SFAPI);