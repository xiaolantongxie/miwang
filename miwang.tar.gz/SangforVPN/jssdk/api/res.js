! function(s) {
    "use strict";
    var d = SFConfig,
        S = SFCommon,
        g = SFLOG,
        o = 300,
        n = 200,
        t = 10,
        a = 1e3,
        c = 3,
        f = "api:res",
        i = SFDTO,
        E = 0,
        C = 1,
        h = 2;

    function translateData(e, r) {
        var t, o = e || {},
            n = xmlToJSON.parseString(o);
        return "Conf" === r ? (t = n).ErrorCode = 1 : "Resource" === r ? ((t = n).ErrorCode = 1, t.securityCheckInterval || 0, t.enableSecurityCheck || !1) : t = n.Auth, {
            code: parseInt(t.ErrorCode, 10),
            data: t
        }
    }

    function queryECStatus(t) {
        var e = S.getECCommand("Q_LOGINSTATUS");
        SFRequest.createRequest({
            type: "ECAgent",
            path: "DoQueryService",
            data: [e],
            method: "get",
            conCount: t.conCount,
            preventOnError: t.preventOnError,
            success: function(e) {
                var r = S.handleData(e);
                if (!S.checkObjAttrExits(r, "data.status")) return g.error(f, "query login status failed", "result not have data.status"), void t.error();
                r.code = parseInt(r.data.status, 10), r.data.validTime = 29, r.code === d.LOGIN_STATUS.SWITCH ? function queryChangeSession(r) {
                    var e = S.getECCommand("Q_SESSIONID");
                    r.reTryErrorCount = "undefined" == typeof r.reTryErrorCount ? 0 : r.reTryErrorCount, SFRequest.createRequest({
                        type: "ECAgent",
                        path: "DoQueryService",
                        data: [e],
                        method: "get",
                        success: function(e) {
                            1 === S.handleData(e).code ? (SF.session.createInstance().setTWFID(e.data.sessionID), g.info(f, " session change from EC success "), is.fn(r.onSessionChange) && r.onSessionChange(e.data.sessionID), SFCommon.isWeb() ? s.cookieSaveLocal(r, e.data.sessionID) : r.success(e)) : (g.info(f, "session change failed"), r.reTryErrorCount > c ? r.error(e) : (r.reTryErrorCount++, setTimeout(function() {
                                g.info(f, "attemp to request again for changing session, current cout :" + r.reTryErrorCount), queryChangeSession(r)
                            }, d.COMMON_TIMESPAN)))
                        },
                        error: function(e) {
                            g.error(f, "session change network is fail", "error is &s", e.msg || ""), r.error(e)
                        },
                        ecVesionAdapter: function(e) {
                            var r;
                            g.info(f, "queryChangeSession:EC: start converting Q_SESSION res to standard !"), e && (r = e.data, e.data = {}, e.data.sessionID = r, g.info(f, "queryChangeSession:EC: convert old data to new data "))
                        }
                    })
                }({
                    onSessionChange: t.onSessionChange,
                    success: function() {
                        SF.session.createInstance().syncSession(), queryECStatus(t), g.info(f, "queryLoginStatus:ECAgent: switching session success ")
                    },
                    error: function() {
                        g.error(f, "query logout success, switching session error ", "error is %s ", e.msg || ""), t.error()
                    }
                }) : (r.data.logoutType = parseInt(e.data.logoutType, 10), r.code === d.LOGIN_STATUS.LOGOUT && r.data.logoutType === d.SERVER_LOGOUT && (r.data.logoutReason = formatLogoutInfo(S.handleJsonString(Base64.decode(e.data.logoutReason)))), r.data.resSecChk = e.data.resSecChk, t.success(r))
            },
            error: function(e) {
                g.error(f, " query login status error", "error is %s ", JSON.stringify(e)), t.error(e)
            }
        })
    }

    function queryServerStatus(n) {
        SFRequest.createRequest({
            type: "Server",
            path: "/por/timequery.csp",
            method: "get",
            conCount: n.conCount,
            preventOnError: n.preventOnError,
            success: function(e) {
                var r = /externsession#oldsessid=([^#]+)/,
                    t = translateData(e, "Auth"),
                    o = (t.data.data || "").trim().toLowerCase();
                r.test(o) ? function onSessionSwitched(t) {
                    var e = {
                        msg: "logout",
                        oldsessid: t.oldSession
                    };
                    t.reTryErrorCount = "undefined" == typeof t.reTryErrorCount ? 0 : t.reTryErrorCount, SFRequest.createRequest({
                        type: "Server",
                        path: "/por/timequery.csp",
                        method: "get",
                        data: e,
                        success: function(e) {
                            var r = translateData(e, "Auth");
                            r.code === d.SUCCESS_CODE && "logout=done" === r.data.data ? (SF.session.createInstance().setTWFID(r.data.twfID), is.fn(t.onSessionChange) && t.onSessionChange(r.data.twfID), t.success(r)) : (g.debug(f, "session change failed"), t.reTryErrorCount > c ? t.error(e) : (t.reTryErrorCount++, setTimeout(function() {
                                g.debug(f, "attemp to request again, current cout :" + t.reTryErrorCount), onSessionSwitched(t)
                            }, d.COMMON_TIMESPAN)))
                        },
                        error: function(e) {
                            t.error(e)
                        }
                    })
                }({
                    oldSession: o.replace(r, "$1"),
                    onSessionChange: n.onSessionChange,
                    success: function(e) {
                        g.info(f, "queryLoginStatus:Server: switching session success "), queryServerStatus(n)
                    },
                    error: function(e) {
                        g.info(f, "queryLoginStatus:Server: query status success ,switching session error "), n.error(e)
                    }
                }) : (t.code = 0 < parseInt(o, 10) ? d.LOGIN_STATUS.ONLINE : d.LOGIN_STATUS.LOGOUT, t.data = {
                    validTime: parseInt(o, 10),
                    twfID: t.data.twfID
                }, 0 < parseInt(o, 10) ? (t.code = d.LOGIN_STATUS.ONLINE, n.success(t)) : (t.code = d.LOGIN_STATUS.LOGOUT, n.isQueryLogout ? function getLogoutInfo(o) {
                    var t, n = SF.setting.getGlobal(KEY_GLOBAL_TWFID, "");

                    function getLogoutInfo(e) {
                        var r, t;
                        t = e || Math.round((new Date).getTime() / 1e3), r = S.encryptID({
                            id: n,
                            type: d.ENCRYPT_TYPE_PSW,
                            extraCode: t
                        }), SFRequest.createRequest({
                            type: "Server",
                            path: "/por/getlogoutinfo.csp",
                            method: "get",
                            data: {
                                exdata: r
                            },
                            conCount: o.conCount,
                            preventOnError: o.preventOnError,
                            success: function(e) {
                                e = S.handleJsonString(e), o.success(e)
                            },
                            error: function(e) {
                                g.error(f, "getLogoutInfo:Server: query getLogoutInfo error ", "error is %s ", e.code || ""), o.error()
                            }
                        })
                    }
                    SFRequest.createRequest({
                        type: "Server",
                        path: "/por/randtick.csp",
                        method: "get",
                        conCount: o.conCount,
                        preventOnError: o.preventOnError,
                        success: function(e) {
                            var r = translateData(e, "Auth");
                            r.code === d.SUCCESS_CODE && r.data.RandTick ? t = r.data.RandTick : (g.error(f, "getLogoutInfo:Server: get RandTick data error, continue by local time", "error is %s ", e.code || ""), t = null), getLogoutInfo(t)
                        },
                        error: function(e) {
                            g.error(f, "getLogoutInfo:Server: query randtick error, continue by local time", "error is %s ", e.code || ""), getLogoutInfo(null)
                        }
                    })
                }({
                    preventOnError: n.preventOnError,
                    success: function(e) {
                        t.data.logoutReason = formatLogoutInfo(e), n.success(t)
                    },
                    error: function() {
                        t.data.logoutReason = formatLogoutInfo({}, !0), n.success(t)
                    }
                }) : n.success(t)))
            },
            error: function(e) {
                g.error(f, "query status error ", "error is %s ", e.msg || ""), n.error(e)
            }
        })
    }

    function formatLogoutInfo(e, r) {
        var t = {};
        return r || !S.checkObjAttrExits(e, "ErrorCode") || e.ErrorCode !== d.SUCCESS_CODE ? (g.error(f, "get logout information error", "error is %s", e.ErrorCode), t = {
            reason: d.LOGOUT.LOGOUT_DEFAULT,
            msg: ""
        }) : t = {
            reason: e.data.reason,
            msg: e.data.msg,
            data: e.data.data
        }, t
    }

    function isFinalState(e) {
        return e === d.SERVICE_STATE.STATUS_LOGOUT || e === d.SERVICE_STATE.STATUS_START_FAILED || e === d.SERVICE_STATE.STATUS_START_SUCCESS || e === d.SERVICE_STATE.STATUS_ALREADY_EXISTS || e === d.SERVICE_STATE.STATUS_NEED_NOT_SERVICE
    }

    function queryServiceAllTime(i, u) {
        var e = S.getECCommand("Q_STATE_ALL");
        SFRequest.createRequest({
            type: "ECAgent",
            path: "DoQueryService",
            data: [e],
            method: "get",
            success: function(e) {
                var r, t, o = S.handleData(e),
                    n = o.data || {},
                    s = parseInt(n.base, 10) || parseInt(n.allService, 10),
                    a = parseInt(n.tcp, 10),
                    c = parseInt(n.l3vpn, 10);
                i.count++, o.data = o.data || {}, r = "Query service status result: base:" + (o.data.base = s) + ",tcp:" + (o.data.tcp = a) + ",l3vpn:" + (o.data.l3vpn = c) + ".", i.lastLog !== r && (g.debug(f, r + "count : " + i.count), i.lastLog = r, i.onStateChanged && i.onStateChanged(o.data)), !i.tcpFinished && isFinalState(a) && (g.debug(f, "TCP service is changed to finished state"), i.onTcpFinished && i.onTcpFinished(), i.tcpFinished = !0), !i.l3vpnFinished && isFinalState(c) && (g.debug(f, "L3vpn service is changed to finished state"), i.onL3vpnFinished && i.onL3vpnFinished(), i.l3vpnFinished = !0), (t = function getStateResult(e, r, t) {
                    return e === d.SERVICE_STATE.STATUS_START_FAILED || e === d.SERVICE_STATE.STATUS_LOGOUT ? h : isFinalState(r) && isFinalState(t) ? C : E
                }(s, a, c)) === E && (!i.queryMax || i.count <= i.queryMax) ? queryServiceTimerResult(i, u) : (t === C ? i.success(o) : (i.tcpFinished || (g.info(f, "TCP service is changed to finished state without success"), i.onTcpFinished && i.onTcpFinished(), i.tcpFinished = !0), i.l3vpnFinished || (g.info(f, "L3vpn service is changed to finished state without success"), i.onL3vpnFinished && i.onL3vpnFinished(), i.l3vpnFinished = !0), g.error(f, " query service status error ", " start service error, logout or over max request times, but do not return expected result "), i.error(o)), u())
            },
            error: function(e) {
                i.error(e), u()
            },
            ecVesionAdapter: function(e) {
                e && (e.data = S.urlToJson(e.data))
            }
        })
    }

    function queryServiceTimerResult(e, r) {
        e.count > t && (e.delay = a), setTimeout(function() {
            queryServiceAllTime(e, r)
        }, e.delay)
    }

    function queryService(e, r) {
        var t = new S.BaseAPI(e, r, function excuting(e, r) {
            queryServiceTimerResult(e, r)
        });
        e.result = e.result || [], e.queryMax = e.queryMax || o, e.delay = e.delay || n, e.count = 0, t.invoke()
    }
    s.getStrategyAndResouceData = function getStrategyAndResouceData(e, r) {
        new S.BaseAPI(e, r, function excuting(t, e) {
            Promise.all([function getStrategy() {
                return new Promise(function(r, t) {
                    var e, o, n, s;
                    e = d.isExistEC ? "ECAgent" : "Server", o = d.isExistEC ? "GetConfig" : "/por/conf.csp", n = d.isExistEC ? ["1"] : {}, SFRequest.createRequest({
                        type: e,
                        path: o,
                        data: n,
                        method: "get",
                        success: function(e) {
                            1 !== (s = d.isExistEC ? S.handleData(e) : translateData(e, "Conf")).code ? (g.error(f, "Get Conf error", "error is %", d.isExistEC ? e.msg || "" : S.getMessage(s.code)), t(s)) : null === s.data.Auth ? (g.error(f, "Get Conf error", " Auth failed, please relogin."), t(s)) : "undefined" == typeof s.data.Conf ? (g.error(f, "Get Conf error!", " Conf is undefined"), t(s)) : r(s.data || {})
                        },
                        error: function(e) {
                            g.error(f, "Get Conf error!", " error is %s ", e.msg || ""), t(e)
                        }
                    })
                })
            }(), function getResource(e) {
                return new Promise(function(r, t) {
                    var e, o, n, s;
                    e = d.isExistEC ? "ECAgent" : "Server", o = d.isExistEC ? "GetConfig" : "/por/rclist.csp", n = d.isExistEC ? ["2"] : {}, SFRequest.createRequest({
                        type: e,
                        path: o,
                        data: n,
                        method: "get",
                        success: function(e) {
                            1 !== (s = d.isExistEC ? S.handleData(e) : translateData(e, "Resource")).code ? (g.error(f, "getResource error ", "error is %", d.isExistEC ? e.msg || "" : S.getMessage(s.code)), t(s)) : null === s.data.Auth ? (g.error(f, "getResource error", "Auth failed, please relogin."), t(s)) : "undefined" == typeof s.data.Resource ? (g.error(f, "getResource error", "Resource is undefined."), t(s)) : r(s.data || {})
                        },
                        error: function(e) {
                            g.error(f, "getResource error!", " error is %s ", e.msg || ""), t(e)
                        }
                    })
                })
            }()]).then(function(e) {
                var r = {
                    code: 1,
                    data: {
                        conf: e[0],
                        rc: e[1]
                    }
                };
                t.success(r)
            })["catch"](function(e) {
                t.error(e)
            })
        }).invoke()
    }, s.noticeClientConfig = function noticeClientConfig(r) {
        SFRequest.createRequest({
            type: "ECAgent",
            path: "DoXmlConfigure",
            method: "get",
            data: [1],
            success: function() {
                SFRequest.createRequest({
                    type: "ECAgent",
                    path: "DoXmlConfigure",
                    method: "get",
                    data: [2],
                    success: function() {
                        r.success()
                    },
                    error: function(e) {
                        g.error(f, "DoXmlConfigure rc error!", " error is %s ", e.msg), r.error()
                    }
                })
            },
            error: function(e) {
                g.error(f, "DoXmlConfigure config error!", " error is %s ", e.msg), r.error()
            }
        })
    }, s.syncInfoForLocalPage = function syncInfoForLocalPage(r) {
        var e = r.info;
        SFAPI.setTempData({
            type: d.CACHE_TYPE.ECAGENT,
            key: d.CACHE_PREFIX + d.CACHE_FOR_LOCAL,
            value: JSON.stringify(e),
            flag: 0,
            success: function(e) {
                g.debug(f, "Set info to ecagent for settings success"), r.success(e)
            },
            error: function(e) {
                g.debug(f, "Set info to ecagent for settings falied"), r.error(e)
            }
        })
    }, s.startService = function startService(e, r) {
        new S.BaseAPI(e, r, function excuting(o, n) {
            SFRequest.createRequest({
                type: "ECAgent",
                path: "StartService",
                method: "get",
                success: function(e) {
                    var r, t = S.handleData(e);
                    1 === t.code ? (is.fn(o.onBeforeQuery) && (r = o.onBeforeQuery()), r && r.then ? r.then(function() {
                        queryService(o)
                    }) : queryService(o)) : (o.error(t), n())
                },
                error: function(e) {
                    g.error(f, "start service error!", " error is %s ", e.msg || ""), o.error(e), n()
                }
            })
        }).invoke()
    }, s.startECTray = function startECTray(e, r) {
        new S.BaseAPI(e, r, function excuting(r, e) {
            ! function syncBaseInfo(r) {
                var e = [],
                    t = {},
                    o = SF.session.createInstance();
                e = SF.setting.getGlobal([KEY_GLOBAL_LOGIN_CLIENT_TYPE, KEY_GLOBAL_EC_PORT, KEY_GLOBAL_VPN_URL, KEY_GLOBAL_FROM_URL, KEY_GLOBAL_BROWSER_TYPE, KEY_GLOBAL_LOGIN_NAME, KEY_GLOBAL_TRAY_TYPE, KEY_GLOBAL_LANG, KEY_GLOBAL_SECURITY_CHECK, KEY_GLOBAL_SECURITY_STRATEGIES], [0]), t.loginClientType = e[0] || 0, t.port = e[1] || 0, t.vpnURL = e[2] || "", t.fromURL = e[3] || "", t.browserType = e[4] || "default", t.loginName = e[5] || "", t.trayType = e[6] || 0, t.lang = e[7] || "zh_CN", t.securityCheck = e[8] || !1, t.strategies = e[9] || [], g.debug(f, "before starttray: current sync data is " + JSON.stringify(t)), SF.setting.setShm({
                    key: KEY_VPN_BASE_INFO,
                    value: t
                }, function(e) {
                    g.debug(f, "brefore starttray: set baseinfo to ecagent"), SFCommon.isWeb() ? r.success() : o.syncSession(function() {
                        r.success()
                    })
                })
            }({
                success: function(e) {
                    g.info(f, "before start manage page sync baseinfo success"),
                        function startManagerPage(t) {
                            S.isWeb() ? SFRequest.createRequest({
                                type: "ECAgent",
                                path: "StartEasyConnectTray",
                                method: "get",
                                success: function(e) {
                                    var r = S.handleData(e);
                                    1 === r.code ? t.success(r) : t.error(r)
                                },
                                error: function(e) {
                                    g.error(f, "startECTray error!", " error is %s ", e.msg || ""), t.error(e)
                                }
                            }) : function createShadowPage(e, r) {
                                var t = d.CONTAINER_WINDOW_PATH.STATUS_MANAGER_WINDOW;
                                g.info(f, "createShadowPage：start tray!"), SF.windowMgr.redirect(d.CONTAINER_WINDOW_ID.STATUS_MANAGER_WINDOW, t, !1), e()
                            }(t.success, t.error)
                        }(r)
                },
                error: function(e) {
                    g.error(f, "before start manage page sync baseinfo error"), r.error(e)
                }
            })
        }).invoke()
    }, s.getUnAuthRes = function getUnAuthRes(e, r) {
        new S.BaseAPI(e, r, function excuting(t, o) {
            var e = S.getECCommand("Q_DISABLE");
            SFRequest.createRequest({
                type: "ECAgent",
                path: "DoQueryService",
                data: [e],
                method: "get",
                success: function(e) {
                    var r = S.handleData(e);
                    1 === r.code ? t.success(r) : t.error(r), o()
                },
                error: function(e) {
                    g.error(f, " get unauth resource error ", "network requet error "), t.error(e), o()
                },
                ecVesionAdapter: function(e) {
                    var r = [],
                        t = [],
                        o = 0;
                    if (g.info(f, "getUnAuthRes: start converting Q_DISABLE res to standard !"), e && e.data) {
                        if (!e.data) return void g.error(f, " get unauth data error ", " res.data is undefined ");
                        if (is.number(e.data)) return void g.error(f, "res.data type is number", " number is  %s", e.data);
                        for (r = e.data.split(";"), e.data = {}, e.data.rc = []; o < r.length; o++) t = r[o].split(","), e.data.rc.push({
                            rcID: t[0],
                            check: t[1],
                            sid: t[2]
                        });
                        g.info(f, "getUnAuthRes: convert old data to new data success")
                    }
                }
            })
        }).invoke()
    }, s.checkLoginStatus = function checkLoginStatus(e, r) {
        new S.BaseAPI(e, r, function excuting(r, t) {
            r.byServer = r.byServer || !1, r.conCount = r.conCount || 0 === r.conCount ? r.conCount : d.DEFAULT_RECONNECT_COUNT, r.preventOnError = r.preventOnError || !1, r.onSessionChange = r.onSessionChange || function() {}, d.isExistEC && !r.byServer ? queryECStatus({
                preventOnError: r.preventOnError,
                conCount: r.conCount,
                onSessionChange: r.onSessionChange,
                success: function(e) {
                    r.success(e), t()
                },
                error: function(e) {
                    r.error(e), t()
                }
            }) : queryServerStatus({
                preventOnError: r.preventOnError,
                conCount: r.conCount,
                isQueryLogout: r.isQueryLogout,
                onSessionChange: r.onSessionChange,
                success: function(e) {
                    r.success(e), t()
                },
                error: function(e) {
                    r.error(e), t()
                }
            })
        }).invoke()
    }, s.logout = function logout(e, r) {
        new S.BaseAPI(e, r, function excuting(o, r) {
            var e, t, n = !!is.bool(o.byServer) && o.byServer;
            !d.isExistEC || n ? (e = "Server", t = "/por/logout.csp") : (e = "ECAgent", t = "Logout"), SFRequest.createRequest({
                type: e,
                path: t,
                method: "post",
                success: function(e) {
                    var r, t;
                    d.isExistEC ? t = S.handleData(e) : (r = xmlToJSON.parseString(e), t = i.authOtherData(r)), t.code !== d.SUCCESS_CODE && t.code !== ERROR_HTTP_MOVE_REQUEST ? s.checkLoginStatus({
                        byServer: n,
                        success: function(e) {
                            e.code === d.LOGIN_STATUS.LOGOUT ? o.success(e) : o.error(e)
                        },
                        error: function(e) {
                            g.error(f, "after request logout error,check loginstatus again ,result is failed", "request network error,data is " + JSON.stringify(e)), o.error(e)
                        }
                    }) : o.success(t)
                },
                error: function(e) {
                    e = e || {}, g.error(f, "logout error", "error code:%s,error msg:%s", e.code, e.msg), o.error(e), r()
                }
            })
        }).invoke()
    }, s.queryService = queryService, s.fetchBalanceData = function fetchBalanceData(e, r) {
        new S.BaseAPI(e, r, function handler(t, r) {
            var e = S.getECCommand("Q_RCBALANCE");
            SFRequest.createRequest({
                type: "ECAgent",
                path: "DoQueryService",
                data: [e],
                method: "get",
                success: function(e) {
                    var r = S.handleData(e);
                    r.code === d.SUCCESS_CODE ? t.success(r) : t.error(r)
                },
                error: function(e) {
                    t.error(e), is.fn(r) && r()
                }
            })
        }).invoke()
    }, s.updateBalanceRes = function updateBalanceRes(e, r) {
        new S.BaseAPI(e, r, function excuting(t, r) {
            var e = S.getECCommand("C_RCBALANCE"),
                o = "/por/balance_update.csp?rcname=" + encodeURIComponent(t.rcName) + "&grpid=" + t.grpID + "&secid=" + t.secID + "&autoid=" + t.autoID;
            SFRequest.createRequest({
                type: "ECAgent",
                path: "doConfigure",
                data: [e, o],
                method: "get",
                success: function(e) {
                    var r = S.handleData(e);
                    r.code === d.SUCCESS_CODE ? t.success(r) : t.error(r)
                },
                error: function(e) {
                    t.error(e), is.fn(r) && r()
                }
            })
        }).invoke()
    }, s.getPrefSetting = function getPrefSetting(e, r) {
        new S.BaseAPI(e, r, function excuting(t, o) {
            S.getResult();
            var e = S.getECCommand("Q_PREFSETTING");
            SFRequest.createRequest({
                type: "ECAgent",
                path: "DoQueryService",
                data: [e],
                method: "get",
                success: function(e) {
                    var r = S.handleData(e);
                    1 === r.code ? t.success(r) : t.error(r), o()
                },
                error: function(e) {
                    g.error(f, " query pref settings error", "error is %s ", e.msg || ""), t.error(e), o()
                }
            })
        }).invoke()
    }, s.startSsoProgram = function startSsoProgram(e, r) {
        new S.BaseAPI(e, r, function excuting(t, o) {
            var e = t.args || [];
            SFRequest.createRequest({
                type: "ECAgent",
                path: "StartSsoProgram",
                data: e,
                method: "get",
                success: function(e) {
                    var r = S.handleData(e);
                    1 === r.code ? t.success(r) : t.error(r), g.debug(f, "Start CS SSO program request success"), o()
                },
                error: function(e) {
                    g.error(f, "Start CS SSO program error", "error is %s ", e.msg || ""), t.error(e), o()
                }
            })
        }).invoke()
    }, s.startSsoIE = function startSsoIE(e, r) {
        new S.BaseAPI(e, r, function excuting(t, o) {
            var e = t.url;
            g.assert(!is.empty(t.url), "url is empty, Can not Start IE for SSO"), e = encodeURIComponent(e), SFRequest.createRequest({
                type: "ECAgent",
                path: "StartSsoIE",
                data: [e],
                method: "get",
                success: function(e) {
                    var r = S.handleData(e);
                    1 === r.code ? t.success(r) : t.error(r), g.debug(f, "Start IE for SSO request success"), o()
                },
                error: function(e) {
                    g.error(f, "Start IE for SSO error", "error is %s ", e.msg || ""), t.error(e), o()
                }
            })
        }).invoke()
    }, s.getKeySN = function getKeySN(e, r) {
        new S.BaseAPI(e, r, function excuting(o, n) {
            SFRequest.createRequest({
                type: "ECAgent",
                path: "GetNDkeySN",
                method: "get",
                success: function(e) {
                    var r = S.handleData(e),
                        t = r.code;
                    g.debug(f, "Get key sn request success, code is:" + t), t === d.SUCCESS_CODE ? o.success(r.data.SerialNumber) : o.error(r), n()
                },
                error: function(e) {
                    g.error(f, "Get key id error", "error code is %s ", e.msg || ""), o.error(e), n()
                }
            })
        }).invoke()
    }
}(SFAPI);