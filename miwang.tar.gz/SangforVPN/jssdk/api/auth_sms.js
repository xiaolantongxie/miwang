! function(e) {
    "use strict";
    var a = SFConfig,
        s = SFCommon,
        i = SFDTO,
        c = SFLOG,
        m = "api:auth_sms";
    e.loginSms = function loginSms(e, r) {
        new s.BaseAPI(e, r, function excuting(t, n) {
            var e;
            e = t.tel ? "/por/login_sms2.csp" : "/por/login_sms1.csp", t.smsCode || c.error(m, "smsCode is null", "smsCode params error or is input null"), SFRequest.createRequest({
                type: "Server",
                path: e,
                data: {
                    svpn_inputsms: t.smsCode || ""
                },
                method: "post",
                success: function(e) {
                    var r, s, o = xmlToJSON.parseString(e);
                    (s = (r = i.authData(o)).code) === a.SUCCESS_CODE || s === a.NEXT_ACTION_CODE || s >= a.REDIRECT_URL_START_CODE && s < a.REDIRECT_URL_END_CODE ? t.success(r) : t.error(r), n()
                },
                error: function(e) {
                    e = e || {}, c.error(m, "login sms error", "%s & %s", e.code, e.msg), t.error(e), n()
                }
            })
        }).invoke()
    }, e.getSmsConfig = function getSmsConfig(e, r) {
        new s.BaseAPI(e, r, function excuting(o, t) {
            SFRequest.createRequest({
                type: "Server",
                path: "/por/login_sms.csp",
                method: "post",
                success: function(e) {
                    var r, s = xmlToJSON.parseString(e);
                    (r = i.authOtherData(s, "getSmsConfig")).data.phone = r.data.phone ? r.data.phone.split(";") : [], r.code === a.SUCCESS_CODE ? o.success(r) : o.error(r), t()
                },
                error: function(e) {
                    e = e || {}, c.error(m, "get init config of sms error", "error code:%s,error msg:%s", e.code, e.msg), o.error(e), t()
                }
            })
        }).invoke()
    }, e.getSmsCode = function getSmsCode(e, r) {
        new s.BaseAPI(e, r, function excuting(t, n) {
            var e;
            e = t.tel ? "/por/get_sms.csp" : "/por/post_sms.csp", t.reqParam && t.reqParam.getSmsCodeUrl && (e = t.reqParam.getSmsCodeUrl), SFRequest.createRequest({
                type: "Server",
                path: e,
                data: {
                    phone_number: t.tel || "",
                    phone_index: t.index || 0
                },
                method: "post",
                success: function(e) {
                    var r, s, o = xmlToJSON.parseString(e);
                    (s = o.Auth || {}).disableTime = s.SmsSendInterval || s.SmsIsStillValid || 0, o.Auth = s, (r = i.authOtherData(o, "getSmsCode")).code === a.SUCCESS_CODE ? t.success(r) : t.error(r), n()
                },
                error: function(e) {
                    e = e || {}, c.error(m, "get sms code error", "error code:%s,error msg:%s", e.code, e.msg), t.error(e), n()
                }
            })
        }).invoke()
    }
}(SFAPI);