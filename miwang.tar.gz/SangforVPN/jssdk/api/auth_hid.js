! function(e) {
    "use strict";
    var n = SFConfig,
        i = SFCommon,
        d = SFDTO,
        s = SFLOG,
        u = "api:auth_hid";
    e.loginHid = function loginHid(e, t) {
        new i.BaseAPI(e, t, function excuting(a, i) {
            SFRequest.createRequest({
                type: "Server",
                path: "/por/login_hid.csp?manual_submit=1",
                data: {
                    hid: a.hid || "",
                    hostname: a.hostName || "",
                    macaddress: a.macAddress || "",
                    ignore: 0
                },
                method: "post",
                success: function(e) {
                    var t, r, o = xmlToJSON.parseString(e);
                    (r = (t = d.authData(o)).code) === n.SUCCESS_CODE || r === n.NEXT_ACTION_CODE || r >= n.REDIRECT_URL_START_CODE && r < n.REDIRECT_URL_END_CODE || SFCustom.authResultFilter(r) ? (s.info(u, "login success by hardid"), a.success(t)) : (s.info(u, "login error by hardid,maybe need submit, error code: %s" + r), a.error(t)), i()
                },
                error: function(e) {
                    a.error(e), i()
                }
            })
        }).invoke()
    }, e.getHid = function getHid(e, t) {
        new SFCommon.BaseAPI(e, t, function excuting(r, o) {
            var e = i.getECCommand("Q_HID");
            SFRequest.createRequest({
                type: "ECAgent",
                path: "DoQueryService",
                data: [e],
                success: function(e) {
                    var t = i.handleData(e);
                    t.code === n.SUCCESS_CODE ? r.success(t) : r.error(t), o()
                },
                error: function(e) {
                    r.error(e), o()
                },
                ecVesionAdapter: function(e) {
                    var t = [];
                    if (s.info(u, "start converting Q_HID to standard !"), e && e.data) {
                        if (!e.data) return void s.error(u, "get hardid error", "data field of result is undefined");
                        if (is.number(e.data)) return void s.error(u, "get hardid error", "type field of result is number, number: " + e.data);
                        s.info(u, "current old data for hid:" + e.data), t = e.data.split("|"), e.data = {}, e.data.hid = "undefined" == typeof t[0] ? "" : t[0], e.data.macAddress = "undefined" == typeof t[1] ? "" : t[1], e.data.hostName = "undefined" == typeof t[2] ? "" : t[2]
                    }
                }
            })
        }).invoke()
    }, e.getHidConfig = function getHidConfig(e, t) {
        new i.BaseAPI(e, t, function excuting(o, a) {
            SFRequest.createRequest({
                type: "Server",
                path: "/por/hardid.csp?manual_submit=1",
                method: "get",
                success: function(e) {
                    var t = xmlToJSON.parseString(e),
                        r = i.getResult();
                    r.code = parseInt(t.Auth.ErrorCode, 0), r.code === n.SUCCESS_CODE ? (r.data = d.getHidConfigDTO(t.Auth), s.info(u, "get init config of hardid  success"), o.success(r)) : (s.error(u, "get init config of hardid  error", "type field of result is number, number: " + r.data), o.error(r)), a()
                },
                error: function(e) {
                    o.error(e), a()
                }
            })
        }).invoke()
    }, e.getAllHid = function getAllHid(e, t) {
        new SFCommon.BaseAPI(e, t, function excuting(r, o) {
            var e = i.getECCommand("Q_ALLHID");
            SFRequest.createRequest({
                type: "ECAgent",
                path: "DoQueryService",
                data: [e],
                success: function(e) {
                    var t = i.handleData(e);
                    t.code === n.SUCCESS_CODE ? r.success(t) : r.error(t), o()
                },
                error: function(e) {
                    r.error(e), o()
                },
                ecVesionAdapter: function(e) {
                    var t = [];
                    s.info(u, "start converting Q_ALLHID to standard !"), e && (s.info(u, "old data:" + e.data), t = e.data, e.data = {}, e.data.id = t)
                }
            })
        }).invoke()
    }, e.submitHid = function submitHid(e, t) {
        new i.BaseAPI(e, t, function excuting(a, i) {
            SFRequest.createRequest({
                type: "Server",
                path: "/por/submithid.csp",
                data: {
                    hid: a.hid || "",
                    hostname: a.hostName || "",
                    macaddress: a.macAddress || ""
                },
                method: "post",
                success: function(e) {
                    var t, r, o = xmlToJSON.parseString(e);
                    (r = (t = d.authData(o)).code) === n.SUCCESS_CODE || r === n.NEXT_ACTION_CODE || r >= n.REDIRECT_URL_START_CODE && r < n.REDIRECT_URL_END_CODE || SFCustom.authResultFilter(r) ? (s.info(u, "submit hardid success, storeCode:" + r), a.success(t)) : (s.error(u, "submit hardid error", "result error, code:" + r), a.error(t)), i()
                },
                error: function(e) {
                    a.error(e), i()
                }
            })
        }).invoke()
    }
}(SFAPI);