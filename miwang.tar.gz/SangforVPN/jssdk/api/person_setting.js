! function(e) {
    "use strict";
    var c = SFCommon,
        a = SFDTO,
        s = {};
    SFLOG;

    function translateData(e, t) {
        var n = e || {},
            o = xmlToJSON.parseString(n),
            r = {};
        return "Auth" === t && (r = o.Auth || {}), {
            code: parseInt(r.ErrorCode, 10),
            data: r
        }
    }
    e.getSettingConfig = function getSettingConfig(e, t) {
        new SFCommon.BaseAPI(e, t, function excuting(r, c) {
            SFRequest.createRequest({
                type: "Server",
                path: "/por/svpnSetting.csp",
                method: "get",
                success: function(e) {
                    var t, n = translateData(e, "Auth"),
                        o = {};
                    o.code = n.code, t = a.getSettingConfigDTO(n.data), o.data = t, 1 === n.code ? r.success(o) : r.error(o), c()
                },
                error: function(e) {
                    r.error(e), c()
                }
            })
        }).invoke()
    }, e.getAccountData = function getAccountData(e, t) {
        new SFCommon.BaseAPI(e, t, function excuting(r, c) {
            SFRequest.createRequest({
                type: "Server",
                path: "/por/perinfo.csp",
                method: "get",
                data: {
                    apitype: r.apitype
                },
                success: function(e) {
                    var t = translateData(e, "Auth"),
                        n = a.getAccountDataDTO(t.data),
                        o = {
                            code: t.code,
                            data: n
                        };
                    1 === t.code ? r.success(o) : r.error(o), c()
                },
                error: function(e) {
                    r.error(e), c()
                }
            })
        }).invoke()
    }, e.getSSOData = function getSSOData(e, t) {
        new SFCommon.BaseAPI(e, t, function excuting(r, c) {
            SFRequest.createRequest({
                type: "Server",
                path: "/por/perssoinfo.csp",
                method: "get",
                success: function(e) {
                    var t, n = translateData(e, "Auth"),
                        o = {};
                    o.code = n.code, t = a.getSSODataDTO(n.data), o.data = t, 1 === o.code ? r.success(o) : r.error(o), c()
                },
                error: function(e) {
                    r.error(e), c()
                }
            })
        }).invoke()
    }, e.getHidData = function getHidData(e, t) {
        new SFCommon.BaseAPI(e, t, function excuting(t, n) {
            SFAPI.getHid({
                success: function(e) {
                    s.cur = e.data,
                        function getListData(o, r) {
                            var c = {};
                            SFRequest.createRequest({
                                type: "Server",
                                path: "/por/general.csp",
                                method: "get",
                                success: function(e) {
                                    var t, n = translateData(e, "Auth");
                                    c.code = n.code, t = a.getListDataDTO(n.data), s.list = t, c.data = {
                                        cur: s.cur || {},
                                        list: s.list || []
                                    }, 1 === c.code ? o.success(c) : o.error(c), r()
                                },
                                error: function(e) {
                                    o.error(e), r()
                                }
                            })
                        }(t, n)
                },
                error: function(e) {
                    t.error(e), n()
                }
            })
        }).invoke()
    }, e.setAcountPsw = function setAcountPsw(e, t) {
        var n = new SFCommon.BaseAPI(e, t, function excuting(o, r) {
                SFRequest.createRequest({
                    type: "Server",
                    path: "/por/changepwd.csp?cknote=0",
                    data: c,
                    method: "post",
                    success: function(e) {
                        var t = translateData(e, "Auth"),
                            n = t.data.PswMask || "";
                        t.data = {}, t.data.pswMask = n, 1 === t.code ? o.success(t) : o.error(t), r()
                    },
                    error: function(e) {
                        o.error(e), r()
                    }
                })
            }),
            c = {
                pripsw: e.pripsw,
                newpsw: e.newpsw,
                svpn_req_randcode: e.svpn_req_randcode,
                apitype: e.apitype
            };
        n.invoke()
    }, e.setAcountTel = function setAcountTel(e, t) {
        var n = new SFCommon.BaseAPI(e, t, function excuting(n, o) {
                SFRequest.createRequest({
                    type: "Server",
                    path: "/por/changetelnum.csp",
                    data: r,
                    method: "post",
                    success: function(e) {
                        var t = parseInt(e, 10);
                        0 === t ? n.success(t) : n.error(t), o()
                    },
                    error: function(e) {
                        n.error(e), o()
                    }
                })
            }),
            r = {
                newtel: e.newTel,
                userRandCode: e.userRandCode
            };
        n.invoke()
    }, e.setAcountDesc = function setAcountDesc(e, t) {
        var n = new SFCommon.BaseAPI(e, t, function excuting(n, o) {
                SFRequest.createRequest({
                    type: "Server",
                    path: "/por/changepwd.csp?cknote=1",
                    data: r,
                    method: "get",
                    success: function(e) {
                        var t = translateData(e, "Auth");
                        1 === t.code ? n.success(t) : n.error(t), o()
                    },
                    error: function(e) {
                        n.error(e), o()
                    }
                })
            }),
            r = {
                newnote: e.newNote
            };
        n.invoke()
    }, e.setPin = function setPin(e, t) {
        var n = new SFCommon.BaseAPI(e, t, function excuting(n, o) {
                SFRequest.createRequest({
                    type: "ECAgent",
                    path: "DoConfigure",
                    data: [r],
                    method: "get",
                    success: function(e) {
                        var t = c.handleData(e);
                        0 === t.code ? n.success(t) : n.error(t), o()
                    },
                    error: function(e) {
                        n.error(e), o()
                    }
                })
            }),
            r = "CONF SETTING PIN oldpin=" + Base64.encode(e.oldPin) + "&amp;newpin=" + Base64.encode(e.newPin);
        n.invoke()
    }, e.setSSOAccount = function setSSOAccount(e, t) {
        new SFCommon.BaseAPI(e, t, function excuting(t, n) {
            SFRequest.createRequest({
                type: "Server",
                path: "/por/chgSsoInfo.csp",
                data: t.postData,
                method: "post",
                success: function(e) {
                    t.success(e), n()
                },
                error: function(e) {
                    t.error(e), n()
                }
            })
        }).invoke()
    }, e.getpswPolicy = function getpswPolicy(e, t) {
        new SFCommon.BaseAPI(e, t, function excuting(n, o) {
            SFRequest.createRequest({
                type: "Server",
                path: "/public/psw_policy",
                method: "get",
                success: function(e) {
                    var t = translateData(e, "Auth");
                    1 === t.code ? n.success(t) : n.error(t), o()
                },
                error: function(e) {
                    n.error(e), o()
                }
            })
        }).invoke()
    }
}(SFAPI);