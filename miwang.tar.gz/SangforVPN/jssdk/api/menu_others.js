! function(e) {
    "use strict";
    var o = SFCommon,
        c = SFLOG;
    e.getLinkInfo = function getLinkInfo(e, t) {
        new o.BaseAPI(e, t, function excuting(n, r) {
            var e = o.getECCommand("Q_LINKINFO");
            SFRequest.createRequest({
                type: "ECAgent",
                path: "DoQueryService",
                method: "get",
                data: [e],
                success: function(e) {
                    var t = o.handleData(e);
                    1 === t.code ? n.success(t) : (c.error("api: menu_others", "get connect state info error", "query link info over max times or query link fail"), n.error(t), r())
                },
                error: function(e) {
                    n.error(e), r()
                }
            })
        }).invoke()
    }, e.getCurMsg = function getCurMsg(e, t) {
        new o.BaseAPI(e, t, function excuting(n, r) {
            var e = o.getECCommand("Q_CUR_MSG");
            SFRequest.createRequest({
                type: "ECAgent",
                path: "DoQueryService",
                method: "get",
                conCount: n.conCount,
                data: [e],
                success: function(e) {
                    var t = o.handleData(e);
                    t && 1 === t.code && t.data ? n.success(t) : (n.error(e), r())
                },
                error: function(e) {
                    n.error(e), r()
                }
            })
        }).invoke()
    }, e.getHistoryMsg = function getHistoryMsg(e, t) {
        new o.BaseAPI(e, t, function excuting(n, t) {
            var e = o.getECCommand("Q_HIS_MSG");
            SFRequest.createRequest({
                type: "ECAgent",
                path: "DoQueryService",
                method: "get",
                data: [e],
                success: function(e) {
                    var t = o.handleData(e);
                    1 === t.code ? n.success(t) : n.error(t)
                },
                error: function(e) {
                    n.error(e), t()
                }
            })
        }).invoke()
    }, e.getECMenu = function getECMenu(e, t) {
        new o.BaseAPI(e, t, function excuting(n, r) {
            var e = o.getECCommand("Q_MENU");
            SFRequest.createRequest({
                type: "ECAgent",
                path: "DoQueryService",
                method: "get",
                data: [e],
                success: function(e) {
                    var t = o.handleData(e);
                    1 === t.code ? n.success(t) : n.error(t), r()
                },
                error: function(e) {
                    n.error(e), r()
                }
            })
        }).invoke()
    }, e.ShowPrintJobs = function ShowPrintJobs(e, t) {
        new o.BaseAPI(e, t, function excuting(n, r) {
            SFRequest.createRequest({
                type: "ECAgent",
                path: "ShowPrintJobs",
                success: function(e) {
                    var t = o.handleData(e);
                    1 === t.code ? n.success(t) : n.error(t), r()
                },
                error: function(e) {
                    n.error(e), r()
                }
            })
        }).invoke()
    }, e.getAccEffect = function getAccEffect(e, t) {
        new o.BaseAPI(e, t, function excuting(t, n) {
            var e = o.getECCommand("Q_FLOWSTAT");
            SFRequest.createRequest({
                type: "ECAgent",
                path: "DoQueryService",
                method: "get",
                data: [e],
                resultFilter: function(e) {
                    return !0
                },
                success: function(e) {
                    o.checkObjAttrExits(e, "result") && is.numeric(e.result) && parseInt(e.result, 10) === ERROR_EC_LOGOUT_STATUS ? (e.code = ERROR_EC_LOGOUT_STATUS, t.error(e)) : t.success(e)
                },
                error: function(e) {
                    t.error(e), n()
                }
            })
        }).invoke()
    }
}(SFAPI);