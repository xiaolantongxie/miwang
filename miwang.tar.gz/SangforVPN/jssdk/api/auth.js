! function(a) {
    "use strict";
    var i = SFConfig,
        c = SFCommon,
        u = SFDTO,
        d = SFLOG,
        g = "api:common:auth";
    a.loginToken = function loginToken(e, o) {
        new c.BaseAPI(e, o, function excuting(t, s) {
            SFRequest.createRequest({
                type: "Server",
                path: "/por/login_token.csp",
                data: {
                    svpn_inputtoken: t.token || ""
                },
                method: "post",
                success: function(e) {
                    var o, r, n = xmlToJSON.parseString(e);
                    (r = (o = u.authData(n)).code) === i.SUCCESS_CODE || r === i.NEXT_ACTION_CODE || r >= i.REDIRECT_URL_START_CODE && r < i.REDIRECT_URL_END_CODE ? t.success(o) : t.error(o), s()
                },
                error: function(e) {
                    e = e || {}, t.error(e), d.error(g, "login token error", "error code:%s,error msg:%s", e.code, e.msg), s()
                }
            })
        }).invoke()
    }, a.loginRadius = function loginRadius(e, o) {
        new c.BaseAPI(e, o, function excuting(t, s) {
            SFRequest.createRequest({
                type: "Server",
                path: "/por/login_radius.csp",
                data: {
                    svpn_inputradius: t.answer || ""
                },
                method: "post",
                success: function(e) {
                    var o, r, n = xmlToJSON.parseString(e);
                    (r = (o = u.authData(n)).code) === i.SUCCESS_CODE || r === i.NEXT_ACTION_CODE || r >= i.REDIRECT_URL_START_CODE && r < i.REDIRECT_URL_END_CODE ? (d.info(g, "login radius request success"), t.success(o)) : (d.info(g, "login radius request success", " request not return expected result, result is " + JSON.stringify(e)), t.error(o)), s()
                },
                error: function(e) {
                    e = e || {}, t.error(e), d.error(g, "login radius error", "error code:%s,error msg:%s", e.code, e.msg), s()
                }
            })
        }).invoke()
    }, a.getRandCode = function getRandCode(e, o) {
        new c.BaseAPI(e, o, function excuting(e, o) {
            var r;
            r = {
                code: 1,
                data: {
                    url: SF.setting.getGlobal(KEY_GLOBAL_VPN_URL, "") + "/por/rand_code.csp?rnd=" + Math.random()
                }
            }, e.success(r), o()
        }).invoke()
    }, a.loginDomain = function loginDomain(e, o) {
        new c.BaseAPI(e, o, function excuting(t, s) {
            var e = SF.setting.getGlobal(KEY_GLOBAL_TWFID, ""),
                o = t.domainSSOUrl;
            SFRequest.createRequest({
                type: "ECAgent",
                path: "DomainSsoAuth",
                timeout: 13e4,
                conCount: -1,
                data: [o, e],
                success: function(e) {
                    var o, r, n = c.handleData(e);
                    n.code === i.SUCCESS_CODE || n.code === i.NEXT_ACTION_CODE ? (d.info(g, "login domain success"), o = xmlToJSON.parseString(n.data), r = u.authData(o), a.handleAuthResult(t, r, s, !0)) : (d.info(g, "login domain failed,code is %s", n.code), n.data = {}, t.error(n)), s()
                },
                error: function(e) {
                    e = e || {}, d.error(g, "login domain error", "error code:%s,error msg:%s", e.code, e.msg), t.error(e), s()
                }
            })
        }).invoke()
    }, a.checkDomain = function checkDomain(e, o) {
        new c.BaseAPI(e, o, function excuting(r, n) {
            var e = c.getECCommand("Q_DOMAIN");
            SFRequest.createRequest({
                type: "ECAgent",
                path: "DoQueryService",
                data: [e],
                success: function(e) {
                    var o = c.handleData(e);
                    d.info(g, "request api(checkDomain) success,data:" + JSON.stringify(e)), o.code === i.SUCCESS_CODE ? r.success(o) : r.error(o), n()
                },
                error: function(e) {
                    e = e || {}, r.error(e), d.error(g, "check domain error", "error code:%s,error msg:%s", e.code, e.msg), n()
                }
            })
        }, "checkDomain").invoke()
    }
}(SFAPI);