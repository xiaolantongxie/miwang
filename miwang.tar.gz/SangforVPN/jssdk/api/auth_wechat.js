! function(e) {
    "use strict";
    var s = SFConfig,
        i = SFCommon,
        n = SFDTO,
        a = SFLOG,
        d = "api:auth_wechat";
    e.loginWechat = function loginWechat(e, t) {
        if (!e.data.state) return a.error(d, "state is null", "state params error or is input null"), void e.error(tr("State不正确，请刷新后重试"));
        new i.BaseAPI(e, t, function excuting(c, o) {
            SFRequest.createRequest({
                type: "Server",
                path: "/auth/wechat",
                data: {
                    state: c.data.state,
                    bindState: c.data.bindState || "binded"
                },
                method: "post",
                success: function(e) {
                    var t, a, r = xmlToJSON.parseString(e);
                    a = (t = n.authData(r)).code, t.data.ErrMsg = i.getMessage(a, e), t.WechatImageUrl = r.Auth.WechatImageUrl || "", t.WechatUserName = r.Auth.WechatUserName || "", a === s.SUCCESS_CODE || a === s.NEXT_ACTION_CODE ? c.success(t) : c.error(t), o()
                },
                error: function(e) {
                    e = e || {}, a.error(d, "login wechat error", "%s & %s", e.code, e.msg), c.error(e), o()
                }
            })
        }).invoke()
    }, e.getWechatConfig = function getWechatConfig(e, t) {
        new i.BaseAPI(e, t, function executing(r, c) {
            SFRequest.createRequest({
                type: "Server",
                path: "/public/wechat_info",
                data: {},
                method: "post",
                success: function(e) {
                    var t, a = xmlToJSON.parseString(e);
                    (t = n.authOtherData(a, "getWechatConfig")).data.State = t.data.NextServiceData.State ? t.data.NextServiceData.State : "", t.data.Appid = t.data.NextServiceData.Appid ? t.data.NextServiceData.Appid : "", t.data.RedirectUrl = t.data.NextServiceData.RedirectUrl ? t.data.NextServiceData.RedirectUrl : "", t.data.StyleUrl = t.data.NextServiceData.StyleUrl ? t.data.NextServiceData.StyleUrl : "", t.data.Timeout = t.data.NextServiceData.Timeout ? t.data.NextServiceData.Timeout : 180, t.data.ErrMsg = i.getMessage(t.code, e), t.code === s.SUCCESS_CODE ? r.success(t) : r.error(t), c()
                },
                error: function(e) {
                    e = e || {}, a.error(d, "get wechat config error", "%s & %s", e.code, e.msg), r.error(e), c()
                }
            })
        }).invoke()
    }, e.getWechatAuthDetail = function getWechatAuthDetail(e, t) {
        e.data.code || a.error(d, "code is null", "state params error or is input null"), new i.BaseAPI(e, t, function executing(r, c) {
            SFRequest.createRequest({
                type: "Server",
                path: "/public/wechat_oauth2",
                data: {
                    code: r.data.code,
                    state: r.data.state
                },
                method: "post",
                success: function(e) {
                    var t, a = xmlToJSON.parseString(e);
                    (t = n.authOtherData(a)).BindState = a.Auth.BindState, t.Note = a.Auth.Note, t.WechatImageUrl = a.Auth.WechatImageUrl, t.WechatUserName = a.Auth.WechatUserName, t.data.ErrMsg = i.getMessage(t.code, e), t.code === s.SUCCESS_CODE ? r.success(t) : r.error(t), c()
                },
                error: function(e) {
                    e = e || {}, a.error(d, "get wechat config error", "%s & %s", e.code, e.msg), r.error(e), c()
                }
            })
        }).invoke()
    }
}(SFAPI);