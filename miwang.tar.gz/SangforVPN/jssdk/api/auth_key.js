! function(i) {
    "use strict";
    SFConfig;
    var c = SFCommon,
        a = SFDTO,
        u = SFLOG,
        d = "api:auth_key";
    i.loginKey = function loginKey(e, r) {
        new c.BaseAPI(e, r, function excuting(n, s) {
            var e, r = c.getResult(),
                t = SF.setting.getGlobal(KEY_GLOBAL_TWFID, "0");
            if (n.pin = Base64.encode(n.pin) || "", n.type = n.type || 2, 2 === n.type) e = "NdKeyAuth";
            else if (4 === n.type) e = "GmKeyAuth";
            else if (3 !== n.type) return u.error(d, "login key error", "get key type  error，type is %s", n.type), void n.error(r);
            SFRequest.createRequest({
                type: "ECAgent",
                path: e,
                data: [n.pin, t],
                method: "post",
                success: function(e) {
                    var r, t, o = c.handleData(e);
                    1 === o.code ? (r = xmlToJSON.parseString(o.data), t = a.authData(r), i.handleAuthResult({
                        success: function() {
                            n.success(t)
                        },
                        error: function() {
                            u.error(d, "login key error", "parse xml error,error code is %s", o.code), n.error(t)
                        }
                    }, t, s, !0)) : (u.debug(d, "login key error", "EC query failed，error code is " + o.code), o.data = {}, n.error(o)), s()
                },
                error: function(e) {
                    u.error(d, "login key error", "request model return failed, error code is %s", e.code), n.error(e), s()
                }
            })
        }).invoke()
    }, i.detectKey = function detectKey(e, r) {
        new c.BaseAPI(e, r, function excuting(t, r) {
            var e;
            c.getResult(), e = c.getECCommand("Q_DETECT_KEY"), SFRequest.createRequest({
                type: "ECAgent",
                path: "DoQueryService",
                data: [e],
                success: function(e) {
                    var r = c.handleData(e);
                    t.success(r)
                },
                error: function(e) {
                    u.error(d, "detect key error", "request model return failed, error code is " + e.code), t.error(e), r()
                }
            })
        }).invoke()
    }
}(SFAPI);