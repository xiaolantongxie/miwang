! function(c) {
    "use strict";
    var u, p, g = SFConfig,
        _ = SFCommon,
        m = SFDTO,
        f = SFLOG,
        l = "api:auth_psw";
    c.getPswConfig = function getPswConfig(e, r) {
        f.debug(l, "get init Config of psw from server called"), new _.BaseAPI(e, r, function excuting(s, o) {
            SFRequest.createRequest({
                type: "Server",
                path: "/public/psw_config",
                method: "get",
                success: function(e) {
                    var r, t = xmlToJSON.parseString(e);
                    f.debug(l, "get init Config of psw from server success"), r = m.authOtherData(t, "getPswConfig"), SF.setting.setGlobal({
                        key: KEY_GLOBAL_ENCRYPT_EXP,
                        value: r.data.encryptExp
                    }, 0), SF.setting.setGlobal({
                        key: KEY_GLOBAL_ENCRYPT_KEY,
                        value: r.data.encryptKey
                    }, 0), SF.setting.setGlobal({
                        key: KEY_GLOBAL_CSRF_RAND_CODE,
                        value: r.data.csrfRandCode
                    }, !1), p = r.data.enableMidAtkCheck, "" === u && f.warn(l, "get init Config of psw from server request success", "data.csrfRandCode is empty!"), r.code === g.SUCCESS_CODE ? s.success(r) : s.error(r), o()
                },
                error: function(e) {
                    e = e || {}, f.error(l, "get init Config of psw from server  error", "error code:%s,error msg:%s", e.code, e.msg), s.error(e), o()
                }
            })
        }).invoke()
    }, c.loginPsw = function loginPsw(e, r) {
        var d = is.Win();
        new _.BaseAPI(e, r, function excuting(r, o) {
            var e, t, s, n, a, i = "Anonymous";

            function authLoginPwd(s, e) {
                SFRequest.createRequest({
                    type: "Server",
                    path: "/por/login_psw.csp?anti_replay=1&encrypt=1",
                    data: e,
                    method: "post",
                    preventOnError: s.preventOnError,
                    timeout: 6e4,
                    success: function(e) {
                        var r, t = xmlToJSON.parseString(e);
                        (r = m.authData(t)).code, SF.setting.setGlobal({
                            key: KEY_GLOBAL_CSRF_RAND_CODE,
                            value: r.data.csrfRandCode
                        }, !1), c.handleAuthResult(s, r, o)
                    },
                    error: function(e) {
                        e = e || {}, f.error(l, "auth psw error", "error code:%s,error msg:%s", e.code, e.msg), s.error(e), o()
                    }
                })
            }
            e = r.userName || "", u = SF.setting.getGlobal(KEY_GLOBAL_CSRF_RAND_CODE, ""), e || f.warn(l, "username is null", "params error or no input"), u ? t = _.encryptID({
                id: r.password,
                type: g.ENCRYPT_TYPE_PSW,
                extraCode: u
            }) : (f.warn(l, "No csrfRandCode, not encrypt password", "params error or params not save"), t = r.password), p = p || 0, n = (s = r.randCode || "") ? hex_md5(s) : s, p && d && g.isExistEC && e !== i ? (a = {
                mitm_result: "",
                svpn_req_randcode: u,
                svpn_name: e,
                svpn_password: "",
                svpn_rand_code: n
            }, c.getMidAttackResult({
                userName: e,
                password: t,
                randCode: s,
                success: function(e) {
                    f.info(l, "get middle Attack result from ECAgent success"), e.data && e.data.key && (a.mitm_result = e.data.key), authLoginPwd(r, a)
                },
                error: function(e) {
                    e = e || {}, f.error(l, "get middle Attack result from ECAgent error", "error code:%s,error msg:%s", e.code, e.msg)
                }
            })) : (s = e !== i ? s : "", f.info(l, "MidAtkCheck not enabled"), authLoginPwd(r, a = {
                mitm_result: "",
                svpn_req_randcode: u,
                svpn_name: e,
                svpn_password: t,
                svpn_rand_code: s
            }))
        }).invoke()
    }
}(SFAPI);