! function(e) {
    "use strict";
    var u = SFCommon,
        a = {},
        c = SFDTO,
        s = SFLOG,
        i = (SFConfig, "api: system_settings");
    e.getPrefSetting = function getPrefSetting(e, t) {
        var n, r = new SFCommon.BaseAPI(e, t, function excuting(r, o) {
                SFRequest.createRequest({
                    type: "ECAgent",
                    path: "DoQueryService",
                    method: "get",
                    data: [a],
                    success: function(e) {
                        var t = u.handleData(e);
                        1 === t.code ? (n = t.data ? t.data : {}, r.success(n)) : (s.error(i, "get preference setting error", " error is %", u.getMessage(e.code)), r.error(t)), o()
                    },
                    error: function(e) {
                        s.error(i, "get preference setting error", " error is %", u.getMessage(e.code)), r.error(e), o()
                    }
                })
            }),
            a = u.getECCommand("Q_PREFSETTING");
        r.invoke()
    }, e.getResourceInfo = function getResourceInfo(e, t) {
        var n, r = new SFCommon.BaseAPI(e, t, function excuting(r, o) {
                SFRequest.createRequest({
                    type: "ECAgent",
                    path: "DoQueryService",
                    method: "get",
                    data: [a],
                    success: function(e) {
                        var t = u.handleData(e);
                        1 === t.code ? (n = t.data && t.data.res ? t.data.res : {}, r.success(n)) : (s.error(i, "get resource info error", " network request success,but api return error result "), r.error(t)), o()
                    },
                    error: function(e) {
                        s.error(i, "get resource info error", " error is %", u.getMessage(e.code)), r.error(e), o()
                    }
                })
            }),
            a = u.getECCommand("Q_RES_PATH");
        r.invoke()
    }, e.getRemoteApp = function getRemoteApp(e, t) {
        var n, r = new SFCommon.BaseAPI(e, t, function excuting(r, o) {
                SFRequest.createRequest({
                    type: "ECAgent",
                    path: "DoQueryService",
                    method: "get",
                    data: [a],
                    success: function(e) {
                        var t = u.handleData(e);
                        1 === t.code ? (n = t.data ? t.data : {}, r.success(n)) : (s.error(i, "get remote app error", " network request success,but api return error result "), r.error(t)), o()
                    },
                    error: function(e) {
                        s.error(i, "get remote app error", " error is %", u.getMessage(e.code)), r.error(e), o()
                    }
                })
            }),
            a = u.getECCommand("Q_RAPPCONF");
        r.invoke()
    }, e.getScacheData = function getScacheData(e, t) {
        var r = new SFCommon.BaseAPI(e, t, function excuting(r, o) {
                SFRequest.createRequest({
                    type: "ECAgent",
                    path: "DoQueryService",
                    method: "get",
                    data: [n, r.svpnID],
                    success: function(e) {
                        var t = u.handleData(e);
                        1 !== t.code ? r.error(t) : (a.scache = t.data ? t.data : {}, r.success(a)), o()
                    },
                    error: function(e) {
                        r.error(e), o()
                    },
                    ecVesionAdapter: function(e) {
                        s.info(i, "queryData: start converting Q_SCACHE res to standard !"), e && (s.info(i, "queryData: old data:" + e.data), e.data = u.urlToJson(e.data))
                    }
                })
            }),
            n = u.getECCommand("Q_SCACHE");
        r.invoke()
    }, e.getScacheConfig = function getScacheConfig(e, t) {
        new SFCommon.BaseAPI(e, t, function excuting(n, t) {
            SFRequest.createRequest({
                type: "Server",
                path: "/por/setAccelerate.csp",
                method: "get",
                success: function(e) {
                    var t = function translateData(e, t) {
                            var r = e || {},
                                o = xmlToJSON.parseString(r),
                                n = {};
                            return "Auth" === t && (n = o.Auth), {
                                code: parseInt(n.ErrorCode, 10),
                                data: n
                            }
                        }(e, "Auth"),
                        r = c.getScacheConfigDTO(t.data),
                        o = {
                            code: t.code,
                            data: r
                        };
                    1 === t.code ? n.success(o) : n.error(o)
                },
                error: function(e) {
                    s.error(i, "get config of scache error", " error is %s ", u.getMessage(e.code)), n.error(e), t()
                }
            })
        }).invoke()
    }, e.clearCache = function clearCache(e, t) {
        var r = new SFCommon.BaseAPI(e, t, function excuting(r, o) {
                SFRequest.createRequest({
                    type: "ECAgent",
                    path: "DoConfigure",
                    method: "get",
                    data: [n],
                    success: function(e) {
                        var t = u.handleData(e);
                        1 === t.code ? r.success(t) : r.error(t), o()
                    },
                    error: function(e) {
                        r.error(e), o()
                    }
                })
            }),
            n = u.getECCommand("C_CLEAN_CACHE");
        r.invoke()
    }, e.setPrefSetting = function setPrefSetting(e, t) {
        var r = new SFCommon.BaseAPI(e, t, function excuting(r, o) {
                SFRequest.createRequest({
                    type: "ECAgent",
                    path: "DoConfigure",
                    method: "get",
                    data: [a, JSON.stringify(n)],
                    success: function(e) {
                        var t = u.handleData(e);
                        1 === t.code ? r.success(t) : r.error(t), o()
                    },
                    error: function(e) {
                        r.error(e), o()
                    }
                })
            }),
            n = e.pref,
            a = u.getECCommand("C_PREFSETTING");
        r.invoke()
    }, e.setResourceInfo = function setResourceInfo(e, t) {
        var n, a, r = new SFCommon.BaseAPI(e, t, function excuting(r, o) {
                for (a = 0; a < c.length / 2; a++) n = u.getECCommand("C_RES_PATH"), SFRequest.createRequest({
                    type: "ECAgent",
                    path: "DoConfigure",
                    method: "get",
                    data: [n, JSON.stringify({
                        res: [{
                            id: c[a].id,
                            name: c[a].name,
                            path: Base64.encode(c[a].path)
                        }]
                    })],
                    success: function(e) {
                        var t = u.handleData(e);
                        s++, 1 === t.code && s === c.length / 2 && (r.success(t), o()), 0 === t.code && (r.error(t), o())
                    },
                    error: function(e) {
                        r.error(e), o()
                    }
                })
            }),
            c = e.res || [],
            s = 0;
        r.invoke()
    }, e.setRemoteApp = function setRemoteApp(e, t) {
        var r = new SFCommon.BaseAPI(e, t, function excuting(r, o) {
                SFRequest.createRequest({
                    type: "ECAgent",
                    path: "DoConfigure",
                    method: "get",
                    data: [a, JSON.stringify(n)],
                    success: function(e) {
                        var t = u.handleData(e);
                        1 === t.code ? r.success(t) : r.error(t), o()
                    },
                    error: function(e) {
                        r.error(e), o()
                    }
                })
            }),
            n = e.rmt,
            a = u.getECCommand("C_RAPPCONF");
        r.invoke()
    }, e.setScacheData = function setScacheData(e, t) {
        var r = new SFCommon.BaseAPI(e, t, function excuting(r, o) {
                SFRequest.createRequest({
                    type: "ECAgent",
                    path: "DoConfigure",
                    method: "get",
                    data: [a, JSON.stringify(n)],
                    success: function(e) {
                        var t = u.handleData(e);
                        1 === t.code ? r.success(t) : r.error(t), o()
                    },
                    error: function(e) {
                        r.error(e), o()
                    }
                })
            }),
            n = e.scache,
            a = u.getECCommand("C_SCACHE");
        r.invoke()
    }
}(SFAPI);