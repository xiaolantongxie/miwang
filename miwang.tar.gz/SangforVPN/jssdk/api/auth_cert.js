! function(i) {
    "use strict";
    var n = SFConfig,
        a = SFCommon,
        u = SFDTO,
        f = SFLOG,
        o = 3e5,
        d = "api:auth_cert";
    i.loginCert = function loginCert(e, t) {
        new a.BaseAPI(e, t, function excuting(e, t) {
            n.isExistEC ? function loginCertByECAgent(c, s) {
                var e, t, r;
                e = c.index || 0, t = c.certName || "", r = SF.setting.getGlobal(KEY_GLOBAL_TWFID, ""), SFRequest.createRequest({
                    type: "ECAgent",
                    path: "CertAuth",
                    data: [e, t, r],
                    method: "post",
                    timeout: o,
                    success: function(e) {
                        var t, r, o = a.handleData(e);
                        o.code === n.SUCCESS_CODE ? (f.info(d, "login certificate by ECAgent success,code is %s", o.code), t = xmlToJSON.parseString(o.data), r = u.authData(t), i.handleAuthResult(c, r, s, !0)) : (f.info(d, "login certificate by ECAgent failed,code is %s", o.code), o.data = {}, c.error(o)), s()
                    },
                    error: function(e) {
                        f.error(d, "login certificate by ECAgent error", "request return failed, code is %s", e.code), c.error(e), s()
                    }
                })
            }(e, t) : function loginCertByServer(c, s) {
                SFRequest.createRequest({
                    type: "Server",
                    path: "/por/login_cert.csp",
                    method: "post",
                    timeout: o,
                    success: function(e) {
                        a.getResult();
                        var t, r, o = xmlToJSON.parseString(e);
                        t = u.authData(o), (r = t.code) === n.SUCCESS_CODE || r === n.NEXT_ACTION_CODE || r >= n.REDIRECT_URL_START_CODE && r < REDIRECT_URL_END_CODE ? (f.info(d, "login certificate by server success, code is: " + r), c.success(t)) : (f.info(d, "login certificate by server failed, error code is" + r), c.error(t)), s()
                    },
                    error: function(e) {
                        f.error(d, "login certificate by server error", "request model return failed, code is %s", e.code), c.error(e), s()
                    }
                })
            }(e, t)
        }).invoke()
    }, i.getCertList = function getCertList(e, t) {
        new a.BaseAPI(e, t, function excuting(r, o) {
            SFRequest.createRequest({
                type: "ECAgent",
                path: "GetCertificates",
                success: function(e) {
                    var t = a.handleData(e);
                    t.code === n.SUCCESS_CODE ? (f.info(d, "get certificate list success"), r.success(t)) : (f.info(d, "get certificate list failed,res:" + JSON.stringify(e)), r.error(t)), o()
                },
                error: function(e) {
                    e = e || {}, f.error(d, "get certificate list error", "data:%s & %s", e.code, e.msg), r.error(e), o()
                }
            })
        }, "getCertList").invoke()
    }, i.getSelectedPath = function getSelectedPath(e, t) {
        new a.BaseAPI(e, t, function excuting(o, c) {
            var t = o.id || "",
                e = o.filter || "*";

            function setTimePath() {
                var e = a.getECCommand("Q_SELECTPATH", {
                    id: t
                });
                SFRequest.createRequest({
                    type: "ECAgent",
                    path: "DoQueryService",
                    data: [e],
                    success: function(e) {
                        var t, r = a.handleData(e);
                        t = r.data.path, 1 === r.code && !is.empty(t) || 2 === r.code ? (f.info(d, "get path success, path:" + t), o.success(r), c()) : 1 !== r.code ? (o.error(r), c()) : setTimeout(setTimePath, 1e3)
                    },
                    error: function(e) {
                        e = e || {}, f.warn(d, "get path error", "error code:%s, error msg:%s", e.code, e.msg), o.error(e), c()
                    }
                })
            }
            SFRequest.createRequest({
                type: "ECAgent",
                path: "SelectFilePath",
                data: [t, e],
                success: function(e) {
                    e.result && "1" === e.result ? setTimePath() : o.error(e), c()
                },
                error: function(e) {
                    e = e || {}, f.warn(d, "get selected path from ECAgent error", "error code:%s , error msg: %s", e.code, e.msg), o.error(e), c()
                }
            })
        }).invoke()
    }, i.importCert = function importCert(e, t) {
        new a.BaseAPI(e, t, function excuting(r, o) {
            var e, t;
            e = Base64.encode(r.path) || "", t = Base64.encode(r.psw) || "", SFRequest.createRequest({
                type: "ECAgent",
                path: "ImportCert",
                data: [e, t],
                success: function(e) {
                    var t = a.handleData(e);
                    1 === t.code ? r.success(t) : r.error(t), o()
                },
                error: function(e) {
                    f.error(d, "import certificate error", "res:" + JSON.stringify(e)), r.error(e), o()
                }
            })
        }).invoke()
    }, i.removeCert = function removeCert(e, t) {
        new a.BaseAPI(e, t, function excuting(r, o) {
            SFRequest.createRequest({
                type: "ECAgent",
                path: "RemoveCert",
                data: [r.certName, r.certIndex],
                success: function(e) {
                    var t = a.handleData(e);
                    t.code === n.SUCCESS_CODE ? (f.info(d, "remove certificate success"), r.success(t)) : (f.info(d, "remove certificate failed,code:" + t.code), r.error(t)), o()
                },
                error: function(e) {
                    e = e || {}, f.error(d, "remove certificate error", "data:%s & %s", e.code, e.msg), r.error(e), o()
                }
            })
        }, "removeCert").invoke()
    }
}(SFAPI);