var SFConfig = {},
    SFCommon = {},
    SFAPI = {},
    SFFilter = {},
    SFRequest = {},
    SFDTO = {},
    SFLOG = {},
    SFCustom = {},
    SF = {
        ecConfig: {},
        setting: {},
        windowMgr: {},
        vpnInfo: {},
        session: {}
    };