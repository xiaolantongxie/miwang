! function(s) {
    "use strict";
    var t, e = SFConfig;

    function refreshFilter() {
        var s, i = function getAPICondition() {
            return {
                selectLines: {
                    res: e.isExistEC
                },
                initECAgent: {
                    res: e.isExistEC
                },
                setLang: {
                    res: e.isExistEC
                },
                checkReLogin: {
                    res: e.isExistEC,
                    def: {
                        code: 0,
                        data: {}
                    }
                },
                checkUpdate: {
                    res: e.isExistEC
                },
                getECLoginConfig: {
                    res: e.isExistEC && e.container !== e.CLIENT_TYPE.WEB
                },
                setECLoginConfig: {
                    res: e.isExistEC && e.container !== e.CLIENT_TYPE.WEB
                },
                getVPNList: {
                    res: e.isExistEC && e.container !== e.CLIENT_TYPE.WEB
                },
                updateControl: {
                    res: e.isExistEC && is.Win()
                },
                checkSecurity: {
                    res: e.isExistEC && !is.Linux && !is.System().isMobile
                },
                checkProxy: {
                    res: e.isExistEC
                },
                testProxy: {
                    res: e.isExistEC
                },
                getLoginProxy: {
                    res: e.isExistEC
                },
                setLoginProxy: {
                    res: e.isExistEC
                },
                checkMidAttack: {
                    res: e.isExistEC && is.Win(),
                    def: {
                        code: 0,
                        data: {}
                    }
                },
                getMidAttackResult: {
                    res: e.isExistEC && is.Win()
                },
                getCertList: {
                    res: e.isExistEC
                },
                importCert: {
                    res: e.isExistEC
                },
                loginDKey: {
                    res: e.isExistEC
                },
                detectDKey: {
                    res: e.isExistEC
                },
                loginHid: {
                    res: e.isExistEC
                },
                getHid: {
                    res: e.isExistEC
                },
                loginDomain: {
                    res: e.isExistEC
                },
                checkDomain: {
                    res: e.isExistEC && is.Win(),
                    def: {
                        code: 1,
                        data: {
                            inDomain: 0
                        }
                    }
                },
                startService: {
                    res: e.isExistEC
                },
                queryService: {
                    res: e.isExistEC
                },
                startECTray: {
                    res: e.isExistEC
                },
                getUnAuthRes: {
                    res: e.isExistEC
                },
                getSysSetting: {
                    res: e.isExistEC && e.container !== e.CLIENT_TYPE.WEB
                },
                setSysSetting: {
                    res: e.isExistEC && e.container !== e.CLIENT_TYPE.WEB
                },
                getLinkInfo: {
                    res: e.isExistEC && e.container !== e.CLIENT_TYPE.WEB
                },
                getCurMsg: {
                    res: e.isExistEC && e.container !== e.CLIENT_TYPE.WEB
                },
                getHistoryMsg: {
                    res: e.isExistEC && e.container !== e.CLIENT_TYPE.WEB
                },
                getECMenu: {
                    res: e.isExistEC && e.container !== e.CLIENT_TYPE.WEB
                },
                invokeContainerAPI: {
                    res: e.isExistEC && e.container !== e.CLIENT_TYPE.WEB
                },
                doQueryEC: {
                    res: e.isExistEC
                },
                doConfigEC: {
                    res: e.isExistEC
                },
                getSelectedPath: {
                    res: e.isExistEC
                },
                creaShortcut: {
                    res: e.isExistEC
                }
            }
        }();
        if (t)
            for (s in i) i.hasOwnProperty(s) && t.hasOwnProperty(s) && (i[s].cb = t[s].cb);
        t = i
    }
    s.invokeFilter = function invokeFilter(s, i, e) {
        refreshFilter(), s && t.hasOwnProperty(s) && !t[s].res ? t[s].hasOwnProperty("cb") && is.fn(t[s].cb) ? t[s].cb(i, e) : function commonHandle(s, i, e) {
            var t = e || {
                code: 1,
                data: {}
            };
            s.success(t)
        }(i, 0, t[s].def) : e()
    }, s.setFilterCallBack = function setFilterCallBack(s, i) {
        t || refreshFilter(), t.hasOwnProperty(s) && is.fn(i) && (t[s].cb = i)
    }, s.checkAPIExist = function checkAPIExist(s) {
        return t || refreshFilter(), !(!s || !t.hasOwnProperty(s))
    }
}(SFFilter);