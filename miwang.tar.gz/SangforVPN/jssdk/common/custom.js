! function(r) {
    "use strict";
    var t = [],
        o = [];
    r.errorCodeFilter = function errorCodeFilter(u) {
        var e = null;
        return t.forEach(function(r) {
            var t = r(u);
            t && (e = t)
        }), e
    }, r.addErrorCodeFilter = function addErrorCodeFilter(r) {
        t.push(r)
    }, r.authResultFilter = function authResultFilter(u) {
        var e = !1;
        return o.forEach(function(r) {
            var t = r(u);
            t && (e = t)
        }), e
    }, r.addAuthResultFilter = function addAuthResultFilter(r) {
        o.push(r)
    }
}(SFCustom);