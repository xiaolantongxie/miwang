! function(s) {
    "use strict";
    var c = SFConfig || {},
        a = SFLOG,
        u = "jssdk:common",
        n = 1024,
        d = 60;

    function getData(e, t) {
        var n;
        if ((t = void 0 === t || t) && "undefined" != typeof sessionStorage) {
            n = sessionStorage.getItem(e);
            try {
                n = JSON.parse(n)
            } catch (r) {
                a.debug("common:getData", " data from sessionStorage is not json string, do not convert ")
            }
        } else try {
            n = store.get(e)
        } catch (i) {
            n = null, a.error("common:getData", "there is no privilege to get data from store", "return null instead")
        }
        return n
    }

    function formTime(e) {
        return e < 10 ? "0" + e : e
    }
    s.clone = function(e) {
        var t, n;
        if (is.object(e) || is.array(e)) {
            for (n in t = e instanceof Array ? [] : {}, e) e.hasOwnProperty(n) && (t[n] = is.object(e[n]) ? s.clone(e[n]) : e[n]);
            return t
        }
        return e
    }, s.formatString = function(e, t) {
        var n, r, i = e,
            o = 1;
        if (1 < arguments.length)
            if (arguments.length === o + 1 && "object" == typeof t)
                for (r in t) t.hasOwnProperty(r) && (n = new RegExp("({" + r + "})", "g"), i = i.replace(n, t[r]));
            else
                for (; o < arguments.length; o++) arguments[o] && (n = new RegExp("({)" + (o - 1) + "(})", "g"), i = i.replace(n, arguments[o]));
        return i
    }, s.tips = function(e) {
        var t, n, r, i = {
                success: "&#xe6b3;",
                error: "&#xe6b2;"
            },
            o = "number" == typeof e.time ? e.time : 2e3,
            s = i[e.type] ? i[e.type] : i.success,
            c = e.msg || "",
            a = document.getElementById("layer"),
            u = document.body.clientWidth;
        return a && nowRemoveEle(a), t = '<div class="layer-main"><span class="layer-msg-status"><i class="iconfont layer-msg-status-icon">' + s + '</i></span><span class="layer-msg">' + c + '</span><div class="layer-bg"></div></div>', (n = document.createElement("div")).innerHTML = t, n.id = "layer", n.className = "layer", document.body.appendChild(n), r = 6 * c.replace(/[^\x00-\xff]/gi, "aa").length + 48 + 24, n.style.width = r + "px", n.style.left = Math.round(u / 2 - r / 2) + "px", setTimeout(function() {
            n.className += " layer-show"
        }, 10), o && setTimeout(function() {
            _removeDom(n)
        }, o), {
            domEle: n,
            removeEle: _removeDom
        };

        function _removeDom(e, t) {
            e.className = e.className.replace("layer-show", ""), setTimeout(function() {
                nowRemoveEle(e)
            }, t || 200)
        }

        function nowRemoveEle(e) {
            e.remove ? e.remove() : (e.children[0] && e.removeChild(e.children[0]), e.removeNode())
        }
    }, s.debounce = function(e, t) {
        var n, r, i = null,
            o = Date.now ? Date.now() : (new Date).getTime();
        return function() {
            n = Date.now ? Date.now() : (new Date).getTime(), r = t - (n - o), clearTimeout(i), r <= 0 ? (e.apply(this, arguments), o = Date.now ? Date.now() : (new Date).getTime()) : i = setTimeout(e, r)
        }
    }, s.getTimeYMDHMS = function(e) {
        var t;
        return t = e.toString().length < 13 ? new Date(1e3 * e) : new Date(e), s.formatDataYMDHMS(t)
    }, s.formatDataYMDHMS = function(e) {
        return e.getFullYear() + "-" + ((e.getMonth() + 1 < 10 ? "0" + (e.getMonth() + 1) : e.getMonth() + 1) + "-") + ((e.getDate() < 10 ? "0" + e.getDate() : e.getDate()) + " ") + ((e.getHours() < 10 ? "0" + e.getHours() : e.getHours()) + ":") + ((e.getMinutes() < 10 ? "0" + e.getMinutes() : e.getMinutes()) + ":") + (e.getSeconds() < 10 ? "0" + e.getSeconds() : e.getSeconds())
    }, s.checkObjAttrExits = function(e, t) {
        var n, r, i = e,
            o = !0;
        if (!e || !t || !is.string(t)) return !1;
        for (n = t.split("."), r = 0; r < n.length; r++) {
            if (!is.set(i[n[r]])) {
                o = !1;
                break
            }
            i = i[n[r]]
        }
        return o
    }, s.clearSpace = function(e) {
        return e ? e.replace(/\s/g, "") : ""
    }, s.$ID = function(e) {
        return document.getElementById(e)
    }, s.getCache = function(e, t) {
        var n, r = "",
            i = !0;
        return t ? r = (n = getData(t = c.CACHE_PREFIX + "_" + t, i) || {})[e] || "" : (t = c.CACHE_PREFIX, c.persistentCache.hasOwnProperty(e) && c.persistentCache[e] && (i = !1), c.cache[e] || (n = getData(t, i) || {}, c.cache[e] = n[e] || ""), r = c.cache[e]), r
    }, s.setCache = function(e, t, n) {
        var r, i = !0;
        c.cache || (c.cache = {}), n ? n = c.CACHE_PREFIX + "_" + n : (n = c.CACHE_PREFIX, c.persistentCache.hasOwnProperty(e) && c.persistentCache[e] && (a.debug(u, "this cache key is persistentCache. the key is ", e), i = !1)), c.cache[e] = t, (r = getData(n, i) || {})[e] = t,
            function setData(e, t, n) {
                (n = void 0 === n || n) && "undefined" != typeof sessionStorage ? (is.object(t) && (t = JSON.stringify(t)), sessionStorage.setItem(e, t)) : store.set(e, t)
            }(n, r, i)
    }, s.clearCache = function() {
        store && store.set(c.CACHE_PREFIX, {})
    }, s.encryptID = function(e) {
        var t, n, r, i, o, s = new RSAKey;
        return n = (o = SF.setting.getGlobal([KEY_GLOBAL_ENCRYPT_EXP, KEY_GLOBAL_ENCRYPT_KEY, KEY_GLOBAL_EC_KEY], [0, ""]))[0] || "65537", r = o[1], i = parseInt(n, 0).toString(c.ENCRYPT_LENGTH), (e = e || {}).type = e.type || 0, e.type === c.ENCRYPT_TYPE_PSW && e.extraCode ? e.id = e.id + "_" + e.extraCode : r = o[2], r && (s.setPublic(r, i), t = s.encrypt(e.id)), t ? (a.debug(u, "key is " + (is.empty(e.id) ? "null" : e.id) + ". encript key is " + t), t) : (a.debug(u, "encryptID() error", "Can not get eckey by cache!"), "")
    }, s.handleEmptyObj = function(e, t) {
        return t || (t = ""), is.object(e) && is.empty(e) ? t : e
    }, s.getECCommand = function(e, t) {
        var n = "";
        return c.COMMAND_CONFIG.hasOwnProperty(e) && (n = s.formatString(c.COMMAND_CONFIG[e], t)), n
    }, s.getCookie = function(e) {
        for (var t, n, r = e + "=", i = r.length, o = document.cookie.length, s = !1, c = 0; c < o && (t = c + i, document.cookie.substring(c, t) === r && (-1 === (n = document.cookie.indexOf(";", t)) && (n = document.cookie.length), s = decodeURIComponent(document.cookie.substring(t, n))), 0 !== (c = document.cookie.indexOf(" ", c) + 1)););
        return s
    }, s.setCookie = function(e, t) {
        var n = arguments,
            r = arguments.length,
            i = 2 < r ? n[2] : null,
            o = 3 < r ? n[3] : "/",
            s = 4 < r ? n[4] : null,
            c = 5 < r && n[5];
        document.cookie = e + "=" + escape(t) + (null === i ? "" : "; expires=" + i.toGMTString()) + (null === o ? "" : "; path=" + o) + (null === s ? "" : "; domain=" + s) + (!0 === c ? "; secure" : "")
    }, s.isFreeMode = function() {
        return 1 === SF.setting.getGlobal(KEY_GLOBAL_CLIENT_RUN_MODE, 0) && s.isWeb()
    }, s.isWeb = function() {
        return is.WebClient
    }, s.isWinClient = function() {
        return is.WinClient
    }, s.isMacClient = function() {
        return is.MacClient
    }, s.isLinuxClient = function() {
        return is.LinuxClient
    }, s.handleData = function(e) {
        return {
            code: parseInt((e || {}).result, 0),
            data: e.data || 0 === e.data ? e.data : {}
        }
    }, s.getClientType = function() {
        var e, t = navigator.userAgent.toLowerCase(),
            n = new RegExp(/easyconnect_(windows|linux|mac)/g);
        return t.match(n) ? (e = t.split("_"), a.info(u, "current userAgent is " + t + ", current clienttype is " + e[1].toUpperCase()), c.CLIENT_TYPE[e[1].toUpperCase()]) : (a.info(u, "current userAgent is " + t + ", current clienttype is 0"), c.CLIENT_TYPE.WEB)
    }, s.checkLang = function(e) {
        return c.LANGUAGE_LIST.hasOwnProperty(e) ? e : c.DEFAULT_LANGUAGE
    }, s.hasUSBKey = function(e) {
        return e === c.KEY_TYPE.GM_KEY || e === c.KEY_TYPE.MQ_KEY || e === c.KEY_TYPE.CERT_KEY
    }, s.getECKey = function(e) {
        return e = SF.setting.getGlobal(KEY_GLOBAL_VPN_URL, "") + "_" + e
    }, s.parseURL = function(e) {
        var t = s.URLParse(e);
        return t.origin + t.pathname
    }, s.URLParse = function(e) {
        var t;
        return e = e || location.href, /^(https?:)\/\//i.test(e) || (e = "http://" + e), (t = URLParse(e)).params = s.getUrlParams(t.query), t.port && 0 < t.port || (t.port = "https:" === t.protocol ? "443" : "80"), t
    }, s.getUrlParams = function(e) {
        var t, n, r, i, o, s, c;
        if (0 === e.indexOf("?") && (e = e.substring(1)), n = {}, "" === e) return n;
        for (t = e.split("&"), r = 0; r < t.length; r++) i = t[r].split("="), o = decodeURIComponent(i[0]), s = "undefined" == typeof i[1] ? "" : decodeURIComponent(i[1]), "undefined" == typeof n[o] ? n[o] = s : "string" == typeof n[o] ? (c = [n[o], s], n[o] = c) : n[o].push(s);
        return n
    }, s.getResult = function(e, t) {
        return {
            code: e = is.number(e) ? e : 0,
            data: t = is.object(t) ? t : {}
        }
    }, s.getMessage = function(e, t) {
        var n = s.checkObjAttrExits(t, "data.NextServiceData.ErrorCode");
        if (t && n && Number(t.data.NextServiceData.ErrorCode) === ERRCODE_HTTP_AUTH_FAILED) return t.data.NextServiceData.ErrorMsg;
        var r = tr(ERROR_MSG_MAP[e]);
        return is.string(r) || (e = ERROR_UNKNOWN_FAULT, r = ERROR_MSG_MAP[ERROR_UNKNOWN_FAULT]), r
    }, s.BaseAPI = function(t, e, n, r) {
        var i, o;
        (t = is.object(t) ? t : {}).success = t.success || function() {}, o = t.error || function() {}, t.error = function(e) {
            is.object(e) ? e.msg || (e.msg = s.getMessage(e.code, e)) : (e = s.getResult(0)).msg = " handle failed ", o(e)
        }, e = function checkEvents(e, t) {
            return e || (e = {}), e.preExcute = is.fn(e.preExcute) ? e.preExcute : function(e, t) {
                t()
            }, e.afterExcute = is.fn(e.afterExcute) ? e.afterExcute : function() {}, e.excuting = is.fn(e.excuting) ? e.excuting : t, e
        }(e, n), (i = this).name = r || "", i.preExcute = e.preExcute, i.afterExcute = e.afterExcute, i.excuting = e.excuting, i.onPreExcute = function(e) {
            i.preExcute(t, e)
        }, i.onExcuting = function(e) {
            i.excuting(t, e)
        }, i.onAfterExcute = function(e) {
            i.afterExcute(t), e()
        }, i.onFiltering = function(e) {
            SFFilter.checkAPIExist(i.name) ? SFFilter.invokeFilter(r, t, e) : e()
        }, i.invoke = function() {
            new Promise(i.onFiltering).then(function() {
                return new Promise(i.onPreExcute)
            }).then(function() {
                return new Promise(i.onExcuting)
            }).then(function() {
                return new Promise(i.onAfterExcute)
            })
        }
    }, s.handleJsonString = function(e) {
        var t = "";
        if (is.object(e)) return e;
        try {
            t = JSON.parse(e)
        } catch (n) {
            t = e, a.debug(u, " current string is not json string: " + e)
        }
        return t
    }, s.extend = function(e, t) {
        var n, r = s.clone(e);
        for (n in t) t.hasOwnProperty(n) && (r[n] = t[n]);
        return r
    }, s.urlToJson = function(e) {
        var r = {};
        if (is.number(e)) e = e.toString();
        else if (!is.string(e)) return e;
        return e.split("&").forEach(function(e) {
            var t = e.indexOf("="),
                n = e.substring(0, t);
            e = e.substring(t + 1), r[n] = e
        }), r
    }, s.getThemeConfigInfo = function(t) {
        SF.init.getManifest({
            success: function(e) {
                t && t(e)
            },
            error: function(e) {
                a.info(u, "Get manifest failed"), t && t()
            }
        })
    }, s.openWindow = function(e, t) {
        var n = avalon.mix({
            url: "",
            target: !0
        }, e);
        return "" === n.url ? (a.debug(u, "openWinow url is not defined"), void(t && t(!1))) : is.string(n.url) ? s.isWeb() ? (n.target ? (window.open(n.url), a.debug(u, "window open url success(new). " + n.url)) : (window.location.href = n.url, a.debug(u, "window open url success(current). " + n.url)), void(t && t(!0))) : (a.info(u, "current environment is container, start invoke API ecOpenBrowser"), void SFAPI.invokeContainerAPI({
            name: "ecOpenBrowser",
            params: {
                url: n.url,
                browserType: is.Browser()
            },
            success: function() {
                a.debug(u, "ECClient open url success. " + n.url), t && t(!0)
            },
            error: function() {
                a.debug(u, "ECClient open url error. " + n.url), t && t(!1)
            }
        })) : (a.debug(u, "openWinow url type is not string"), void(t && t(!1)))
    }, s.checkVersion = function(e) {
        var t, n, r, i, o, s;
        return is.object(e) ? (a.info(u, "check version ,data:" + JSON.stringify(e)), t = e.local ? e.local.split(".") : "", n = e.remote ? e.remote.split(".") : "", 5 === t.length && 5 === n.length ? (r = t[0] + "." + t[1] + "." + t[2] + "." + t[3], i = n[0] + "." + n[1] + "." + n[2] + "." + n[3], o = t[4], s = n[4], r !== i ? c.IS_UPDATE.NEED_UPDATE : o !== s ? c.IS_UPDATE.AUTO_UPDATE : c.IS_UPDATE.NOT_UPDATE) : c.IS_UPDATE.NEED_UPDATE) : c.IS_UPDATE.NEED_UPDATE
    }, s.installClient = function(e) {
        a.error(u, "Common Error: " + JSON.stringify(e), "Need define a function for SFCommon.installClient to handle this error")
    }, s.onError = function(e) {
        a.error(u, "Common Error: " + JSON.stringify(e), "Need define a function for SFCommon.onError to handle this error")
    }, s.onExit = function(e) {
        a.debug(u, "Not define exit function. Run default action. Define a function for SFCommon.onExit to handle this event"), e ? SF.windowMgr.hide(c.CONTAINER_WINDOW_ID.CURRENT_WINDOW) : SF.windowMgr.close(c.CONTAINER_WINDOW_ID.CURRENT_WINDOW)
    }, s.flowUnit = function(e) {
        var t;
        return e ? (t = parseInt(e, 10)) < n ? t + " B" : t < n * n ? (t / n).toFixed(2) + " KB" : t < n * n * n ? (t / n / n).toFixed(2) + " MB" : t < n * n * n * n ? (t / n / n / n).toFixed(2) + " GB" : (t / n / n / n / n).toFixed(2) + " TB" : "0 B"
    }, s.handletime = function(e) {
        var t, n, r, i, o;
        return i = Math.floor(e / d / d / 24), t = Math.floor(e % 86400 / (d * d)), n = Math.floor(e % 86400 % (d * d) / d), r = e % 86400 % (d * d) % d, o = formTime(t) + ":" + formTime(n) + ":" + formTime(r), i ? i + " 天 " + o : o
    }, s.format = function(e) {
        var t = (e = new Date(parseInt(e, 10))).getFullYear(),
            n = e.getMonth() + 1,
            r = e.getDate(),
            i = e.getHours(),
            o = e.getMinutes();
        return t + "-" + formTime(n) + "-" + formTime(r) + " " + formTime(i) + ":" + formTime(o)
    }, s.getStrInfo = function(e, t) {
        var n, r = 0;
        if ("string" != typeof e) return 0;
        for (n = 0; n < e.length; n++)
            if (null !== e.charAt(n).match(/[^\x00-\xff]/gi) ? r += 2 : r += 1, t && t <= r) return e.substr(0, n + 1);
        return r
    }, s.getSystemError = function(e) {
        var t = {
                400: {
                    title: "Bad Request",
                    description: "The client request has syntax error and the server cannot parse it.",
                    description_cn: "客户端请求的语法错误，服务器无法理解"
                },
                401: {
                    title: "Authorization Required",
                    description: "User authenticaion is required.   ",
                    description_cn: "请求要求用户的身份认证"
                },
                402: {
                    title: "Payment Required",
                    description: "Payment Required",
                    description_cn: "保留，将来使用"
                },
                403: {
                    title: "Forbidden",
                    description: "Server has understood the client request but refuses to execute it.",
                    description_cn: "服务器理解请求客户端的请求，但是拒绝执行此请求"
                },
                404: {
                    title: "Not Found",
                    description: "Server is unable to find resources based on the client request.",
                    description_cn: "服务器无法根据客户端的请求找到资源"
                },
                405: {
                    title: "Not Allowed",
                    description: "The method in client request is not allowed.",
                    description_cn: "客户端请求中的方法被禁止"
                },
                406: {
                    title: "Not Acceptable",
                    description: "Server is unable to complete the request based on feature requested by client.",
                    description_cn: "服务器无法根据客户端请求的内容特性完成请求"
                },
                407: {
                    title: "Proxy Authentication Required",
                    description: "Proxy authentication is required.",
                    description_cn: "请求要求代理的身份认证"
                },
                408: {
                    title: "Request Time-out",
                    description: "The request that server waiting for client to send has timed out.",
                    description_cn: "服务器等待客户端发送的请求时间过长，超时"
                },
                409: {
                    title: "Conflict",
                    description: "A confict occurred while the server is processing the request.",
                    description_cn: "服务器处理请求时发生了冲突"
                },
                410: {
                    title: "Gone",
                    description: "The resources requested by client does not exist.",
                    description_cn: "客户端请求的资源已经不存在"
                },
                411: {
                    title: "Length Required",
                    description: "Server is unable to process request information sent by client without Content-Length.",
                    description_cn: "服务器无法处理客户端发送的不带Content-Length的请求信息"
                },
                412: {
                    title: "Precondition Failed",
                    description: "Precondition error in information requested by client.",
                    description_cn: "客户端请求信息的先决条件错误"
                },
                413: {
                    title: "Request Entity Too Large",
                    description: "The request was rejected because the requested entity is too large for server to process.",
                    description_cn: "由于请求的实体过大，服务器无法处理，因此拒绝请求。"
                },
                414: {
                    title: "Request-URI Too Large",
                    description: "Server is unable to process due to too long URI.",
                    description_cn: "请求的URI过长，服务器无法处理"
                },
                415: {
                    title: "Unsupported Media Type",
                    description: "Server is unable to process attached media formats.",
                    description_cn: "服务器无法处理请求附带的媒体格式"
                },
                416: {
                    title: "Requested Range Not Satisfiable",
                    description: "The range requested by client is invalid.",
                    description_cn: "客户端请求的范围无效"
                },
                417: {
                    title: "Expectation Failed",
                    description: "Sever is unable to meet the expectation of Expect's request header information.",
                    description_cn: "服务器无法满足Expect的请求头信息"
                },
                421: {
                    title: "Misdirected Request",
                    description: "The request is redirected to server that is unable to generate response.",
                    description_cn: "请求被指向到无法生成响应的服务器"
                },
                429: {
                    title: "Too Many Requests",
                    description: "User has sent too many requests in specifed time.",
                    description_cn: "户在指定的时间里发送了太多的请求"
                },
                494: {
                    title: "Bad Request",
                    description: "Request Header Or Cookie Too Large",
                    description_cn: "Request Header Or Cookie Too Large"
                },
                495: {
                    title: "Bad Request",
                    description: "The SSL certificate error",
                    description_cn: "The SSL certificate error"
                },
                496: {
                    title: "Bad Request",
                    description: "No required SSL certificate was sent",
                    description_cn: "No required SSL certificate was sent"
                },
                497: {
                    title: "Bad Request",
                    description: "No required SSL certificate was sent",
                    description_cn: "The plain HTTP request was sent to HTTPS port"
                },
                500: {
                    title: "Internal Server Error",
                    description: "Server internal error. Unable to process the request.",
                    description_cn: "服务器内部错误，无法完成请求"
                },
                501: {
                    title: "Not Implemented",
                    description: "Server does not support features implementing requests needs.",
                    description_cn: "服务器不支持实现请求所需要的功能"
                },
                502: {
                    title: "Bad Gateway",
                    description: "An invalid response is received from a remote server when a server working as a gateway or proxy tried to execute the request.",
                    description_cn: "作为网关或者代理工作的服务器尝试执行请求时，从远程服务器接收到了一个无效的响应"
                },
                503: {
                    title: "Service Temporarily Unavailable",
                    description: "Server is unable to process client's requests temporarily due to overload or system maintenance.",
                    description_cn: "由于超载或系统维护，服务器暂时的无法处理客户端的请求"
                },
                504: {
                    title: "Gateway Time-out",
                    description: "The server working as a gateway or proxy is unable to get requests from remote servers in time.",
                    description_cn: "充当网关或代理的服务器，未及时从远端服务器获取请求"
                },
                505: {
                    title: "HTTP Version Not Supported",
                    description: "Server does not support HTTP version of the request and cannot complete the process. ",
                    description_cn: "服务器不支持请求的HTTP协议的版本，无法完成处理"
                },
                507: {
                    title: "Insufficient Storage",
                    description: "Server is unable to store content necessary to complete the request.",
                    description_cn: "服务器无法存储完成请求所必须的内容"
                }
            },
            n = e + "";
        return t[n] ? t[n] : t[404]
    }
}(SFCommon);