! function(E) {
    "use strict";
    var T = 11;
    E.DEFAULT_PORT = 54530, E.FIRST_LOGIN = !0, E.PORT1 = E.DEFAULT_PORT + T, E.PORT2 = E.PORT1 + T, E.PORT3 = E.PORT2 + T, E.PORT4 = E.PORT3 + T, E.PORT5 = E.PORT4 + T, E.PORT6 = E.PORT5 + T, E.PORT7 = E.PORT6 + T, E.PORT8 = E.PORT7 + T, E.USEABLE_PORTS = [E.PORT1, E.PORT2, E.PORT3, E.PORT4, E.PORT5, E.PORT6, E.PORT7, E.PORT8], E.LANGUAGE_LIST = {
        en_US: "language.en_US.js",
        zh_CN: ""
    }, E.LANGUAGE = {
        EN_US: "en_US",
        ZH_CN: "zh_CN"
    }, E.DEFAULT_LANGUAGE = E.LANGUAGE.EN_US, E.JS_SDK_VERSION = "3.0.0", E.API_VERSION = "1", E.EC_VERSION = 1024, E.EC_URL_TEMPLATE = "https://127.0.0.1:{0}/ECAgent/", E.ENCRYPT_LENGTH = 16, E.COMMON_TIMESPAN = 1e3, E.ENCRYPT_TYPE_PSW = 1, E.HTTP_DEFAULT_PROTOCOL = "http", E.HTTP_DEFAULT_PORT = 80, E.HTTPS_DEFAULT_PORT = 443, E.DEFAULT_RECONNECT_COUNT = 3, E.NEXT_ACTION_CODE = 2, E.SUCCESS_CODE = 1, E.COM_ERROR_CODE = 0, E.PASSIVE_LOGOUT = 0, E.INITIATIVE_LOGOUT = 1, E.SECURITY_CHECK_LOGOUT = 2, E.SERVER_LOGOUT = 3, E.REDIRECT_URL_START_CODE = 4e4, E.REDIRECT_URL_END_CODE = 5e4, E.EC_MD5_SALT = "__md5_salt_for_ecagent_session__", E.VPN_URL_TEMP = "{0}/{1}", E.jsonpIndexStart = 1e4, E.jsonpIndex = E.jsonpIndexStart, E.jsonpIndexEnd = 10200, E.persistentCache = {
        ecPort: !0,
        lang: !0,
        bindWX: !0,
        clientRunMode: !0,
        firstAuth: !0
    }, E.LOGIN_STATUS = {
        OFFLINE: 0,
        ONLINE: 1,
        CONNECTING: 2,
        LOGOUT: 3,
        SWITCH: 4
    }, E.cache = {
        ecPort: 0,
        ecGuid: "",
        ecToken: "",
        encryptKey: "",
        encryptExp: "",
        ecKey: "",
        vpnURL: "",
        vpnIP: "",
        vpnProtocol: "",
        vpnCrossDomain: 0,
        vpnPort: 0,
        queryMax: 60,
        queryDelay: 500,
        next: "",
        twfID: "",
        guid: "",
        randCodeUrl: "",
        fromURL: ""
    }, E.temp = {}, E.CONTAINER_WINDOW_PATH = {
        MAIN_WINDOW: "/local/connect/connect.html",
        STATUS_MANAGER_WINDOW: "/local/vpn_status_manager/vpn_status_manager.html",
        LOGOUT_WINDOW: "/local/vpn_logout_passive/vpn_logout_passive.html",
        MENU_WINDOW: "/local/menu/menu.html",
        CONNECT_WINDOW: "/local/connect/connect.html",
        INFORMATION_WINDOW: "/local/information/information.html",
        HISTORY_WINDOW: "/local/connect_history/connect_history.html",
        SYS_SETTING: "/local/sys_setting/sys_setting.html",
        CONNECT_STATE: "/local/connect_state/connect_state.html",
        REMOTE_APP_NOTICE: "/local/remote_app_notice/remote_app_notice.html",
        CONNECT_NOT_FOUND: "/local/connect_notfound/connect_notfound.html",
        ABOUT: "/local/about/about.html",
        REJECT_LOGIN: "/local/vpn_reject_login/vpn_reject_login.html"
    }, E.PORTAL_DIRECTORY = "portal", E.CONTAINER_WINDOW_TYPE = {
        DIALOG_WINDOW: 0,
        MSG_WINDOW: 1,
        STATUS_WINDOW: 2,
        MENU_WINDOW: 3,
        STATUS_MANAGER_WINDOW: 4
    }, E.CONTAINER_WINDOW_ID = {
        CURRENT_WINDOW: 0,
        MAIN_WINDOW: 1,
        STATUS_MANAGER_WINDOW: 2,
        CONNECT_WINDOW: 6
    }, E.isExistEC = null, E.CLIENT_TYPE = {
        WEB: 0,
        WINDOWS: 1,
        LINUX: 2,
        MAC: 3
    }, E.container = E.CLIENT_TYPE.WEB, E.enableContainerMock = !1, E.containerMockType = E.CLIENT_TYPE.WINDOWS, E.systemType = E.CLIENT_TYPE.WINDOWS, E.CACHE_PREFIX = "sfjssdk", E.CACHE_FOR_LOCAL = "local", E.LOGOUT_FIELD = "logoutType", E.KEY_TYPE = {
        NO_KEY: 1,
        MQ_KEY: 2,
        GM_KEY: 4,
        CERT_KEY: 3
    }, E.SERVICE_INIT_STATE = {
        ENABLE: "enble",
        DISABLE: "disable",
        LOADING: "loading"
    }, E.IS_UPDATE = {
        NOT_UPDATE: 0,
        NEED_UPDATE: 1,
        AUTO_UPDATE: 2
    }, E.UPDATE_STATE = {
        INPROCESS: 0,
        SETUPFAILD: 1,
        SETUPSUCESS: 2,
        ISUPTODATE: 3,
        SET_UPERROR: 4,
        HAVENOPOWER: 5,
        USERCANCEL: 6,
        DOWNLOAD_FAILD: 7,
        ANOTHERISRUNNING: 8,
        RESOURCEEXHAUSTION: 9,
        INVALIDPARAM: 10,
        UNKOWNERR: 11,
        GETCONFFAILD: 12,
        NEEDUPDATEBEFORELOGIN: 13,
        NEEDREINSTALL: 14,
        UPDATE_REQOLDSERVER: 15,
        UPDATE_REQTIMOUT: 16
    }, E.PAGE_SIZE = {
        LOGIN_WIDTH: 860,
        LOGIN_HEIGHT: 560,
        CONNECT_WIDTH: 860,
        CONNECT_HEIGHT: 560
    }, E.SERVICE_SHOW_TIME = 1e3, E.CHECKPROXY = {
        IEOPTION_PARAM_ERROR: "参数错误",
        IEOPTION_USE_AUTO_CONFIG: "无法启用IE代理\n\n原因：当前IE代理启用了自动配置脚本",
        IEOPTION_USE_AUTO_DETECT: "使用了自动检测设置",
        IEOPTION_NO_SPECIFY_PROXY: "没有为指定的类型指定一个代理服务器",
        IEOPTION_IN_PASSBY: "指定的地址在排除列表中",
        IEOPTION_DIFFERENT_PROXY: "http与https代理不一致"
    }, E.LOGOUT = {
        LOGOUT_TIMEOUT: "LOGOUT_TIMEOUT",
        LOGOUT_PRIVATEKICK: "LOGOUT_PRIVATEKICK",
        LOGOUT_ADMINKICK: "LOGOUT_ADMINKICK",
        LOGOUT_COMMON: "LOGOUT_COMMON",
        LOGOUT_NOTIN_TIMEPLAN: "LOGOUT_NOTIN_TIMEPLAN",
        LOGOUT_LOCAL_EXCEPTION: "LOGOUT_LOCAL_EXCEPTION",
        LOGOUT_DEFAULT: "LOGOUT_DEFAULT"
    }, E.SERVICE_STATE = {
        STATUS_LOGOUT: 2,
        STATUS_STARTING: 17,
        STATUS_START_SUCCESS: 18,
        STATUS_START_FAILED: 19,
        STATUS_STARTED: 20,
        STATUS_STOPPING: 21,
        STATUS_STOP_SUCCESS: 22,
        STATUS_STOP_FAILED: 23,
        STATUS_STOPPED: 24,
        STATUS_INITING: 25,
        STATUS_INIT_SUCCESS: 26,
        STATUS_INIT_FAILED: 27,
        STATUS_SCACHE_MOVING: 28,
        STATUS_SCACHE_MOVE_SUCCESS: 29,
        STATUS_SCACHE_MOVE_FAILED: 30,
        STATUS_SCACHE_CLEAN_SUCCESS: 31,
        STATUS_SCACHE_CLEAN_FAILED: 32,
        STATUS_ALREADY_EXISTS: 42,
        STATUS_NEED_NOT_SERVICE: 43
    }, E.HTTP_STATUS = {
        OK: 200,
        MULTIPLE_CHOICES: 300,
        NOT_MODIFIED: 304
    }, E.CACHE_TYPE = {
        ECAGENT: 0,
        LOCAL: 1,
        TEMP: 2
    }, E.COMMAND_CONFIG = {
        Q_DISABLE: "QUERY QDISABLE",
        Q_PIN: "QUERY CHECK_PIN pin={pin}&randstring={randString}",
        Q_FLOWSTAT: "QUERY QFLOWSTAT",
        Q_BEFORE_SEC: "QUERY CHKBEFORE",
        Q_AFTER_SEC: "QUERY CHKAFTER",
        Q_UPDATE: "QUERY CONTROLS UPDATEPROCESS",
        Q_ISUPDATE: "QUERY NEEDUPDATE",
        Q_DETECT_KEY: "QUERY DKEY_DETECT",
        Q_HID: "QUERY GETHARDID",
        Q_ALLHID: "QUERY GETALLHARDID",
        Q_LANG: "QUERY LANG",
        Q_LOGOUT: "QUERY LOGOUT",
        Q_LOGINSTATUS: "QUERY LOGINSTATUS",
        Q_SESSIONID: "QUERY QSESSIONID",
        Q_CERTINFO: "QUERY QSETTING RCERTINFO",
        Q_STATE_L3VPN: "QUERY QSTATE L3VPN",
        Q_STATE_TCP: "QUERY QSTATE TCP",
        Q_STATE_ALL: "QUERY QSTATE ALLSERVICES",
        Q_STATE_SERVICES: "QUERY QSTATE SERVICES",
        Q_HTP: "QUERY QSETTING HTP",
        Q_WEBOPT: "QUERY QSETTING WEBOPT {svpnID}",
        Q_SELECTDIR: "QUERY SCACHESELECTDIR",
        Q_RCBALANCE: "QUERY QRCBALANCE",
        C_RCBALANCE: "CONF RCBALANCE",
        S_LANG: "SET LANG {lang}",
        C_PIN: "CONF SETTING PIN oldpin={oldPin}&newpin={newPin}",
        C_BALANCE_URL: "CONF RCBALANCE url={url}",
        C_RMTAPP: "CONF SETTING RAPPEXEC {id}&amp;{appPath}",
        C_LOCALAPP: "CONF STARTPROGRAM {data}",
        C_LOGINADDR: "CONF SETTING LOGINADDR {vpnLine}",
        S_LOGINADDR: "SET LOGINADDR {vpnLine}",
        S_TWFID: "SET TWFID {session}",
        S_BROWSER: "SET BROWSER {browserType}",
        S_SERVADDR: "SET SERVADDR {address}",
        C_CERTINFO: "CONF SETTING CERTINFO {cert}",
        C_CLEAN_CACHE: "CONF DISABLE CLEAN_CACHE",
        Q_SVPNURL: "QUERY SVNPADDRLIST",
        Q_LOGININFO: "QUERY LOGININFO url={url}",
        C_DEL_LOGININFO: "CONF DELETE LOGININFO url={url}",
        Q_RAPPCONF: "QUERY QSETTING RAPPCONF",
        Q_STATE_SCACHE: "QUERY QSTATE SCACHE {svpnID}",
        Q_SCACHE: "QUERY QSETTING SCACHE",
        Q_PREFSETTING: "QUERY QSETTING PREFSETTING",
        Q_RES_PATH: "QUERY RESOURCEPATH",
        C_RES_PATH: "CONF SETTING RESOURCEPATH",
        C_PREFSETTING: "CONF SETTING PREFSETTING",
        C_RAPPCONF: "CONF SETTING RAPPCONF",
        C_DISABLE_SCACHE: "CONF DISABLE SCACHE 0",
        C_ENABLE_SCACHE: "CONF ENABLE SCACHE",
        C_WEBOPT: "CONF SETTING WEBOPT state={state}",
        C_DISABLE_HTP: "CONF DISABLE HTP",
        C_ENABLE_HTP: "CONF ENABLE HTP",
        C_HTP: "CONF SETTING HTP enable={enable}&workMode={workMode}",
        C_SCACHE: "CONF SETTING SCACHE",
        Q_LINKINFO: "QUERY LINKINFO",
        Q_CUR_MSG: "QUERY DISPLAYMSG",
        Q_HIS_MSG: "QUERY HISTORYMSG",
        Q_SELECTPATH: "QUERY DIRECTORY {id}",
        Q_DOMAIN: "QUERY DOMAIN",
        Q_MENU: "QUERY MENU",
        Q_PROXYINFO: "QUERY PROXYINFO",
        C_PROXYINFO: "CONF PROXYINFO enable={enable}&userName={userName}&userPwd={userPwd}",
        C_LOGININFO: "CONF LOGININFO url={url}&pwd={pwd}&userName={userName}&enableAutoRelogin={enableAutoRelogin}&enableRemPwd={enableRemPwd}"
    }
}(SFConfig);