! function(e) {
    "use strict";
    var s, t, c, o, n, r, u = SFConfig,
        l = SFCommon,
        p = SFLOG,
        d = "jssdk:request",
        i = 500,
        a = 2e3,
        m = "jsonp_";

    function ecAgentResultFilter(e) {
        return !(!e.result && 0 !== e.result)
    }

    function ajaxResultFilter(e) {
        return !0
    }

    function pageResultFilter(e) {
        return !0
    }

    function parseECAgentResult(e, t) {
        var r, o = l.getResult(0);
        if (o.code = ERROR_SERVER_REQUEST_TIMEOUT, !t) return p.error(d, "request error", "JSON data is Empty , data is: %s. on URL: %s", JSON.stringify(t), e.requestPath), o.code = ERROR_SERVER_DATA_FORMAT_INVALID, o.msg = l.getMessage(o.code), void e.error(o);
        try {
            r = is.object(t) ? t : JSON.parse(t)
        } catch (n) {
            return p.error(d, "Json data parse error", "data is: %s. on URL: %s", JSON.stringify(t), e.requestPath), o.code = ERROR_SERVER_DATA_FORMAT_INVALID, o.msg = l.getMessage(o.code), void e.error(o)
        }
        is.numeric(r.result) && -100 === parseInt(r.result, 10) && (r.result = ERROR_EC_LOGOUT_STATUS), e.resultFilter(r) ? (! function handleHook(e, t) {
            t.version = parseInt(t.version, 0), "raw" === t.dataType && "base64" === t.encrypt && (t.data = Base64.decode(t.data), t.encrypt = "none");
            t.version >= u.EC_VERSION && (e.ecVesionAdapter = null);
            is.fn(e.ecVesionAdapter) && e.ecVesionAdapter(t)
        }(e, r), e.success(r)) : (p.error(d, "check result filter failed", "data is: %s. on URL: %s", JSON.stringify(r), e.requestPath), o.code = ERROR_SERVER_DATA_FORMAT_INVALID, o.msg = l.getMessage(o.code), e.error(o))
    }

    function formatURLParam(e, t) {
        var r, o = "";
        if (t = t || !1, "object" == typeof e) {
            for (r in e) e.hasOwnProperty(r) && is.set(e[r]) && (o += "&" + r + "=" + (t ? e[r] : encodeURIComponent(e[r])));
            o = o.substr(1)
        }
        return o
    }

    function getCallBackName() {
        var e = "cb" + u.jsonpIndex;
        return u.jsonpIndex === u.jsonpIndexEnd ? u.jsonpIndex = u.jsonpIndexStart : u.jsonpIndex++, e
    }

    function ajax(a) {
        var t, r, e, o, n, s = l.getResult(),
            c = !1;

        function onSuccess(e) {
            n = function httpData(e, t) {
                var r, o;
                if (r = c ? e.contentType : e.getResponseHeader("Content-Type"), o = "xml" === t ? e.responseXML : e.responseText, "json" === (t = t || (r && 0 <= r.indexOf("xml") ? "xml" : ""))) try {
                    o = JSON.parse(o)
                } catch (n) {
                    return p.error(d, "request error", "Json data parse error: data is: %s, On URL : %s", JSON.stringify(o), a.path), s.code = ERROR_SERVER_DATA_FORMAT_INVALID, s.msg = l.getMessage(s.code), void a.error(s)
                }
                return o
            }(e, a.dataType), a.success(n), a.complete(), r = !0, t = null
        }

        function onError(e) {
            e.msg = l.getMessage(e.code), r = !0, t.abort && t.abort(), t = null, reConnection(ajax, a)
        }
        for (o in a.crossDomain && (is.IE(8) || is.IE(9) || is.IE(10)) && XDomainRequest ? (t = new XDomainRequest, c = !0) : ("undefined" == typeof XMLHttpRequest && (XMLHttpRequest = function() {
                var e;
                return window.ActiveXObject ? ((e = new ActiveXObject("Microsoft.XMLHTTP")) || (e = new ActiveXObject("Msxml2.XMLHTTP")), e) : (p.error(d, "Init XMLHTTP Error!", "The ActiveXObject of Browser is disabled"), c = !0, XDomainRequest)
            }), t = new XMLHttpRequest), t.open(a.method, a.path, a.async), r = !1, window.setTimeout(function() {
                r || (s.code = ERROR_SERVER_REQUEST_TIMEOUT, onError(s))
            }, a.timeout), c ? (t.timeout = a.timeout, t.onload = function() {
                onSuccess(t)
            }, t.onerror = function() {
                s.code = ERROR_NETWORK_REQUEST_FAILED, onError(s)
            }) : t.onreadystatechange = function() {
                4 !== t.readyState || r || (! function httpSuccess(e) {
                    try {
                        return e.status >= u.HTTP_STATUS.OK && e.status < u.HTTP_STATUS.MULTIPLE_CHOICES || e.status === u.HTTP_STATUS.NOT_MODIFIED || 0 <= navigator.userAgent.indexOf("Safari") && "undefined" == typeof e.status
                    } catch (t) {
                        return !1
                    }
                }(t) ? (s.code = ERROR_NETWORK_REQUEST_FAILED, onError(s)) : onSuccess(t))
            }, c || t.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"), a.headers) a.headers.hasOwnProperty(o) && t.setRequestHeader(o, a.headers[o]);
        try {
            a.data && "post" === a.method ? (e = formatURLParam(a.data), t.send(e)) : t.send(null)
        } catch (i) {
            return null
        }
    }

    function jsonpRequest(t) {
        var r = l.getResult(0),
            o = window.setTimeout(function() {
                p.info(d, "JSONP: Connect timeout: " + t.timeout + ";Path: " + t.path), r.code = ERROR_SERVER_REQUEST_TIMEOUT, removeScript(t.jsonpCallback), t.jsonpCallback = getCallBackName(), reConnection(jsonpRequest, t)
            }, t.timeout),
            e = document.createElement("script");
        e.id = m + t.jsonpCallback, e.type = "text/javascript", e.async = !0, t.callBackName = t.callBackName ? t.callBackName : "callBack", 0 < t.requestPath.indexOf("?") ? t.path = t.requestPath + "&" + t.callBackName + "=" + t.jsonpCallback : t.path = t.requestPath + "?" + t.callBackName + "=" + t.jsonpCallback, window[t.jsonpCallback] = function(e) {
            window.clearTimeout(o), t.complete(), t.success(e), setTimeout(function() {
                removeScript(t.jsonpCallback)
            }, 100), is.IE() || delete window[t.jsonpCallback]
        }, e.onerror = function(e) {
            p.error(d, "load error", "Network Connect error! %s", t.path || ""), window.clearTimeout(o), r.code = ERROR_NETWORK_REQUEST_FAILED, removeScript(t.jsonpCallback), t.jsonpCallback = getCallBackName(), reConnection(jsonpRequest, t)
        }, e.src = t.path, document.getElementsByTagName("head")[0].appendChild(e)
    }

    function removeScript(e, t) {
        var r = l.$ID(m + e);
        r && (is.set(t) ? document.body.removeChild(r) : document.getElementsByTagName("head")[0].removeChild(r), r = null), window[e] && (window[e] = function() {})
    }

    function reConnection(e, t) {
        var r = l.getResult();
        r.code = ERROR_NETWORK_REQUEST_FAILED, 0 === t.conCount || t.curCount < t.conCount && 0 < t.conCount ? (t.curCount++, p.error(d, "request error ", "attemp to connect again, url is %s ,current count is %s", t.path, t.curCount), t.isPostBack && (r.msg = l.getMessage(r.code), t.error(r), t.complete()), setTimeout(function() {
            e(t)
        }, a)) : (r.msg = l.getMessage(r.code), t.error(r), t.complete(), function requestError(e) {
            e.preventOnError || (p.info(d, "Request error, show common error message."), l.onError({
                isReload: !0,
                closeBtn: !1
            }))
        }(t))
    }
    e.createRequest = function createRequest(e) {
        ! function initParam() {
            var e;
            r = SF.session.createInstance(), e = SF.setting.getGlobal([KEY_GLOBAL_VPN_URL, KEY_GLOBAL_VPN_CROSS_DOMAIN, KEY_GLOBAL_EC_PORT, KEY_GLOBAL_EC_GUID], ["", "", "", "", ""]), o = r.getTWFID(), c = r.getToken(), n = e[0], t = e[1], s = e[2], e[3]
        }(), "ECAgent" === (e = {
            type: e.type || "ECAgent",
            path: e.path || "",
            method: e.method || "get",
            requestType: e.requestType || "0",
            data: e.data || "",
            headers: e.headers || {},
            error: e.error || function() {},
            success: e.success || function() {},
            complete: e.complete || function() {},
            isNotEncode: e.isNotEncode || !1,
            compat: e.compat || !1,
            resultFilter: e.resultFilter,
            ecVesionAdapter: e.ecVesionAdapter,
            port: e.port,
            conCount: is.set(e.conCount) ? e.conCount : u.DEFAULT_RECONNECT_COUNT,
            preventOnError: e.preventOnError || !1,
            curCount: e.curCount || 0,
            apiVersion: e.apiVersion ? e.apiVersion : u.API_VERSION,
            contentType: e.contentType || "application/x-www-form-urlencoded",
            timeout: e.timeout || 3e4,
            async: !is.bool(e.async) || e.async,
            crossDomain: e.crossDomain || t,
            jsonpCallback: e.jsonpCallback || getCallBackName(),
            isPostBack: !!is.bool(e.isPostBack) && e.isPostBack
        }).type ? function handleECAgentRequest(t) {
            var e, r = "",
                o = c,
                n = {},
                a = 0;
            if (t.resultFilter = t.resultFilter || ecAgentResultFilter, t.data = t.data || [], n.op = t.path, is.array(t.data))
                for (; a < t.data.length; a++) n["arg" + (a + 1)] = t.data[a];
            n.type = SFCommon.isWeb() ? "WEB" : "EC", n.token = o, t.port || (t.port = s || u.DEFAULT_PORT), r = formatURLParam(n, t.isNotEncode), t.requestPath = l.formatString(u.EC_URL_TEMPLATE, t.port) + "?" + r, "undefined" != typeof mockRewrite && mockRewrite(t) || (e = {
                path: t.requestPath,
                requestPath: t.requestPath,
                data: n,
                curCount: t.curCount,
                timeout: t.timeout,
                conCount: t.conCount,
                preventOnError: t.preventOnError,
                async: t.async,
                error: t.error,
                complete: t.complete
            }, t.compat || is.IE(6) || is.IE(7) || is.Win(8) && is.IE() ? (e.jsonpCallback = t.jsonpCallback, e.success = function(e) {
                parseECAgentResult(t, e)
            }, e.callBackName = "callBack", jsonpRequest(e)) : (e.path = e.path + "&callBack=" + t.jsonpCallback, e.method = "get", e.dataType = "text", e.crossDomain = !0, e.success = function(e) {
                e = function getECAgentData(e) {
                    var t, r, o, n;
                    return p.assert(is.string(e), "Type error, get ecagent data from must be a string"), t = e.indexOf("(") + 1, r = e.lastIndexOf(")"), n = e.substring(t, r).trim(), p.assert(e, "Format error, can not get ecagent data between ( and )"), (o = n.length) ? '"' === n[0] && '"' === n[o - 1] || "'" === n[0] && "'" === n[o - 1] ? JSON.parse(n) : "{" === n[0] && "}" === n[o - 1] ? n : void p.assert(e, "Format error, neither string or object") : ""
                }(e), parseECAgentResult(t, e)
            }, ajax(e)))
        }(e) : function handleServerRequest(e) {
            var t = "",
                r = e.data;
            is.set(r.guid) && (r.guid = ""), 0 <= e.path.indexOf("?") ? e.path = e.path + "&apiversion=" + e.apiVersion : e.path = e.path + "?apiversion=" + e.apiVersion, 1 === e.crossDomain ? (r.twfID = o, t = formatURLParam(r), e.path = l.formatString(u.VPN_URL_TEMP, n, e.path) + (t ? "&" + t : ""), e.requestPath = e.path, e.callBackName = "callBack", jsonpRequest(e)) : (e.data = e.data || {}, "get" === e.method && (t = formatURLParam(r), e.path += t ? "&" + t : ""), "undefined" != typeof mockRewrite && mockRewrite(e) || ("0" === e.requestType ? (e.resultFilter = e.resultFilter || ajaxResultFilter, ajax(e)) : (e.resultFilter = e.resultFilter || pageResultFilter, function pageRequest(t) {
                var r, o = document.createElement("iframe"),
                    n = 0,
                    a = 5,
                    s = l.getResult();

                function queryResult() {
                    var e;
                    void 0 !== o ? "complete" === o.contentDocument.readyState && is.set(o.contentDocument.documentElement) ? (clearTimeout(r), e = o.contentDocument.documentElement.innerHTML, t.resultFilter(e) ? (t.success(e), removeScript(t.jsonpCallback, "body")) : setTimer()) : setTimer() : n < a ? (t.jsonpCallback = getCallBackName(), o.style.display = "none", o.id = m + t.jsonpCallback, document.body.appendChild(o), o.src = t.path, n++) : (s.code = ERROR_NETWORK_REQUEST_FAILED, s.msg = l.getMessage(s.code), t.error(s), t.error = function() {}, t.success = function() {})
                }

                function setTimer(e) {
                    setTimeout(queryResult, i)
                }
                o.style.display = "none", o.id = m + t.jsonpCallback, document.body.appendChild(o), o.src = t.path, r = setTimeout(function() {
                    s.code = ERROR_SERVER_REQUEST_TIMEOUT, s.msg = l.getMessage(s.code), p.debug(d, "pageRequest timeout"), t.error(s), t.error = function() {}, t.success = function() {}, removeScript(t.jsonpCallback, "body")
                }, t.timeout), setTimer(queryResult)
            }(e))))
        }(e)
    }
}(SFRequest);