! function(e) {
    "use strict";
    window && "object" == typeof window ? window.localStorage && "object" == typeof window.localStorage ? "function" == typeof define && define.amd ? define([], e) : "object" == typeof exports ? module.exports = e() : window.LocalLogger = e() : console.log("<LocalLogger> Browser does not support localStorage.") : console.log("<LocalLogger> Supports browser env only.")
}(function() {
    "use strict";
    var e = function(e) {
        var t = {};
        e && "object" == typeof e && (t = function init(e) {
            var t = {};
            return t.now = new Date, t.today = function dateString(e) {
                return (e.getFullYear() + "/" + (e.getMonth() + 1) + "/" + e.getDate()).replace(/\b([0-9]{1})\b/g, "0$1").replace(/\//g, "")
            }(t.now), t.name = e.name || "LocalLogger", t.key = t.name + "__" + t.today, t.timestamp = !!e.timestamp, t.maxDays = parseInt(e.maxDays, 10) || 3, clean(t.name, t.now, t.maxDays), t
        }(e)), this.getConfig = function(e) {
            return t[e]
        }
    };

    function clean(e, t, o) {
        for (var n, r, g = window.localStorage.length - 1; 0 <= g; g--) matchKey(e, r = window.localStorage.key(g)) && ((n = new Date(t)).setDate(n.getDate() - o), window.localStorage.removeItem(r))
    }

    function matchKey(e, t) {
        return new RegExp("^" + e + "__[0-9]{8}$").test(t)
    }
    return e.prototype.write = function(e, t) {
        void 0 === t && (t = e, e = this.getConfig("key")), t = escape(t.toString());
        var o = this.read(!1, e) ? this.read(!1, e) + ";" : "",
            n = this.getConfig("timestamp") ? "[" + (new Date).toTimeString().split(" ")[0] + "]" : "";
        window.localStorage.setItem(e, o + n + t)
    }, e.prototype.read = function(e, t) {
        if (void 0 === t && (t = this.getConfig("key")), e) {
            t = this.getConfig("name");
            for (var o = [], n = 0; n < window.localStorage.length; n++) matchKey(t, window.localStorage.key(n)) && o.push({
                date: window.localStorage.key(n).replace(t + "__", ""),
                log: window.localStorage.getItem(window.localStorage.key(n))
            });
            return o
        }
        return window.localStorage.getItem(t)
    }, e.prototype.readAsList = function(e, t) {
        var o, n, r = this.read(e, t);
        if (null == r) return [];
        e || (r = [{
            log: r
        }]);
        for (var g = 0; g < r.length; g++) {
            r[g].log = r[g].log.split(";");
            for (var i = 0; i < r[g].log.length; i++)(n = r[g].log[i].match(/^\[[0-9]+\:[0-9]+\:[0-9]+\]/g)) instanceof Array ? (o = r[g].log[i].replace(n[0], ""), n = n[0].replace(/\[|\]/g, "")) : (o = r[g].log[i], n = null), r[g].log[i] = {
                time: n,
                val: unescape(o),
                toString: function() {
                    return this.time + ":" + this.val + "\r\n"
                }
            }
        }
        return e || (r = r[0].log), r
    }, e.prototype.clean = function(e) {
        clean(this.getConfig("name"), this.getConfig("now"), e)
    }, e
}),
function(e) {
    "use strict";
    var n, r = {},
        g = {
            error: 1,
            warn: 2,
            info: 3,
            debug: 4
        },
        i = "",
        a = 1,
        l = ["pub", "dev"],
        c = !is.WebClient,
        s = !!window.localStorage;

    function _getLogSettingInfo() {
        var n;
        return new Promise(function(e, t) {
            if (!is.empty(r) || s)
                if ((n = localStorage.getItem("logCache")) || !is.empty(r)) try {
                    e(n = JSON.parse(n) || r)
                } catch (o) {
                    _writeLog("error", "log format error. please check"), e(r)
                } else e(null);
                else e(null)
        })
    }

    function _setLogSettingInfo(o) {
        return new Promise(function(e, t) {
            if (is.empty(o)) return _writeLog("debug", "setLogSettingInfo params error"), void e(!1);
            o = JSON.stringify(o), localStorage.setItem("logCache", o)
        })
    }

    function _writeLog(e, t) {
        window.console && window.console[e] && window.console[e](t), c && ("info" === e || "error" === e) && is.fn(window.ecDbgInfo) && window.ecDbgInfo(1, "portal_log_" + e, t)
    }

    function _saveLogPrintInfo(e) {
        var t = "logText",
            o = function _getLogFrag(e) {
                var t = "";
                try {
                    s && (t = localStorage.getItem(e) || "")
                } catch (o) {
                    return t
                }
                return t
            }(t + n);
        if (!e) return !1;
        s && !c && (51200 <= o.length + e.length ? (10 <= (n += 1) && (n = 0), function _setLogSaveIndex(e) {
            try {
                s && localStorage.setItem("logSaveIndex", is.number(e) ? e : 0)
            } catch (t) {}
        }(n), function _setLogFrag(e, t) {
            try {
                s && localStorage.setItem(e, t)
            } catch (o) {}
        }(t + n, e)) : (o += e, localStorage.setItem(t + n, o)))
    }

    function _log(e, t) {
        var o;
        if (!s) return !1;
        o = function _getLogText(e, t) {
            var o = "",
                n = "";
            t[3];
            return o += function _getNowFormatDate() {
                var e = new Date,
                    t = e.getMonth() + 1,
                    o = e.getDate();
                return 1 <= t && t <= void 0 && (t = "0" + t), 0 <= o && o <= void 0 && (o = "0" + o), e.getFullYear() + "-" + t + "-" + o + " " + e.getHours() + ":" + e.getMinutes() + ":" + e.getSeconds() + "." + e.getMilliseconds().toString().substr(0, 1)
            }(), o += t[0] && " [" + t[0] + "]" || "", o += t[1] && " " + t[1] || "", n += function _analysisLogMsg(e) {
                var t, o, n;
                if (e.length < 4) return e[2];
                for (t = e[2], o = 3; o < e.length; o++) n = new RegExp("%s"), t = t.replace(n, e[o]);
                return t
            }(t), n = t[2] ? ". Reason: " + n : "", o += n
        }(0, t), g[e] && r.logStack && ("error" === e || "warn" === e) && (o += "\n" + _assert(!1, o)), 20 < a || "opera" === is.Browser() ? (a = 1, _saveLogPrintInfo(i), i = "") : (a += 1, i += o + ";"), _writeLog(e, o)
    }

    function _logCondition(e, t, o) {
        return o = o || 3, !(r.logLevel < g[e]) && (!(t.length < o) || (_assert(!1, "log params error"), !1))
    }

    function _assert(e, t) {
        if (!e) {
            t = t || "";
            try {
                throw new Error(t)
            } catch (n) {
                var o = "";
                return o += n.message, o += "\r\n", n.stack && (o += n.stack), r.model === l[1] && alert(o), _writeLog("error", o), o
            }
        }
    }
    window.onbeforeunload = function() {
            _saveLogPrintInfo(i), i = ""
        },
        function _initLog() {
            _getLogSettingInfo().then(function(e) {
                is.empty(e) ? (r.logLevel = g.info, r.logStack = !1, r.model = l[0]) : (r.logLevel = e.logLevel, r.logStack = e.logStack, r.model = e.model)
            }), n = function _getLogSaveIndex() {
                var e;
                try {
                    is.number(n) ? e = n : (e = localStorage.getItem("logSaveIndex")) && (e = Number(e))
                } catch (t) {
                    return e
                }
                return e
            }(), (!is.number(n) || n < 0) && (n = 0)
        }(), e.error = function _error() {
            if (!_logCondition("error", arguments)) return !1;
            _log("error", arguments)
        }, e.warn = function _warn() {
            if (!_logCondition("warn", arguments)) return !1;
            _log("warn", arguments)
        }, e.info = function _info() {
            if (!_logCondition("info", arguments, 2)) return !1;
            _log("info", arguments)
        }, e.debug = function _debug() {
            if (!_logCondition("debug", arguments, 2)) return !1;
            _log("debug", arguments)
        }, e.help = function _help() {
            _writeLog("info", 'Log level: \nError: 1 \nWarn: 2 \nInfo: 3 \nDebug: 4 \nset log level："setLogLevel(num)", Warn: num is 0, log cannot save  \nget log level: "getLogLevel()"  \nset stack log level："setLogStackStatus(true/false)"  \nget stack log level: "getLogStackStatus()"  \nset log model: setModel(pub/dev) \nget log model: getModel() \ndefault log is 3. stack off \nstack info alert need  setting "on stack" and "dev model"')
        }, e.assert = _assert, e.getModel = function _getModel() {
            _getLogSettingInfo().then(function(e) {
                _writeLog("debug", e.model)
            })
        }, e.setModel = function _setModel(e) {
            l.indexOf(e) < 0 || (r.model = e, _setLogSettingInfo(r))
        }, e.getLogLevel = function _getLogLevel() {
            _getLogSettingInfo().then(function(e) {
                _writeLog("debug", e.logLevel)
            })
        }, e.setLogLevel = function _setLogLevel(e) {
            if (!is.number(e) && e < 3 && 0 <= e) return !1;
            r.logLevel = e, _setLogSettingInfo(r)
        }, e.getLogStackStatus = function _getLogStackStatus() {
            _getLogSettingInfo().then(function(e) {
                _writeLog("debug", e.logStack)
            })
        }, e.setLogStackStatus = function _setLogStackStatus(e) {
            if (!is.bool(e)) return !1;
            r.logStack = e, _setLogSettingInfo(r)
        }
}(SFLOG);