! function(e) {
    "use strict";
    var n, m = SF.session.createInstance(),
        h = SFLOG,
        g = "business:res_opener",
        y = SFCommon,
        c = SF.rc.sso,
        P = SF.rc.store,
        o = (SF.rc.utils, e.rc.define.rcType),
        s = e.rc.define.rcProto,
        p = e.rc.define.rcService,
        u = e.rc.define.ssoType,
        r = 0;

    function canNotOpen() {
        return new Promise(function(e, n) {
            e(!1)
        })
    }

    function handleWebsvc(e, n, t, r) {
        var o, s, i, a;
        return null !== t && (o = P.getRcById(t), a = !!(i = P.getEasyLinkRcById(t)) && i.isPort, h.assert(!is.empty(o), g + " handleWebsvc get rc result is empty")), o && (o.ips[e].host_from, o.ports[e].port_from, o.ports[e].port_to), "" === (s = o && o.svc === p.FILESHARE ? function getFileShareURL(e) {
            return "/por/webfs.csp?rcid=" + e.id + "&rnd=" + Math.random()
        }(o) : o && /^webapp:https?$/i.test(o.svc) ? function getWebAppURL(e) {
            var n = e.host,
                t = y.URLParse(n),
                r = /^https:/.test(t.protocol),
                o = t.hostname,
                s = t.port,
                i = r ? "443" !== s : "80" !== s,
                a = SF.resConfig.config.webvpn,
                c = a.scheme,
                p = a.hostname,
                u = a.port;
            if (-1 !== o.indexOf(p)) return n;
            var d = o.replace(/-/g, "--").replace(/\./g, "-");
            i && (d = d + "-" + s + "-p");
            r && (d += "-s");
            if (-1 === location.hostname.indexOf(p)) {
                var f = (t.query ? "&" : "?") + "sangfor_redirect=1&sangfor_sessid=" + encodeURIComponent(Base64.encode(m.getTWFID()));
                t.query += f
            }
            return t.protocol = c, t.host = d + "." + p + (u ? ":" + u : ""), t.toString()
        }(o) : o && i ? function getEasyLinkHref(e) {
            var n, t, r = {
                    port: "0",
                    domain: "1",
                    subdomain: "2"
                },
                o = e.ips[0].host_from,
                s = y.URLParse(o),
                i = s.pathname + s.query,
                a = P.getEasyLinkRcById(e.id),
                c = a.MapAddr,
                p = s.hash,
                u = a.Mode,
                d = SF.resConfig.config.httpPort,
                f = window.location.port,
                l = SF.resConfig.config.enableWebHttp;
            if (is.empty(e)) return h.error(g, "getEasyLinkHref: handle error  ", " rc is null"), "";
            h.assert(is.string(u), "mode is not string type"), c = c.trim().replace(/\/$/, ""), l && 0 < d && (u === r.domain || u === r.subdomain) && "https:" === c.substr(0, 6).toLowerCase() && (c = "http:" + c.substr(6), f = d, h.debug(g, "This resource to opened enabled http proxy"));
            t = n = "", u !== r.port && (f && (c = c + ":" + f), n = p ? -1 !== p.indexOf("?") ? "&" : "?" : -1 !== i.indexOf("?") ? "&" : "?", n += "sangfor_redirect=1", t = "&sangfor_sessid=" + encodeURIComponent(Base64.encode(m.getTWFID())));
            return format("{0}{1}{2}{3}{4}", c, i, p, n, t)
        }(o) : function getWebHref(e, n) {
            var t = String(n);
            if ("" === t || "?" === t) return "";
            (t = t.replace(/^\s+/g, "").replace(/\s+$/g, "").replace(/\\/g, "/")).match(/^(http:\/\/)|(https:\/\/)\s*/i) || (t = "http://" + t);
            t.match(/^https?:\/\/.+\//i) || (0 <= t.indexOf("?") ? t = t.replace(/\?/, "/?") : 0 <= t.indexOf("#") ? t = t.replace(/#/, "/#") : t += "/");
            return function sfTransURL(e, n) {
                var t, r, o = "/web/",
                    s = "1",
                    i = new String(e);
                (i = i.replace(/[\?#].*$/, "")).match(/\.css$/i) ? s = "2" : i.match(/\.js$/i) ? s = "3" : i.match(/\.vbs$/i) && (s = "4");
                if (!(t = e.match(/(https?)(:\/\/)(.*)$/i))) return "";
                r = t[3], n && (o = "/safeurl" + o);
                return window.location.protocol + "//" + SFCommon.URLParse().host + o + s + "/" + t[1] + "/0/" + r
            }(t, e && e.enable_disguise)
        }(o, n)) ? (h.info(g, "Trans url result is empty, can not open this url."), canNotOpen()) : o && o.ssoType !== u.NONE ? c.openSsoRc(o, s, r) : i && !a || y.isWeb() ? openWindow({
            url: s,
            target: !r
        }) : openWindow({
            url: function buildShortcutURL(e) {
                var n = SF.setting.getGlobal(KEY_GLOBAL_VPN_URL, ""),
                    t = SF.setting.getGlobal(KEY_GLOBAL_LANG, "");
                return h.assert(!is.empty(n), "URL of VPN is empty when build short cut URL"), n + "/portal/shortcut.html?twfid=" + m.getTWFID() + "&url=" + encodeURIComponent(e) + "&lang=" + t
            }(s),
            target: !r
        })
    }

    function openWindow(t) {
        return new Promise(function(n, e) {
            SFCommon.openWindow(t, function(e) {
                SFCommon.isWeb() && !0 === e && !t.target ? n(r) : n(e)
            })
        })
    }
    n = {
        handleResource: function(e, n, t) {
            var r = P.getRcById(e);
            return this.isCanOpen(e, n) ? r.type === o.APP && (r.svc === p.REMOTE_APP || is.Mac & r.svc === p.TERMINAL_SERVICE) ? function openRemoteApp(e) {
                return new Promise(function(n, t) {
                    SFAPI.doConfigEC({
                        key: "C_RMTAPP",
                        params: {
                            id: e.id,
                            appPath: e.app_path
                        },
                        success: function(e) {
                            h.info(g, " openRemoteApp: Open remoteAPP success"), n(!0)
                        },
                        error: function(e) {
                            h.error(g, "openRemoteApp: Failed Open remoteAPP", " error is %s ", e.msg), t()
                        }
                    })
                })
            }(r) : r.type === o.WEB ? function handWebHref(e, n) {
                var t = P.getRcById(e);
                if (is.empty(t)) return h.debug(g, "Resource: Data not exsist! id : " + e), canNotOpen();
                return handleWebsvc(0, t.ips[0].host_from, e, n)
            }(r.id, t) : r.type === o.APP || r.type === o.IP ? function handleAppOrIpHref(e, n, t) {
                var r, o = P.getRcById(e),
                    s = o.svc;
                h.assert(!is.empty(o), g + " handleIpHref get rc result is empty"), is.set(n) && (n = Number(n)); {
                    if (n = is.empty(n) ? 0 : n, r = function handleHrefHelper(e, n, t) {
                            var r, o, s, i = "",
                                a = "";
                            return r = e.ports[n].port_from, o = e.ips[n].host_from, h.assert(is.string(r), "portFrom is not string type"), t === p.HTTP ? (i = "80" === r ? "" : ":" + r, t = "http://") : t === p.HTTPS ? (i = "443" === r ? "" : ":" + r, t = "https://") : t === p.FILESHARE ? t = "\\\\" : t === p.FTP && (i = "21" === r ? "" : ":" + r, t = "ftp://"), s = o.indexOf("://") || o.indexOf("\\\\"), a = 0 < o.indexOf(":", s + 1) ? o : o + i, a = -1 === s ? t + a : a
                        }(o, n, s), o.ssoType !== u.NONE) return c.openSsoRc(o, r, t);
                    if (s === p.HTTP || s === p.HTTPS) return openWindow({
                        url: r,
                        target: !t
                    })
                }
                return function openLocalApp(s, i) {
                    return new Promise(function(n, t) {
                        var e, r, o;
                        o = s.svc, e = o !== p.FTP && o !== p.FILESHARE ? s.app_path : o === p.FTP && "" !== s.app_path ? Base64.encode(i + "|" + Base64.decode(s.app_path)) : Base64.encode(i), r = Base64.encode(format("{0}|{1}|{2}", s.id, s.name, e)), SFAPI.doConfigEC({
                            key: "C_LOCALAPP",
                            params: {
                                data: r
                            },
                            timeout: 12e4,
                            conCount: -1,
                            success: function(e) {
                                h.info(g, "Open local app resource by ECAgent success"), n(!0)
                            },
                            error: function(e) {
                                h.error(g, "Failed to open local app resource", " error is %s ", e.msg), t()
                            }
                        })
                    })
                }(o, r)
            }(r.id, n, t) : (h.warn(g, "Handle resource: Unknow Resource type", "May be data error"), canNotOpen()) : canNotOpen()
        },
        goDefaultPage: function() {
            var e = Number(P.defaultRcID);
            return h.info(g, "exist default id ,rcid is " + e), e <= 0 ? (h.debug(g, "default rcid <=0 , not continue "), canNotOpen()) : this.isCanOpen(e, 0) ? this.handleResource(e, 0, !0) : canNotOpen()
        },
        handleWebsvc: function(e) {
            return handleWebsvc(0, e, null, !1)
        },
        isCanOpen: function(e, n) {
            var t, r = P.getRcById(e);
            return h.assert(is.number(n), "index param of isCanOpen not a number"), r ? -99 === e ? (h.info(g, "Can not open Web all net resource, not continue"), !1) : r.state ? r.svc === p.DNS || r.proto === s.ICMP && r.type === o.IP ? (h.info(g, "Can not open dns or icmp resource, not continue"), !1) : (t = r.type === o.WEB || r.svc === p.HTTP || r.svc === p.HTTPS, r.addrRangeStates[n] && t ? (h.info(g, "Can not open resource address with range, not continue"), !1) : !!is.Win() || (!(!is.Mac || r.svc !== p.REMOTE_APP && r.svc !== p.TERMINAL_SERVICE) || (!!t || (h.info(g, "Can not support resource type on current platform, not continue"), !1)))) : (h.info(g, "State of the resource to open is disabled, not continue"), !1) : (h.info(g, "Can not get resource by id, not continue"), !1)
        }
    }, e.rc = e.rc || {}, e.rc.opener = n
}(SF);