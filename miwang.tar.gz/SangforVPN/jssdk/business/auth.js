! function(e) {
    "use strict";
    var c = SFAPI,
        o = SFCommon,
        u = (SFFilter, SFLOG),
        a = SFConfig,
        d = "business:auth";
    SF.ecConfig;

    function getLoginConfig(n, i) {
        var r;
        o.isWeb(), n.onHaveMidAttack;
        u.debug(d, "get login config data"),
            function init() {
                return new Promise(function(o, e) {
                    var s = n.onGetPswConfig || function() {};
                    u.debug(d, "call init() to get password params"), c.getPswConfig({
                        success: function(e) {
                            var n = e.data;
                            s(n), r = 1 === n.enableMidAtkCheck, SF.setting.setGlobal({
                                key: KEY_GLOBAL_AUTH_ENABLE_MIDATK_CHECK,
                                value: r
                            }, 0), o()
                        },
                        error: function(e) {
                            u.error(d, "get config of password failed", "%s & %s.", e.code, e.msg), n.error && n.error(e), i()
                        }
                    })
                })
            }().then(function() {
                n.onInitLoginInfo && n.onInitLoginInfo()
            })
    }

    function authPsw(s, o) {
        s.isReset;
        var i = s.userName,
            r = s.password,
            t = s.randCode;
        SF.vpnInfo.createInstance();
        (function resetLogin() {
            return new Promise(function(n, o) {
                s.notCheck ? n() : c.getInitConfig({
                    preventOnError: s.preventOnError,
                    success: function(e) {
                        n()
                    },
                    error: function(e) {
                        a.FIRST_LOGIN = !0, s.error && s.error(e), o(d, "")
                    }
                })
            })
        })().then(function loginPsw() {
            return new Promise(function(e, n) {
                c.loginPsw({
                    preventOnError: s.preventOnError,
                    userName: i,
                    password: r,
                    randCode: t,
                    success: function(e) {
                        s.success(e)
                    },
                    error: function(e) {
                        e = e || {}, u.info(d, "auth psw failed", "%s & %s", e.code, e.msg), s.error && s.error(e), o()
                    }
                })
            })
        })["catch"](function(e) {
            var n = is.object(e) ? e.message : e;
            u.error(d, "auth psw error", n)
        })
    }

    function getRandCode(n, o) {
        var e = n.token;
        c.getRandCode({
            token: e,
            success: function(e) {
                u.info(d, "get random code success"), n.success(e), o()
            },
            error: function(e) {
                u.error(d, "get random code error", "network error or context exception"), n.error(e), o()
            }
        })
    }

    function authToken(n, o) {
        var e = n.token;
        c.loginToken({
            token: e,
            success: function(e) {
                u.info(d, "token authenticion success"), n.success(e), o()
            },
            error: function(e) {
                e = e || {}, n.error(e), u.error(d, "token authenticion error", "%s & %s.", e.code, e.msg), o()
            }
        })
    }

    function authRadius(n, o) {
        var e = n.answer;
        c.loginRadius({
            answer: e,
            success: function(e) {
                u.info(d, "radius authentication success"), n.success(e), o()
            },
            error: function(e) {
                e = e || {}, n.error(e), u.error(d, "radius authentication", "%s & %s.", e.code, e.msg), o()
            }
        })
    }

    function loginDomain(n) {
        c.loginDomain({
            success: function(e) {
                n.success(e)
            },
            error: function(e) {
                e = e || {}, n.error(e), u.error(d, "login domain error", "%s & %s.", e.code, e.msg)
            }
        })
    }

    function getSmsConfig(n) {
        c.getSmsConfig({
            success: function(e) {
                n.success(e)
            },
            error: function(e) {
                e = e || {}, n.error(e), u.debug(d, "getSmsConfig error", "%s & %s.", e.code, e.msg)
            }
        })
    }

    function submitHid(n, o) {
        c.submitHid({
            hid: n.hid,
            hostName: n.hostName,
            macAddress: n.macAddress,
            success: function(e) {
                u.info(d, "submit hardid success"), n.success(e), o()
            },
            error: function(e) {
                e = e || {}, n.error(e), u.debug(d, "submit hardid error", "%s & %s.", e.code, e.msg), o()
            }
        })
    }

    function getHid(n, o) {
        c.getHid({
            success: function(e) {
                u.info(d, "get hardid success"), n.success(e), o()
            },
            error: function(e) {
                e = e || {}, n.error(e), u.debug(d, "get hardid error", "%s & %s.", e.code, e.msg), o()
            }
        })
    }

    function loginSms(n) {
        c.loginSms({
            tel: n.tel || "",
            smsCode: n.smsCode || "",
            success: function(e) {
                u.info(d, "Sms login authentication success"), n.success(e)
            },
            error: function(e) {
                n.error(e), u.debug(d, "Sms login authentication error", "%s & %s.", e.code, e.msg)
            }
        })
    }

    function getAllHid(n, o) {
        c.getAllHid({
            success: function(e) {
                u.info(d, "get all hardid success"), n.success(e), o()
            },
            error: function(e) {
                e = e || {}, n.error(e), u.debug(d, "get all hardid error", "%s & %s.", e.code, e.msg), o()
            }
        })
    }

    function getSmsCode(n) {
        c.getSmsCode({
            tel: n.tel || "",
            index: n.index || 0,
            reqParam: n.reqParam || "",
            success: function(e) {
                u.info(d, "get sms code success"), n.success(e)
            },
            error: function(e) {
                e = e || {}, n.error(e), u.debug(d, "get sms code error", "%s & %s.", e.code, e.msg)
            }
        })
    }

    function loginHid(n, o) {
        c.loginHid({
            hid: n.hid,
            hostName: n.hostName,
            macAddress: n.macAddress,
            success: function(e) {
                u.info(d, "hardid login success"), n.success(e), o()
            },
            error: function(e) {
                e = e || {}, n.error(e), u.debug(d, "hardid login failed , may be need submit", "%s & %s.", e.code, e.msg), o()
            }
        })
    }

    function getHidConfig(n, o) {
        c.getHidConfig({
            success: function(e) {
                u.info(d, "get config of hardid success"), n.success(e), o()
            },
            error: function(e) {
                e = e || {}, n.error(e), u.debug(d, "get config of hardid error", "%s & %s.", e.code, e.msg), o()
            }
        })
    }

    function setUserFirstAuth(e, n) {
        o.getResult(1);
        e.userFirstAuth = e.userFirstAuth || "", SFCommon.isWeb() || is.empty(e.userFirstAuth) || (SF.setting.setVPN({
            key: KEY_VPN_USER_FIRST_ATUH,
            value: e.userFirstAuth
        }, 1), e.success())
    }
    e.auth = {}, e.auth.setUserFirstAuth = function(e, n) {
        new SFCommon.BaseAPI(e, n, setUserFirstAuth).invoke()
    }, e.auth.getLoginConfig = function(e, n) {
        new SFCommon.BaseAPI(e, n, getLoginConfig).invoke()
    }, e.auth.authPsw = function(e, n) {
        new SFCommon.BaseAPI(e, n, authPsw).invoke()
    }, e.auth.getRandCode = function(e, n) {
        new SFCommon.BaseAPI(e, n, getRandCode).invoke()
    }, e.auth.authToken = function(e, n) {
        new SFCommon.BaseAPI(e, n, authToken).invoke()
    }, e.auth.authRadius = function(e, n) {
        new SFCommon.BaseAPI(e, n, authRadius).invoke()
    }, e.auth.loginDomain = function(e, n) {
        new SFCommon.BaseAPI(e, n, loginDomain).invoke()
    }, e.auth.getSmsConfig = function(e, n) {
        new SFCommon.BaseAPI(e, n, getSmsConfig).invoke()
    }, e.auth.loginSms = function(e, n) {
        new SFCommon.BaseAPI(e, n, loginSms).invoke()
    }, e.auth.getSmsCode = function(e, n) {
        new SFCommon.BaseAPI(e, n, getSmsCode).invoke()
    }, e.auth.submitHid = function(e, n) {
        new SFCommon.BaseAPI(e, n, submitHid).invoke()
    }, e.auth.getHid = function(e, n) {
        new SFCommon.BaseAPI(e, n, getHid).invoke()
    }, e.auth.getAllHid = function(e, n) {
        new SFCommon.BaseAPI(e, n, getAllHid).invoke()
    }, e.auth.loginHid = function(e, n) {
        new SFCommon.BaseAPI(e, n, loginHid).invoke()
    }, e.auth.getHidConfig = function(e, n) {
        new SFCommon.BaseAPI(e, n, getHidConfig).invoke()
    }
}(SF);