! function(e) {
    "use strict";
    var c, a = SFAPI,
        u = SFLOG,
        f = SFCommon,
        g = SF.rc.utils,
        l = SF.rc.store,
        i = SF.rc.opener,
        d = {},
        o = {
            success: function() {},
            error: function() {}
        },
        h = SFConfig,
        p = SF.rc.define.rcType,
        S = {
            info: {},
            config: {
                unAuthData: [],
                securityStrategy: [],
                securityStrategyHash: [],
                enableSslTray: 0,
                autoStartClient: 0,
                securityCheckInterval: null,
                enableSecurityCheck: null,
                isEnableComFirstDns: "",
                isDisplayHost: null,
                needGoDefault: null,
                otherLogin: !1,
                sslvpnNameFix: "",
                webvpn: {}
            },
            websso: [],
            rc: {
                userBind: [],
                fileLock: [],
                unAuth: [],
                strategyData: [],
                config: {},
                other: {}
            },
            sso: {
                raw: {},
                data: [],
                info: {
                    cert: null
                }
            }
        },
        _ = "business: res",
        s = SFConfig.container === SFConfig.CLIENT_TYPE.WEB;

    function Res() {}

    function _hideMainWindow() {
        SF.windowMgr.hide(SFConfig.CONTAINER_WINDOW_ID.CURRENT_WINDOW)
    }

    function _getConfigValue(e, n) {
        var t = S.config.raw.Conf;
        return g.getNodeValue(e, n, t)
    }

    function _initServiceState(e) {
        S.info.isFirstL3vpn = e.l3vpn !== h.SERVICE_STATE.STATUS_ALREADY_EXISTS, S.info.isL3vpnSuccess = e.l3vpn === h.SERVICE_STATE.STATUS_START_SUCCESS, S.info.isTcpSuccess = e.tcp === h.SERVICE_STATE.STATUS_START_SUCCESS
    }

    function _startEcTray() {
        return new Promise(function(n, t) {
            u.info(_, "step :startEcTray "), h.isExistEC && !is.WebClient ? SF.windowMgr.isExistWin(h.CONTAINER_WINDOW_ID.STATUS_MANAGER_WINDOW, function(e) {
                e ? (u.info(_, "management page is exist,do not start again"), n()) : a.startECTray({
                    success: function(e) {
                        u.info(_, "start tray success"), n(e)
                    },
                    error: function(e) {
                        u.error(_, "Failed to start the tray", " network request error "), t(e)
                    }
                })
            }) : a.startECTray({
                success: function(e) {
                    u.info(_, "start tray success"), n(e)
                },
                error: function(e) {
                    u.error(_, "Failed to start the tray", " network request error "), t(e)
                }
            })
        })
    }

    function _settingServerAddr() {
        var e, n;
        return is.empty(d.vpnIP) || is.empty(d.vpnPort) ? (n = f.URLParse(location.href), e = n.hostname + " " + n.port) : e = d.vpnIP + " " + d.vpnPort, u.info(_, "step :set server address "), new Promise(function(n, t) {
            SFAPI.doConfigEC({
                key: "S_SERVADDR",
                params: {
                    address: e
                },
                success: function(e) {
                    u.info(_, "set Server Addr success "), n(e)
                },
                error: function(e) {
                    u.error(_, " set server address failed ", " network requset error "), t(e)
                }
            })
        })
    }

    function _syncBaseInfoToClient(i) {
        return new Promise(function(e, n) {
            var t, r = d.fromURL;
            if (h.isExistEC && S.config.isFirstLogin) {
                if (t = f.isWeb() ? is.Browser() : "default", SF.setting.setGlobal({
                        key: KEY_GLOBAL_BROWSER_TYPE,
                        value: t
                    }, 0), "before" === i) return u.debug(_, "step :syncBaseInfoToClient before start service,need _settingServerAddr "), Promise.all([_settingServerAddr()]).then(function() {
                    e()
                });
                if (!S.info.isOnlyWeb) return u.debug(_, "step :syncBaseInfoToClient after start service,need _settingBrowserType、_settingFrom、_settingServerAddr "), Promise.all([function _settingBrowserType(e) {
                    return u.info(_, "step :set browser type "), new Promise(function(n, t) {
                        if (!e || !is.set(e.browserType)) return u.info(_, "settingBrowserType: check params error ", " current param is invalid "), void n();
                        SFAPI.doConfigEC({
                            key: "S_BROWSER",
                            params: {
                                browserType: e.browserType
                            },
                            success: function(e) {
                                u.info(_, "set browser type success  "), n(e)
                            },
                            error: function(e) {
                                u.error(_, "set  browser type failed ", "network request error "), t(e)
                            }
                        })
                    })
                }({
                    browserType: t
                }), function _settingFrom(r) {
                    return new Promise(function(n, t) {
                        var e = "";
                        if (u.info(_, "step :set from url  "), !r || !r.fromAddr) return u.warn(_, "set from url failed", "settingFrom: fromURL is empty ,continue "), void n();
                        e = h.systemType === h.CLIENT_TYPE.WINDOWS ? "C_LOGINADDR" : "S_LOGINADDR", SFAPI.doConfigEC({
                            key: e,
                            params: {
                                vpnLine: r.fromAddr
                            },
                            success: function(e) {
                                u.info(_, "Set source url success"), n(e)
                            },
                            error: function(e) {
                                u.error(_, "Failed Set the source url", " network request error "), t(e)
                            }
                        })
                    })
                }({
                    fromAddr: r
                }), _settingServerAddr()]).then(function() {
                    e()
                });
                e()
            } else e()
        })
    }

    function _isMustInstallClient() {
        return !(!(S.config.isEnableComFirstDns || S.config.enableSslvpnOnlyLine || S.config.enableSecurityCheck || l.data.hasLoadBalanceRc) || is.System().isMobile || f.isFreeMode()) && (u.info(_, " must install client,can not excute next step. Data is: isEnableComFirstDns:" + S.config.isEnableComFirstDns + ", enableSslvpnOnlyLine:" + S.config.enableSslvpnOnlyLine + ", enableSecurityCheck:" + S.config.enableSecurityCheck + ", hasLoadBalanceRc:" + l.data.hasLoadBalanceRc), !0)
    }
    Res.prototype = {
        init: function(e) {
            var n, t = this,
                r = null === h.isExistEC;
            if (e = avalon.mix(o, e), is.fn(e.error) && (t.error = e.error), c = SF.session.createInstance(), c.getTWFID(), n = function getRedirectUri() {
                    var e;
                    if (!SFCommon.isWeb()) return;
                    return (e = SFCommon.URLParse().params) && e.redirect_uri
                }()) return location.replace(n);
            ! function _initParam() {
                var e, n = [];
                n.push(KEY_GLOBAL_TWFIDTMP), n.push(KEY_GLOBAL_EC_TOKEN), n.push(KEY_GLOBAL_FROM_URL), n.push(KEY_GLOBAL_VPN_PORT), n.push(KEY_GLOBAL_VPN_IP), n.push(KEY_GLOBAL_EC_PORT), n.push(KEY_GLOBAL_EC_GUID), n.push(KEY_GLOBAL_VPN_URL), e = SF.setting.getGlobal(n, []), d.twfIDTmp = e[0], d.token = e[1], d.fromURL = e[2], d.vpnPort = e[3], d.vpnIP = e[4], d.port = e[5], d.guid = e[6], d.vpnURL = e[7]
            }(),
            function _checkECAgent(r) {
                return new Promise(function(e, n) {
                    var t;
                    u.info(_, "step : checkECAgent"), r ? (u.info(_, "checkECAgent ECAgent not Exist,should be detect"), t = SF.setting.getGlobal(KEY_GLOBAL_IS_FROM_EC, 0), SF.setting.setGlobal({
                        key: KEY_GLOBAL_IS_FROM_EC,
                        value: 0
                    }, 0), a.checkECAgent({
                        longTimeout: t,
                        success: function() {
                            u.info(_, " check EC agent success "), e()
                        },
                        error: function() {
                            e()
                        }
                    })) : (u.info(_, "  check EC agent success "), e())
                })
            }(r).then(function() {
                return function _initECAgent(e) {
                    return new Promise(function(n, t) {
                        u.info(_, "step : initECAgent"), h.isExistEC && e ? a.initECAgent({
                            success: function(e) {
                                u.info(_, "init ECAgent success"), n(e)
                            },
                            error: function(e) {
                                u.error(_, "Failed to init ECAgent", "error is %s ", f.getMessage(e.code)), t(e)
                            }
                        }) : n()
                    })
                }(r)
            }).then(function() {
                return function _checkLoginStatus(s) {
                    return new Promise(function(i, o) {
                        if (u.info(_, "step :queryLoginStatu"), !h.isExistEC) return S.config.isFirstLogin = !0, i(), !1;
                        a.checkReLogin({
                            success: function(e) {
                                var n, t = {
                                        notLogin: 0,
                                        selfLogin: 1,
                                        otherLogin: 2,
                                        checkOtherURL: 3,
                                        checkOtherSession: 4
                                    },
                                    r = c.getTWFID();
                                if (u.info(_, "query login status"), !e || "undefined" == typeof e.code) return u.error(_, "queryLoginStatu:Query login status failed", " api returned null or error data "), o({
                                    message: "",
                                    stack: "check re-login status failed"
                                }), !1;
                                if (u.info(_, "step :checkReLogin "), e.code === t.notLogin) u.info(_, "first login,current status is " + e.code + " no user login"), S.config.isFirstLogin = !0, n = !0;
                                else if (e.code === t.selfLogin) u.info(_, "relogin,current status is " + e.code + ", self login"), n = !0;
                                else if (e.code === t.otherLogin || e.code === t.checkOtherURL || e.code === t.checkOtherSession) return u.info(_, "relogin,other login,can not excute next temp（syncTWFID）,current status is  ", e.code), S.config.otherLogin = !0, s.onOtherLogin(), !1;
                                if (n) return is.empty(r) ? (u.error(_, "check base data failed", "twfid data is empty"), o({
                                    isEmptyData: !0
                                }), !1) : function _syncTWFID(t) {
                                    return u.info(_, "step :syncTWFID "), new Promise(function(e, n) {
                                        a.setTWFID({
                                            twfID: t,
                                            isForce: !0,
                                            success: function() {
                                                u.info(_, " sync twfid success "), e()
                                            },
                                            error: function() {
                                                u.error(_, "sync twfid error", "network request error")
                                            }
                                        })
                                    })
                                }(r).then(function() {
                                    i(e)
                                })["catch"](function(e) {
                                    o(e)
                                });
                                i(e)
                            },
                            error: function(e) {
                                u.error(_, "queryLoginStatu:Query login status failed", " cause by network request error "), o(e)
                            }
                        })
                    })
                }(e)
            }).then(function() {
                return function _checkNeedModifyPass(o) {
                    return new Promise(function(e) {
                        var n, t, r, i;
                        return n = SF.setting.getGlobal(KEY_GLOBAL_TWFID, ""), u.assert(n, "sid is empty, can not compare mark of change password"), t = hex_md5(n + SFConfig.EC_MD5_SALT), r = f.getCookie(KEY_GLOBAL_NEED_CHANGE_PSW), i = f.getCookie(KEY_GLOBAL_CHANGE_PSW_RESULT), t && t === r ? is.fn(o.onNeedModifyPass) ? void(is.fn(o.onNeedModifyPass) && o.onNeedModifyPass(e, i)) : (u.info(_, "Function onNeedModifyPass is not defined, resolve and continue"), void e()) : (u.debug(_, "session is not matched, resolve and continue without change password"), void e())
                    })
                }(e)
            }).then(function() {
                return new Promise(function(n, t) {
                    Promise.all([function _getStrategyAndResource(r) {
                        return new Promise(function(n, t) {
                            u.info(_, "step :getStrategyAndResource "), a.getStrategyAndResouceData({
                                success: function(e) {
                                    e && e.data.conf && e.data.rc && e.data.rc.Resource ? (u.info(_, "get strategy and resource success "), n(e)) : (u.info(_, "conf or rcList is null ", " token is invalid or do not set twfid to ecagent or ecagent return empty data "), r.success())
                                },
                                error: function(e) {
                                    u.error(_, "get conf or rcList error ", " network request error "), t(e)
                                }
                            })
                        })
                    }(e), function _checkProxy(e) {
                        return new Promise(function(t, n) {
                            u.info(_, "step :checkProxy "), h.isExistEC ? a.checkProxy({
                                success: function(e) {
                                    var n = !1;
                                    e && 0 === e.code && "0" === e.data ? (u.info(_, "enable proxy "), n = !0) : u.info(_, "disable proxy"), t(e), u.info(_, "check proxy success"), S.info.isUseIeProxy = n
                                },
                                error: function(e) {
                                    u.error(_, " checkProxy: error is  " + f.getMessage(e.code), "network request error or return error code "), n(e)
                                }
                            }) : t()
                        })
                    }(), _syncBaseInfoToClient("before")]).then(function(e) {
                        n(e[0])
                    })["catch"](function(e) {
                        t(e)
                    })
                })
            }).then(function(e) {
                return function _formatConfAndResource(s) {
                    return new Promise(function(e, n) {
                        var t, r, i, o = 0;
                        if (u.info(_, "step :formatConfAndResource  "), s.data.conf.Conf.Other.isUseIeProxy = S.info.isUseIeProxy, S.info = s.data.conf.Conf.Other, S.info.isFirstL3vpn = !0, S.config.raw = s.data.conf, l.initData(s.data.rc.Resource), S.config.enableSslTray = _getConfigValue("SysTray.enable", 0), S.config.isEnableComFirstDns = "" !== l.getConfig("Dns.dnsserver", ""), S.config.showRc = _getConfigValue("Other.enable_cs_rc_windows", 1), S.config.enableSslvpnOnlyLine = _getConfigValue("Other.sddn_enable", 0), S.config.enableSecurityCheck = !!_getConfigValue("SecurityCheck", !1), S.config.securityCheckInterval = _getConfigValue("SecurityCheck.attribute.interval", 0), S.config.sslvpnNameFix = function _getLocalConfigValue(e, n) {
                                var t = S.config.raw.LocalConf;
                                return g.getNodeValue(e, n, t)
                            }("Session.nameFix", ""), S.info.loginName = _getConfigValue("Other.login_name", "").toString(), SF.setting.setGlobal({
                                key: KEY_GLOBAL_LOGIN_NAME,
                                value: S.info.loginName
                            }, 0), SF.setting.setGlobal({
                                key: KEY_GLOBAL_SECURITY_CHECK,
                                value: S.config.enableSecurityCheck
                            }, 0), SF.setting.setGlobal({
                                key: KEY_GLOBAL_TRAY_TYPE,
                                value: S.config.enableSslTray
                            }, 0), S.info.isReLogin = _getConfigValue("Other.isRelogin", 0), S.info.lastLoginTime = _getConfigValue("Other.RelogTimeLast", 0), S.info.lastLoginIp = _getConfigValue("Other.RelogIPLast", ""), S.config.httpPort = _getConfigValue("WebHttpEnable.httpPort", 0), S.config.enableWebHttp = _getConfigValue("WebHttpEnable.enable", 0), S.config.webvpn.scheme = _getConfigValue("WebVpn.scheme", "http:"), S.config.webvpn.hostname = _getConfigValue("WebVpn.hostname", ""), S.config.webvpn.port = _getConfigValue("WebVpn.port", "80"), r = SF.vpnInfo.createInstance(), i = r.getLoginInfo(), is.set(i.showRc) && (S.config.showRc = i.showRc, u.debug(_, "Get showRc from pref-settings, showRc:" + S.config.showRc)), S.rc.groups = l.getGroups(), S.rc.rcs = l.getRcs(), S.rc.rcsHash = l.getRcsHash(), S.config.enableSecurityCheck)
                            if (t = _getConfigValue("SecurityCheck.strategies.strategy"), is.array(t))
                                for (S.config.securityStrategy = t; o < t.length; o++) S.config.securityStrategyHash[t[o].id] = t[o];
                            else S.config.securityStrategy = [], S.config.securityStrategy.push(t), S.config.securityStrategyHash[t.id] = t;
                        if (SF.setting.setGlobal({
                                key: KEY_GLOBAL_SECURITY_STRATEGIES,
                                value: S.config.securityStrategy
                            }, !1), S.info.isOnlyWeb = !(!f.isWeb() || _isMustInstallClient() || l.data.hasL3vpnRc || l.data.hasTcpRc || is.Win() && l.data.hasAutoFillSsoRc), h.isExistEC && S.config.isFirstLogin && !S.info.isOnlyWeb && is.empty(d.fromURL)) return u.error(_, "check base data failed", "necessary data fromURL is empty"), void n({
                            isEmptyData: !0
                        });
                        l.updateRcState(p.WEB), l.updateRcState(p.IP), l.updateRcState(p.APP), u.info(_, "format conf data And resource data success "), e()
                    })
                }(e)
            }).then(function() {
                return function _noticeClientConfig() {
                    return new Promise(function(e, n) {
                        if (!h.isExistEC) return e(), !0;
                        a.noticeClientConfig({
                            success: function() {
                                e()
                            },
                            error: function() {
                                n({
                                    message: "",
                                    stack: "do xml config failed"
                                })
                            }
                        })
                    })
                }()
            }).then(function() {
                return function _securityCheck(r) {
                    return new Promise(function(n, t) {
                        if (!S.config.enableSecurityCheck) return n(), !0;
                        a.checkSecurity({
                            type: "after",
                            success: function(e) {
                                f.checkObjAttrExits(e, "data.strategies") && !is.empty(e.data.strategies) ? (u.info(_, "check security failed after login"), is.fn(r) && r(S.config.securityStrategy, e.data.strategies)) : (u.info(_, "check security success after login"), n())
                            },
                            error: function(e) {
                                t({
                                    message: "",
                                    stack: "error request after login from ecagent"
                                }), u.error(_, "check security failed after login,request failed", JSON.stringify(e))
                            }
                        })
                    })
                }(e.onCheckSecurityDeny)
            }).then(function() {
                return function _initRsData() {
                        if (u.info(_, "step : init res data "), !S.rc.rcs || !S.rc.groups) return void u.warn(_, "_initRsData(). Initialize resource data exceptions", " no resource data");
                        S.rc.allData = S.rc.groups, S.rc.pureData = S.rc.rcs;
                        var e = l.data.hasTcpRc,
                            n = l.data.hasRemoteAppRc;
                        SF.setting.setGlobal({
                            key: KEY_GLOBAL_HAS_TCP_RESOURCE,
                            value: e
                        }, 0), SF.setting.setGlobal({
                            key: KEY_GLOBAL_HAS_REMOTE_APP,
                            value: n
                        }, 0), u.debug(_, "initRsData: success")
                    }(), t.rsInit = !0,
                    function _checkMustInstallClient(t) {
                        return new Promise(function(e, n) {
                            u.info(_, "step : checkMustInstallClient "), h.isExistEC ? e() : _isMustInstallClient() ? is.fn(t) && t() : (u.info(_, " do not need install ec client ,continue next step "), e())
                        })
                    }(e.onMustInstallClient)
            }).then(function() {
                S.config.needGoDefault = !(!l.defaultRcID || !S.config.isFirstLogin), u.debug(_, "service init success"), e.success()
            })["catch"](function(e) {
                e = e || {}, u.error(_, "catch step: proccess error  ", " occur a error in proccess, error: %s", JSON.stringify(e)), t.error(e)
            })
        },
        startService: function(t) {
            var n = this;
            u.info(_, "[timecount] enter start service process"),
                function _startService(t) {
                    return new Promise(function(n, e) {
                        function handleStartServiceError(e) {
                            if (e && e.data && e.data.base === h.SERVICE_STATE.STATUS_LOGOUT) return u.info(_, "client is logout when service is starting"), t.onLogout && t.onLogout(), !1;
                            u.info(_, "Start service failed, resolve and continue as normal"), n()
                        }

                        function startService(r) {
                            return new Promise(function(n, t) {
                                u.info(_, "[timecount] step :startService "), a.startService({
                                    onBeforeQuery: r.onBeforeQuery,
                                    onTcpFinished: r.onTcpFinished,
                                    onL3vpnFinished: r.onL3vpnFinished,
                                    onStateChanged: function(e) {
                                        _initServiceState(e)
                                    },
                                    success: function(e) {
                                        e.data;
                                        u.info(_, " start service success "), n(e)
                                    },
                                    error: function(e) {
                                        r.onBeforeQuery().then(function() {
                                            u.error(_, " start service error ", "continue starting tray as normal ")
                                        }), u.error(_, " start service error ", " network request error or service do not start "), t(e)
                                    }
                                })
                            })
                        }
                        if (!h.isExistEC || S.info.isOnlyWeb) return t.onTcpFinished && t.onTcpFinished(), t.onL3vpnFinished && t.onL3vpnFinished(), void n();
                        S.config.isFirstLogin ? startService({
                            onBeforeQuery: t.onBeforeQuery,
                            onTcpFinished: t.onTcpFinished,
                            onL3vpnFinished: t.onL3vpnFinished
                        }).then(function(e) {
                            n()
                        })["catch"](function(e) {
                            u.error(_, "Start service error", "ECAgent api returned error result" + JSON.stringify(e)), handleStartServiceError(e)
                        }) : t.onBeforeQuery().then(function() {
                            return function _queryService(e) {
                                return new Promise(function(n, t) {
                                    u.info(_, "step :queryService "), a.queryService({
                                        onTcpFinished: e.onTcpFinished,
                                        onL3vpnFinished: e.onL3vpnFinished,
                                        onStateChanged: function(e) {
                                            _initServiceState(e)
                                        },
                                        success: function(e) {
                                            u.info(_, " query service success "), n(e)
                                        },
                                        error: function(e) {
                                            u.error(_, " query service error ", " network request error or service do not query "), t(e)
                                        }
                                    })
                                })
                            }({
                                onTcpFinished: t.onTcpFinished,
                                onL3vpnFinished: t.onL3vpnFinished
                            })
                        }).then(function(e) {
                            t.onTcpFinished && t.onTcpFinished(), t.onL3vpnFinished && t.onL3vpnFinished(), n()
                        })["catch"](function(e) {
                            startService({
                                onTcpFinished: t.onTcpFinished,
                                onL3vpnFinished: t.onL3vpnFinished
                            }).then(function(e) {
                                n()
                            })["catch"](function(e) {
                                u.error(_, "Start service error", "ECAgent api retryed and returned error result: " + JSON.stringify(e)), handleStartServiceError(e)
                            })
                        })
                    })
                }({
                    onBeforeQuery: function() {
                        return new Promise(function(e, n) {
                            (function _startTray() {
                                return new Promise(function(e, n) {
                                    h.isExistEC ? function _syncLoginInfo() {
                                        return new Promise(function(e, n) {
                                            if (!f.isWeb() && S.config.isFirstLogin) {
                                                var t, r = S.info.loginName,
                                                    i = SF.vpnInfo.createInstance();
                                                r && ((t = i.getLoginInfo()).userName = r, i.saveLoginInfo(t)), e()
                                            } else e()
                                        })
                                    }().then(_startEcTray).then(function() {
                                        e()
                                    })["catch"](function(e) {
                                        n({
                                            message: tr("系统托盘启动失败"),
                                            e: e
                                        })
                                    }) : e()
                                })
                            })().then(t.onBeforeQuery).then(function() {
                                e()
                            })["catch"](function(e) {
                                n(e)
                            })
                        })
                    },
                    onTcpFinished: function() {
                        u.info(_, "[timecount] The process of Tcp service started finished"), l.updateRcState(p.APP), t.onTcpFinished && t.onTcpFinished()
                    },
                    onL3vpnFinished: function() {
                        u.info(_, "[timecount] The process of L3vpn service started finished"), l.updateRcState(p.IP), t.onL3vpnFinished && t.onL3vpnFinished()
                    },
                    onLogout: t.onLogout
                }).then(function() {
                    return _syncBaseInfoToClient()
                }).then(function() {
                    return function _syncInfoForLocalPage() {
                        return new Promise(function(e, n) {
                            var t, r, i = SF.setting.getGlobal(KEY_GLOBAL_INIT_GET_INIT_CONFIG_DATA, !1);
                            !h.isExistEC || !S.config.isFirstLogin && s || S.info.isOnlyWeb ? e() : (u.assert(i, "Can not get loginAuthConfig data from getGlobal."), r = i.enableAutoLogin, t = i.enableSavePwd, a.syncInfoForLocalPage({
                                info: {
                                    enableAutoLogin: r,
                                    enableSavePwd: t,
                                    svpnID: _getConfigValue("Service.SvpnID", ""),
                                    hasTcpResource: l.data.hasTcpRc ? 1 : 0,
                                    hasRemoteApp: l.data.hasRemoteAppRc ? 1 : 0,
                                    enableHtp: _getConfigValue("Htp.enable", 0),
                                    enableScache: _getConfigValue("SCache.enable", 0),
                                    enableWebOpt: _getConfigValue("WebOpt.enable", 0),
                                    webOptDevice: _getConfigValue("WebOpt.device", 0),
                                    showRc: S.config.showRc
                                },
                                success: function() {
                                    u.debug(_, "step :syncInfoForLocalPage success, sync data for local page"), e()
                                },
                                error: function(e) {
                                    u.error(_, "step :syncInfoForLocalPage error", "error is %s ", e.msg), n({
                                        message: "",
                                        stack: "sync base information failed"
                                    })
                                }
                            }))
                        })
                    }()
                }).then(function() {
                    u.info(_, "[timecount] last step: start service process success"), t.success()
                })["catch"](function(e) {
                    u.error(_, "catch step: proccess error  ", " occur a error in proccess of start service, message is %s stack is %s ", e.message, e.stack), n.error(e)
                })
        },
        goDefault: function(e) {
            var n = this;
            (function _goDefaultResource(r) {
                return new Promise(function(t, e) {
                    S.config.isFirstLogin ? i.goDefaultPage().then(function(e) {
                        var n;
                        n = 0 === e, f.isWeb() || !1 === e || (u.debug(_, "Hide EC window after open Default resource."), _hideMainWindow()), r && r(n), n || t(n)
                    }) : t()
                })
            })(e.onGoDefault).then(function() {
                return function _swicthShowRcList() {
                    return new Promise(function(e, n) {
                        if (f.isWeb() || !S.config.isFirstLogin) return u.debug(_, "In browser or not first login, not switch show state"), void e();
                        S.config.showRc ? (u.debug(_, "Not hide EC window, Because showRc of pref-settings or server is false"), e()) : (u.debug(_, "Hide EC window, Because showRc of pref-settings or server is true"), _hideMainWindow(), setTimeout(function() {
                            e()
                        }, 1e3))
                    })
                }()
            }).then(function() {
                u.debug(_, "Call success callback after go default resource"), e.success()
            })["catch"](function(e) {
                u.error(_, "catch step: proccess error  ", " occur a error in proccess of start service, message is %s stack is %s ", e.message, e.stack), n.error(e)
            })
        },
        updateBalanceRes: function(n) {
            n && SFAPI.updateBalanceRes({
                rcName: n.name,
                grpID: n.rc_grp_id,
                secID: n.selectid,
                autoID: n.id,
                success: function(e) {
                    u.info(_, "updateBalanceRes: The load balancing update was successful"), n.success(e)
                },
                error: function(e) {
                    u.error(_, "updateBalanceRes error", "error is %s", e.msg), n.error(e)
                }
            })
        },
        handleResource: function(e, n, t) {
            return i.handleResource(e, n, t)
        },
        sf_handle_websvc: function(e) {
            return i.handleWebsvc(e)
        },
        error: function(e) {
            u.error(_, "Some error occured, but no function to handle by init.", "error is %s", e.msg)
        }
    }, SF.res = new Res, SF.resConfig = S
}(SF);