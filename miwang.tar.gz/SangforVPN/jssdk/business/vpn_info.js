! function(e) {
    "use strict";
    var n, t, _ = SFCommon,
        L = (SFLOG, SFConfig, 10);

    function VPNInfo() {
        var n, t, s, o = SFLOG,
            i = "module:vpnInfo";
        (s = this).getLoginInfo = function() {
            return SFCommon.isWeb() ? {} : (n = SF.setting.getVPN(KEY_VPN_LOGIN_INFO, {}), SFCommon.clone(n))
        }, s.setLoginInfo = function(e) {
            if (SFCommon.isWeb()) return {};
            e = e || {}, n = SFCommon.extend(n, e)
        }, s.syncLoginInfo = function() {
            var e, n;
            if (_.getResult(1), SF.setting.setGlobal({
                    key: KEY_GLOBAL_LOGIN_CLIENT_TYPE,
                    value: SFConfig.container
                }, !1), SFCommon.isWeb()) return {};
            o.debug(i, "sync login info"), n = s.getLoginInfo(), e = s.getTempLoginInfo(), n.userName && n.userName === e.userName ? (o.debug(i, "username of history is diff with current temp username, should be instead."), e = _.extend(n, e)) : n.hasOwnProperty("showRc") && !e.hasOwnProperty("showRc") && (e.showRc = n.showRc), SF.setting.setVPN({
                key: KEY_VPN_FIRST_AUTH,
                value: s.getTempFirstAuth()
            }, !0), s.saveLoginInfo(e), s.clearTempInfo()
        }, s.getFirstAuth = function() {
            return SF.setting.getVPN(KEY_VPN_FIRST_AUTH, "")
        }, s.setTempFirstAuth = function(e) {
            SF.setting.setVPN({
                key: KEY_VPN_TEMP_FIRST_AUTH,
                value: e
            }, !1)
        }, s.getTempFirstAuth = function() {
            return SF.setting.getVPN(KEY_VPN_TEMP_FIRST_AUTH, "")
        }, s.saveLoginInfo = function(e) {
            if (SFCommon.isWeb()) return {};
            n = e || {}, SF.setting.setVPN({
                key: KEY_VPN_LOGIN_INFO,
                value: n
            }, !0)
        }, s.getTempLoginInfo = function() {
            return t = SF.setting.getVPN(KEY_VPN_TEMP_LOGIN_INFO, {}), SFCommon.clone(t)
        }, s.saveTempLoginInfo = function(e) {
            (e = e || {}).userName && e.userName !== t.userName && (t = {}), t = SFCommon.extend(t, e), SF.setting.setVPN({
                key: KEY_VPN_TEMP_LOGIN_INFO,
                value: t
            }, !1)
        }, s.clearTempInfo = function() {
            t = {}, SF.setting.setVPN({
                key: KEY_VPN_TEMP_LOGIN_INFO,
                value: {}
            }, !1), SF.setting.setVPN({
                key: KEY_VPN_TEMP_FIRST_AUTH,
                value: ""
            }, !1)
        }, s.getVPNURLList = function() {
            return SF.setting.getGlobal(KEY_GLOBAL_VPN_URL_LIST, [])
        }, s.setLastVPNURL = function(e) {
            var n, t = s.getVPNURLList(),
                o = [];
            e && (n = SFCommon.parseURL(e), o.push(e), t.forEach(function(e) {
                SFCommon.parseURL(e) !== n && o.push(e)
            }), o.length > L && (o = o.slice(0, L)), SF.setting.setGlobal({
                key: KEY_GLOBAL_LAST_VPN_URL,
                value: e
            }, !0), SF.setting.setGlobal({
                key: KEY_GLOBAL_VPN_URL_LIST,
                value: o
            }, !0), (SFCommon.isMacClient() || SFCommon.isLinuxClient()) && SF.ecConfig.write({
                key: SF.ecConfig.key.LAST_VPN_URL,
                value: e
            }))
        }, s.deleteVPNURL = function(n) {
            var e, t = s.getVPNURLList(),
                o = [];
            n && (t.forEach(function(e) {
                n !== e && o.push(e)
            }), SF.setting.setGlobal({
                key: KEY_GLOBAL_LAST_VPN_URL,
                value: o[0] ? o[0] : ""
            }, !0), SF.setting.setGlobal({
                key: KEY_GLOBAL_VPN_URL_LIST,
                value: o
            }, !0), e = SF.setting.getGlobal(KEY_GLOBAL_FROM_URL, ""), SF.setting.setGlobal({
                key: KEY_GLOBAL_FROM_URL,
                value: n
            }, !1), s.saveLoginInfo({}), SF.setting.setGlobal({
                key: KEY_GLOBAL_FROM_URL,
                value: e
            }, !1))
        }, s.getLastVPNURL = function() {
            return SF.setting.getGlobal(KEY_GLOBAL_LAST_VPN_URL, "")
        }
    }
    e.vpnInfo = e.vpnInfo || {}, e.vpnInfo.createInstance = function createInstance() {
        return t = t || SF.ecConfig, is.empty(n) && (n = new VPNInfo), n
    }
}(SF);