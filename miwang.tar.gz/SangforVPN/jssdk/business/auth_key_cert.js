! function(e) {
    "use strict";
    var o = SFAPI,
        c = SFConfig,
        i = SFCommon,
        r = 0,
        s = SFLOG,
        u = "business: auth_key_cert";

    function authKey(t, e) {
        ! function resetLogin() {
            o.getInitConfig({
                success: function(e) {
                    ! function loginKey() {
                        o.loginKey({
                            type: t.type,
                            pin: t.pin,
                            success: function(e) {
                                t.success(e)
                            },
                            error: function(e) {
                                e = e || {}, s.debug(u, "auth key failed,", "error code:%s,error msg:%s", e.code, e.msg), t.error && t.error(e)
                            }
                        })
                    }()
                },
                error: function(e) {
                    t.error && t.error(e)
                }
            })
        }()
    }

    function getCertList(t, e) {
        o.getCertList({
            success: function(e) {
                t.success(e)
            },
            error: function(e) {
                e = e || {}, s.error(u, "get certificate list failed", "error code:%s,error msg:%s", e.code, e.msg), t.error && t.error(e), t.nextAction && t.nextAction()
            }
        })
    }

    function getSelectedPath(r, e) {
        var t = (new Date).valueOf(),
            n = "*.p12;*.pfx";
        i.isWeb() || is.Win() ? o.getSelectedPath({
            id: t,
            filter: n,
            success: function(e) {
                r.success(e)
            },
            error: function(e) {
                e = e || {}, s.error(u, "get selected path failed", "error code:%s,error msg:%s", e.code, e.msg), r.error && r.error(e), r.nextAction && r.nextAction()
            }
        }) : o.invokeContainerAPI({
            name: "ecSelectFile",
            params: {
                type: 1,
                filter: n
            },
            success: function(e) {
                var t = i.getResult();
                is.set(e.data) || is.empty(e.data.path) ? (t.code = c.SUCCESS_CODE, t.data.path = e.data.path, r.success(t)) : (s.error(u, " get seleced path failed ", " container return undefined data "), r.error(t))
            },
            error: function(e) {
                s.error(u, " get seleced path failed ", " invoke container api error or container return failed result "), r.error(e)
            }
        })
    }

    function importCert(t, e) {
        t.path = t.path || "", t.psw = t.psw || "", t.nextAction = e, o.importCert({
            path: t.path,
            psw: t.psw,
            success: function(e) {
                e.code === c.SUCCESS_CODE ? t.success(e) : t.error(e)
            },
            error: function(e) {
                e = e || {}, s.debug(u, "import cert failed,", "error code:%s,error msg:%s", e.code, e.msg), t.error && t.error(e), t.nextAction && t.nextAction()
            }
        })
    }

    function authCert(t, e) {
        SF.vpnInfo.createInstance();
        t.type = c.isExistEC ? "ECAgent" : "Server", t.index = t.index || 0, t.certName = t.certName || "", t.nextAction = e,
            function resetLogin() {
                o.getInitConfig({
                    success: function(e) {
                        ! function loginCert() {
                            o.loginCert({
                                index: t.index || 0,
                                certName: t.certName || "",
                                success: function(e) {
                                    t.success(e)
                                },
                                error: function(e) {
                                    e = e || {}, s.debug(u, "auth certificate failed", "error code:%s,error msg:%s", e.code, e.msg), t.error && t.error(e)
                                }
                            })
                        }()
                    },
                    error: function(e) {
                        t.error && t.error(e)
                    }
                })
            }()
    }

    function detectKey(e, t) {
        r++, e.currentTimer = r, e.queryMax = "undefined" != typeof e.queryMax ? e.queryMax : 0, e.delay = "undefined" != typeof e.delay ? e.delay : 2e3, e.count = 0, e.nextAction = t, createDetectKeyRequest(e)
    }

    function createDetectKeyRequest(t) {
        o.detectKey({
            success: function(e) {
                t.currentTimer === r && (! function queryTimer(e) {
                    (e.count < e.queryMax || 0 === e.queryMax) && setTimeout(function() {
                        e.count++, createDetectKeyRequest(e)
                    }, e.delay)
                }(t), t.success(e))
            },
            error: function(e) {
                s.debug(u, "detectKey() error", "%s & %s", e.code, e.msg), t.error && t.error(e), t.nextAction && t.nextAction()
            }
        })
    }

    function downloadKey(e, t) {
        new i.BaseAPI(e, t, function excuting(e, t) {
            var r, n = function getDkeyURL() {
                    return "zh_cn" === SF.setting.getGlobal(KEY_GLOBAL_LANG, "").toLowerCase() ? "/com/dkeydrv_zh.cab" : "/com/dkeydrv_en.cab"
                }(),
                o = is.Browser() || "default",
                c = SF.setting.getGlobal(KEY_GLOBAL_VPN_URL, "");
            i.isWeb() ? ((r = document.createElement("iframe")).style.display = "none", document.body.appendChild(r), r.src = n) : (n = c + n, s.debug("ui:auth_key_cert", n), SF.windowMgr.openBrowser(n, o, function() {}))
        }).invoke()
    }
    e.auth = e.auth || {}, e.auth.authKey = function(e, t) {
        new SFCommon.BaseAPI(e, t, authKey).invoke()
    }, e.auth.detectKey = function(e, t) {
        new SFCommon.BaseAPI(e, t, detectKey).invoke()
    }, e.auth.cancelTimer = function cancelTimer(e) {
        r++
    }, e.auth.getSelectedPath = function(e, t) {
        new SFCommon.BaseAPI(e, t, getSelectedPath).invoke()
    }, e.auth.importCert = function(e, t) {
        new SFCommon.BaseAPI(e, t, importCert).invoke()
    }, e.auth.getCertList = function(e, t) {
        new SFCommon.BaseAPI(e, t, getCertList).invoke()
    }, e.auth.authCert = function(e, t) {
        new SFCommon.BaseAPI(e, t, authCert).invoke()
    }, e.auth.downloadKey = function(e, t) {
        new SFCommon.BaseAPI(e, t, downloadKey).invoke()
    }
}(SF);