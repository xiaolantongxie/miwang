! function(e) {
    "use strict";
    var _ = SFCommon,
        I = SFConfig,
        O = "jssdk:popup_manage",
        N = SFLOG,
        r = 600,
        s = 500;
    e.popupManage = e.popupManage || {}, e.popupManage.init = function init() {
        var e, n, o, i, t, w;
        _.isWinClient() && (o = SF.windowMgr.createWindow(I.CONTAINER_WINDOW_TYPE.DIALOG_WINDOW, I.CONTAINER_WINDOW_PATH.CONNECT_STATE), SF.setting.setGlobal({
            key: KEY_GLOBAL_CONNECT_STATE_ID,
            value: o
        }, 0), N.info(O, "create connection state window, ID:" + o), i = SF.windowMgr.createWindow(I.CONTAINER_WINDOW_TYPE.DIALOG_WINDOW, I.CONTAINER_WINDOW_PATH.HISTORY_WINDOW), SF.setting.setGlobal({
            key: KEY_GLOBAL_CONNECT_HISTORY_ID,
            value: i
        }, 0), N.info(O, "create history window, ID:" + i), e = SF.windowMgr.createWindow(I.CONTAINER_WINDOW_TYPE.DIALOG_WINDOW, I.CONTAINER_WINDOW_PATH.SYS_SETTING), SF.setting.setGlobal({
            key: KEY_GLOBAL_SYS_SETTING_ID,
            value: e
        }, 0), N.info(O, "create system setting window, ID:" + e), w = SF.windowMgr.createWindow(I.CONTAINER_WINDOW_TYPE.DIALOG_WINDOW, I.CONTAINER_WINDOW_PATH.ABOUT), SF.setting.setGlobal({
            key: KEY_GLOBAL_ABOUT_ID,
            value: w
        }, 0), N.info(O, "create about window, ID:" + w)), t = SF.runtime.buildShortcutUrl("/portal/#!/user_setting_box"), n = SF.windowMgr.createWindow(I.CONTAINER_WINDOW_TYPE.DIALOG_WINDOW, t), N.info(O, "create personal setting window, ID:" + n), SF.setting.setGlobal({
            key: KEY_GLOBAL_PERSON_SETTING_ID,
            value: n
        }, 0), SF.windowMgr.resize(n, r, s), SF.windowMgr.moveTo(n, (window.screen.width - r) / 2, (window.screen.height - s) / 2), SF.windowMgr.registEvents("onOpenPersonSetting", function() {
            is.LinuxClient && (SF.windowMgr.show(n), SF.windowMgr.resize(n, r, s), SF.windowMgr.moveTo(n, (window.screen.width - r) / 2, (window.screen.height - s) / 2)), SF.windowMgr.show(n)
        })
    }, e.popupManage.close = function close(e) {
        SF.windowMgr.hide(e)
    }, e.popupManage.show = function show(e) {
        SF.windowMgr.show(e)
    }
}(SF);