! function(e) {
    "use strict";
    var a, s = SFAPI,
        g = SFLOG,
        o = SFCommon,
        u = SFConfig,
        l = "business: common";
    SF.ecConfig;

    function getInstallAdress(n, o) {
        s.getInstallAdress({
            type: n.type,
            success: function(e) {
                g.info(l, "get install address success"), n.success(e), o()
            },
            error: function(e) {
                e = e || {}, g.error(l, "get install address error", "%s & %s CausedBy: network error or type error", e.code, e.msg), n.error(e), o()
            }
        })
    }

    function setLang(n) {
        SF.setting.setGlobal({
            key: KEY_GLOBAL_LANG,
            value: n.lang
        }, 1), o.isWeb() ? n.success() : SF.ecConfig.write({
            key: SF.ecConfig.key.LANG,
            value: n.lang
        }, function(e) {
            n.success(e)
        })
    }
    e.common = e.common || {}, e.common.getInstallAdress = function(e, n) {
        new SFCommon.BaseAPI(e, n, getInstallAdress).invoke()
    }, e.common.setLang = function(e, n) {
        new SFCommon.BaseAPI(e, n, setLang).invoke()
    }, e.common.initLocalPage = function initLocalPage(n) {
        a = SF.session.createInstance(),
            function checkEnvironment() {
                SFAPI.checkECAgent({
                    success: function() {
                        ! function init() {
                            a.init(function() {
                                n.success()
                            })
                        }()
                    },
                    error: function(e) {
                        e = e || {}, n.error()
                    }
                })
            }()
    }, e.common.showResourcePage = function showResourcePage(e) {
        var o, n, s, t, i, r, c;

        function openContainerPage() {
            var e;
            if (t) return e = getShortcutURL(r), g.info(l, "showResourcePage :path:" + e + ",container:" + s), void SF.windowMgr.redirect(u.CONTAINER_WINDOW_ID.MAIN_WINDOW, e, i);
            SF.windowMgr.show(u.CONTAINER_WINDOW_ID.MAIN_WINDOW)
        }

        function getShortcutURL(e) {
            var n;
            return n = "portal/shortcut.html?twfid=" + a.getTWFID() + "&url=" + encodeURIComponent(e) + "&lang=" + c, "/" === o.substr(o.length - 1) ? o + n : o + "/" + n
        }
        e = is.object(e) ? e : {}, a = SF.session.createInstance(), c = SF.setting.getGlobal(KEY_GLOBAL_LANG, "en_US"), r = "/portal/#!/service", i = !is.bool(e.isShow) || e.isShow, t = !!is.bool(e.isRefresh) && e.isRefresh, o = is.set(e.vpnURL) ? e.vpnURL : SF.setting.getGlobal(KEY_GLOBAL_VPN_URL, ""), n = is.set(e.browserType) ? e.browserType : SF.setting.getGlobal(KEY_GLOBAL_BROWSER_TYPE, "default"), s = is.set(e.loginClientType) ? e.loginClientType : SF.setting.getGlobal(KEY_GLOBAL_LOGIN_CLIENT_TYPE, 0), g.info(l, " invoke showResourcePage ,loginClientType is " + s), s === u.CLIENT_TYPE.WINDOWS ? (g.info(l, " open res by container "), openContainerPage()) : s === u.CLIENT_TYPE.MAC || s === u.CLIENT_TYPE.LINUX ? SF.ecConfig.read(SF.ecConfig.key.ALL_ID, [], function(e) {
            var n = !0;
            0 <= e.indexOf(u.CONTAINER_WINDOW_ID.MAIN_WINDOW) && (n = !1, g.info(l, " mac or linux :  ")), t = t || n, openContainerPage()
        }) : (g.info(l, " open res by browser "), function openWebPage() {
            var e = getShortcutURL(r);
            g.info(l, "showResourcePage :path:" + e + ",browserType:" + n), SF.windowMgr.openBrowser(e, n, function() {
                g.debug(l, " open browser by container success ")
            })
        }())
    }
}(SF);