! function(n) {
    "use strict";
    var i = SFLOG,
        c = "module:ecConfig";

    function dataToArray(n, t, o, a) {
        is.array(n) ? n.forEach(function(n, e) {
            o.push(n), a.push(t[e])
        }) : (o.push(n), a.push(t))
    }
    n.ecConfig = n.ecConfig || {}, n.ecConfig.read = function readConfig(n, e, t) {
        ! function commonAsyncGet(n, e, t) {
            var o, a = !1,
                r = [];
            t = is.fn(t) ? t : function() {}, o = function handleGetPromiseAll(n, e, t, o) {
                var a = [],
                    r = [],
                    i = [];
                return dataToArray(n, e, r, i), r.forEach(function(n, e) {
                    a.push(function createGetPromise(t, o, a) {
                        return new Promise(function(e, n) {
                            ! function invokeGetAPI(n, e, t) {
                                SFAPI.invokeContainerAPI({
                                    name: "ecReadConfig",
                                    params: {
                                        key: n.key
                                    },
                                    success: function(n) {
                                        e(n.data)
                                    },
                                    error: function() {
                                        e("")
                                    }
                                })
                            }(t, function(n) {
                                a[o] = is.empty(n) ? t.defaultValue : n, e()
                            })
                        })
                    }({
                        key: n,
                        defaultValue: i[e]
                    }, e, t))
                }), a
            }(n, e, r), Promise.all(o).then(function() {
                a = !0, t.apply(null, r)
            })["catch"](function(n) {
                i.debug(c, "get data failed, error:" + n.message), a || t(!1)
            })
        }(n, e, t)
    }, n.ecConfig.write = function writeConfig(n, e) {
        ! function commonAsyncSet(n, e) {
            var t, o = !1;
            e = is.fn(e) ? e : function() {}, t = function handleSetPromiseAll(n, e) {
                var t = [],
                    o = [];
                return i.assert(is.array(n) || is.object(n), "current data is not object or array"), dataToArray(n, "", o, []), o.forEach(function(n) {
                    t.push(function createSetPromise(t) {
                        return new Promise(function(n, e) {
                            ! function invokeSetAPI(n, e, t) {
                                SFAPI.invokeContainerAPI({
                                    name: "ecWriteConfig",
                                    params: {
                                        key: n.key,
                                        value: n.value
                                    },
                                    success: function(n) {
                                        e(n.data)
                                    },
                                    error: function() {
                                        e("")
                                    }
                                })
                            }(t, n)
                        })
                    }({
                        key: n.key,
                        value: n.value
                    }))
                }), t
            }(n), Promise.all(t).then(function() {
                e(o = !0)
            })["catch"](function(n) {
                i.debug(c, "save data failed,error:" + n.message), o || e(!1)
            })
        }(n, e)
    }, n.ecConfig.key = {
        LOGIN_INFO: "loginInfo",
        USERCFG_TRANSLATE: "userConfigTranslate",
        DKEY_MONITOR: "dkeyMonitor",
        VPN_URL_LIST: "vpnURLList",
        LANG: "lang",
        EC_PORT: "ecPort",
        GUID: "guid",
        TWFID: "twfID",
        TOKEN: "token",
        LAST_VPN_URL: "lastVPNURL",
        PROXY: "proxy",
        ALL_ID: "allID",
        CURRENT_ID: "currentID",
        DELETE_VPN_URL: "deleteVPNURL",
        PRIVACY: "privacy",
        FIRST_CONNECT: "firstconnect",
        APP_NAME: "appName"
    }
}(SF);