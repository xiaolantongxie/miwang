! function(t) {
    "use strict";
    SFAPI;
    var a = SFConfig,
        i = SF.setting;
    SFLOG;
    t.runtime = t.runtime || {}, t.runtime.buildShortcutUrl = function buildShortcutUrl(t) {
        var r = i.getGlobal(KEY_GLOBAL_VPN_URL, ""),
            e = i.getGlobal(KEY_GLOBAL_TWFID, ""),
            o = i.getGlobal(KEY_GLOBAL_LANG, "en_US");
        return SFCommon.formatString("{0}/portal/shortcut.html?twfid={1}&url={2}&lang={3}", r, e, encodeURIComponent(t), o)
    }, t.runtime.getRappStorageUrl = function getRappStorageUrl(t, r, e) {
        var o = i.getGlobal(KEY_GLOBAL_VPN_URL, ""),
            n = i.getGlobal(KEY_GLOBAL_TWFID, ""),
            l = i.getGlobal(KEY_GLOBAL_LANG, "zh_CN"),
            _ = i.getGlobal(KEY_GLOBAL_EC_PORT, a.DEFAULT_PORT);
        return SFCommon.formatString("{0}/por/shortcut.csp?type=cs&destUrl=webfs.csp&id={1}&ea_port={2}&rapp_storage_id={3}&rcid={4}&is_reminded={5}&language={6}", o, n, _, t, r, e, l)
    }, t.runtime.openUrlWithBrowser = function openUrlWithBrowser(t, r) {
        r = (r = r || i.getGlobal(KEY_GLOBAL_BROWSER_TYPE, 0)) || "default", SF.windowMgr.openBrowser(t, r)
    }
}(SF);