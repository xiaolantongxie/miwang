! function(s) {
    "use strict";
    var p, a = SFAPI,
        u = SFLOG,
        E = SFCommon,
        S = SF.session.createInstance(),
        f = s.rc.define.rcType,
        g = s.rc.define.rcService,
        y = s.rc.define.bitType,
        F = s.rc.define.ssoType,
        L = "business:res_sso",
        C = SF.rc.store;
    SF.rc.utils;
    p = {
        info: {},
        getSsoURL: function(s, o) {
            var e, t, n = s.id,
                r = window.location.protocol + "//" + SFCommon.URLParse().host,
                i = S.getTWFID(),
                c = 0,
                p = "",
                a = "",
                u = SF.setting.getGlobal(KEY_GLOBAL_LANG, "");
            return SFConfig.isExistEC && (c = (t = SF.setting.getGlobal([KEY_GLOBAL_EC_PORT, KEY_GLOBAL_EC_GUID, KEY_GLOBAL_EC_TOKEN], []))[0], p = t[1], a = t[2]), e = C.getEasyLinkRcById(n), (SFConfig.isExistEC && s.type !== f.WEB && s.ssoType === F.FILL || SFConfig.isExistEC && e && !e.isPort || SFConfig.isExistEC && !E.isWeb() && s.type !== f.WEB ? "https://127.0.0.1:" + c + "/Web/sso.html" : r + "/portal/sso.html") + "?id=" + n + "&url=" + (o = encodeURIComponent(o)) + "&twfid=" + i + "&ecport=" + c + "&ecguid=" + p + "&ectoken=" + a + "&lang=" + u
        },
        openSsoRc: function(r, i, c) {
            return new Promise(function(s, o) {
                var e, t, n = !c || 1;
                u.assert(!is.empty(r), "rc is empty, can not open this rc by sso."), u.assert(!is.empty(i), "url is empty, can not open this rc by sso."), r.ssoType === F.NONE ? (u.info(L, "Not sso rc, can not open by sso"), o()) : r.ssoType === F.WEB ? (i = p.getSsoURL(r, i), SFCommon.openWindow({
                    url: i,
                    target: !c
                }), s(n)) : r.ssoType === F.FILL ? (t = r.svc) === g.HTTP || t === g.HTTPS ? (i = p.getSsoURL(r, i), is.Win() && SFConfig.isExistEC ? a.startSsoIE({
                    url: i,
                    success: function() {
                        u.debug(L, "Open IE for sso success"), s(!0)
                    },
                    error: function() {
                        o()
                    }
                }) : (SFCommon.openWindow({
                    url: i,
                    target: !c
                }), s(n))) : (e = r.attr & y.USER_BIND ? 1 : 0, a.startSsoProgram({
                    args: [r.sso.data, 0, r.app_path, "", r.type, e],
                    success: function() {
                        u.debug(L, "Open resource for cs sso success"), s(!0)
                    },
                    error: function() {
                        o()
                    }
                })) : (u.error(L, "Open resource by sso error", "Type of sso is not expected"), o())
            })
        }
    }, s.rc = s.rc || {}, s.rc.sso = p
}(SF);