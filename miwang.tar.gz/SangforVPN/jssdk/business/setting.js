var KEY_GLOBAL_VERSION = "version",
    KEY_GLOBAL_WORK_PATH = "workPath",
    KEY_GLOBAL_LAST_VPN_URL = "lastVPNURL",
    KEY_GLOBAL_EC_PORT = "ecPort",
    KEY_GLOBAL_VPN_URL_LIST = "vpnURLList",
    KET_GLOBAL_GUID = "guid",
    KEY_GLOBAL_LANG = "lang",
    KEY_GLOBAL_DELETE_VPN_URL = "deleteVPNURL",
    KEY_GLOBAL_MENU_ID = "menuID",
    KEY_GLOBAL_BROWSER_TYPE = "browserType",
    KEY_GLOBAL_IS_USER_LOGOUT = "isUserLogout",
    KEY_GLOBAL_USING_KEY = "usingKey",
    KEY_GLOBAL_ENCRYPT_EXP = "encryptExp",
    KEY_GLOBAL_ENCRYPT_KEY = "encryptKey",
    KEY_GLOBAL_EC_KEY = "ecKey",
    KEY_GLOBAL_LOGIN_CLIENT_TYPE = "loginClientType",
    KEY_GLOBAL_VPN_PORT = "vpnPort",
    KEY_GLOBAL_VPN_URL = "vpnURL",
    KEY_GLOBAL_VPN_IP = "vpnIP",
    KEY_GLOBAL_VPN_PROTOCOL = "VPNProtocol",
    KEY_GLOBAL_FROM_URL = "fromURL",
    KEY_GLOBAL_EC_GUID = "ecGuid",
    KEY_GLOBAL_LOGIN_NAME = "loginName",
    KEY_GLOBAL_TRAY_TYPE = "trayType",
    KEY_GLOBAL_TWFIDTMP = "twfIDTmp",
    KEY_GLOBAL_EC_TOKEN = "ecToken",
    KEY_GLOBAL_NEED_CHANGE_PSW = "needChangePswMark",
    KEY_GLOBAL_CHANGE_PSW_RESULT = "needChangePswResult",
    KEY_GLOBAL_TWFID = "sid",
    KEY_GLOBAL_EC_TWFID = "ecTWFID",
    KEY_GLOBAL_AUTH_LIST = "authList",
    KEY_GLOBAL_AUTH_ENABLE_MIDATK_CHECK = "authEnableMidAtkCheck",
    KEY_GLOBAL_INIT_GET_INIT_CONFIG_DATA = "initGetInitConfigData",
    KEY_GLOBAL_CONNECT_URL = "connectUrl",
    KEY_GLOBAL_DISABLED_AUTO_RELOGIN = "disabledAutoRelogin",
    KEY_GLOBAL_HAS_TCP_RESOURCE = "hasTcpResource",
    KEY_GLOBAL_HAS_REMOTE_APP = "hasRemoteApp",
    KEY_GLOBAL_ENABLE_AUTO_LOGIN = "enableAutoLogin",
    KEY_GLOBAL_VPN_CROSS_DOMAIN = "vpnCrossDomain",
    KEY_GLOBAL_SVPN_ID = "svpnID",
    KEY_GLOBAL_IS_CLIENT_EXIT = "isClientExit",
    KEY_GLOBAL_IS_CACHE = "isCache",
    KEY_GLOBAL_CUR_MSG = "curMsg",
    KEY_GLOBAL_SYS_SETTING_ID = "sysSettingID",
    KEY_GLOBAL_PERSON_SETTING_ID = "personSettingID",
    KEY_GLOBAL_REAL_FROM_URL = "realFromURL",
    KEY_GLOBAL_AUTO_TEST = "autoTest",
    KEY_GLOBAL_PSW_REMAIN_TIME = "pswRemainTime",
    KEY_GLOBAL_LOGOUT_FROM = "logoutFrom",
    KEY_GLOBAL_CSRF_RAND_CODE = "csrfRandCode",
    KEY_GLOBAL_CONNECT_STATE_ID = "connectStateID",
    KEY_GLOBAL_CONNECT_PAGE_SHOW = "connectPageShow",
    KEY_GLOBAL_IS_FROM_EC = "isFromEC",
    KEY_GLOBAL_RELOGIN_STATUS = "reloginStatus",
    KEY_GLOBAL_IS_APP_RECOVER = "isAppRecover",
    KEY_GLOBAL_PERSON_SETTING_IS_LOADING_DONE = "personSettingIsLoadingDone",
    KEY_GLOBAL_NOT_AUTO_CONNECT = "notAutoConnect",
    KEY_GLOBAL_NOT_SHOW_CONNECT_PAGE = "notShowConnetPage",
    KEY_GLOBAL_CONNECT_HISTORY_ID = "connectHistoryID",
    KEY_GLOBAL_CUR_MSG_ID = "curMsgID",
    KEY_GLOBAL_AUTO_CONNECT = "autoConnect",
    KEY_GLOBAL_ABOUT_ID = "aboutID",
    KEY_GLOBAL_SECURITY_CHECK = "securityCheck",
    KEY_GLOBAL_SECURITY_STRATEGIES = "securityStrategies",
    KEY_GLOBAL_LOGOUT_REASON = "logoutReason",
    KEY_GLOBAL_HISTORY_MSG_ID = "historyMsgID",
    KEY_GLOBAL_IS_SHOW_MENU = "isShowMenu",
    KEY_GLOBAL_BROWSER_CACHE = "unsupportBrowserCache",
    KEY_GLOBAL_TRANSLATION = "translation",
    KEY_GLOBAL_THIRDPARTY_DATA = "thirdpartyParamTrans",
    KEY_GLOBAL_WECHAT_STATE = "wxState",
    KEY_GLOBAL_WECHAT_UNBIND = "unbind",
    KEY_GLOBAL_WECHAT_BINDED = "binded",
    KEY_GLOBAL_WECHAT_REBIND = "rebind",
    KEY_GLOBAL_WECHAT_BINDDATA = "bindWX",
    KEY_GLOBAL_CLIENT_RUN_MODE = "clientRunMode",
    KEY_VPN_USER_FIRST_ATUH = "userFirstAuth",
    KEY_VPN_LOGIN_INFO = "loginInfo",
    KEY_VPN_PUB_MENU_DATA = "pubMenuData",
    KEY_VPN_END_TAG = "END",
    KEY_VPN_TEMP_LOGIN_INFO = "tempLoginInfo",
    KEY_VPN_DKEY_MONITOR = "dkeyMonitor",
    KEY_VPN_TEMP_FIRST_AUTH = "tempFirstAuth",
    KEY_VPN_FIRST_AUTH = "firstAuth",
    KEY_VPN_BASE_INFO = "",
    KEY_VPN_LOGIN_AUTH = "local";
!window.ecGet && top.window.ecGet && (window.ecGet = top.window.ecGet), !window.ecSet && top.window.ecSet && (window.ecSet = top.window.ecSet),
    function(_) {
        "use strict";
        var A = SFLOG,
            o = SFCommon,
            a = SFConfig,
            i = "ECAgent",
            r = "Container",
            O = "WEB",
            c = "module:setting",
            G = !0,
            s = {},
            u = {},
            t = o.isWeb() ? O : r;

        function commonSyncGet(e, _, t, n) {
            var E = [],
                L = [],
                o = [];
            return dataToArray(e, E, _, L), E.forEach(function(e, _) {
                s.hasOwnProperty(e) && !u[e] && G ? o[_] = SFCommon.clone(s[e]) : (o[_] = invokeGetAPI({
                    key: e,
                    isGlobal: t
                }, n), L[_] = is.set(L[_]) ? L[_] : "", o[_] = is.empty(o[_]) && 0 !== o[_] ? L[_] : o[_], s[e] = o[_])
            }), is.array(e) ? o : o[0]
        }

        function commonSyncSet(e, t, n, E) {
            var _ = [];
            t = t ? 1 : 0, dataToArray(e, _, "", []), _.forEach(function(e, _) {
                s[e.key] = e.value, invokeSetAPI({
                    key: e.key,
                    value: e.value,
                    isGlobal: n,
                    persist: t
                }, E)
            })
        }

        function dataToArray(e, t, n, E) {
            n = n || 0 === n ? n : "", E = E || [], is.array(e) ? e.forEach(function(e, _) {
                t.push(e), E.push(n[_])
            }) : (t.push(e), E.push(n))
        }

        function invokeGetAPI(e, _, t, n) {
            var E, L;
            switch (_) {
                case O:
                    return function getCache(e, _) {
                        return o.getCache(e)
                    }(e.key);
                case r:
                    return L = getContainerKeyPath(e.key, e.isGlobal), (E = (E = window.ecGet(L)) || {}).data = o.handleJsonString(E.data), E.data;
                case i:
                    L = a.CACHE_PREFIX + e.key, SFAPI.getCacheFromECAgent({
                        key: L,
                        value: JSON.stringify(e),
                        flag: 0,
                        success: function(e) {
                            t(e.data)
                        },
                        error: n
                    });
                    break;
                default:
                    n()
            }
        }

        function invokeSetAPI(e, _, t, n) {
            switch (_) {
                case O:
                    ! function setCache(e, _, t) {
                        o.setCache(e, _, t)
                    }(e.key, e.value);
                    break;
                case r:
                    e.key = getContainerKeyPath(e.key, e.isGlobal), e.value = is.object(e.value) ? e.value : JSON.stringify(e.value), window.ecSet(e.key, e.value, e.persist);
                    break;
                case i:
                    e.key = a.CACHE_PREFIX + e.key, SFAPI.setCacheFromECAgent({
                        key: e.key,
                        value: e.value,
                        success: t,
                        error: n
                    });
                    break;
                default:
                    n()
            }
        }

        function getContainerKeyPath(e, _) {
            var t, n, E;
            return (_ = _ || !1) ? E = "/global/" + e : (t = window.ecGet("/global/" + KEY_GLOBAL_FROM_URL) || {}, n = o.handleJsonString(t.data) || "", n = o.parseURL(n), E = "/" + (n = encodeURIComponent(n)) + "/" + e), E
        }
        u[KEY_GLOBAL_TWFID] = !0, u[KEY_GLOBAL_EC_TOKEN] = !0, u[KEY_VPN_LOGIN_INFO] = !0, u[KEY_VPN_TEMP_LOGIN_INFO] = !0, u[KEY_GLOBAL_IS_CACHE] = !0, u[KEY_GLOBAL_CONNECT_PAGE_SHOW] = !0, u[KEY_GLOBAL_PERSON_SETTING_IS_LOADING_DONE] = !0, u[KEY_GLOBAL_AUTO_CONNECT] = !0, u[KEY_GLOBAL_IS_SHOW_MENU] = !0, u[KEY_GLOBAL_TRANSLATION] = !0, u[KEY_GLOBAL_PERSON_SETTING_ID] = !0, _.setting = _.setting || {}, _.setting.getGlobal = function getGlobal(e, _) {
            return commonSyncGet(e, _, !0, t)
        }, _.setting.setGlobal = function setGlobal(e, _) {
            return commonSyncSet(e, _, !0, t)
        }, _.setting.setVPN = function setVPN(e, _) {
            return commonSyncSet(e, _, !1, t)
        }, _.setting.getVPN = function getVPN(e, _) {
            return commonSyncGet(e, _, !1, t)
        }, _.setting.getShm = function getShm(e, _, t) {
            ! function commonAsyncGet(e, _, t, n, E) {
                var L, o = !1,
                    a = [];
                L = function handleGetPromiseAll(e, _, t, n, E, L) {
                    var o = [],
                        a = [],
                        i = [];
                    return dataToArray(e, a, _, i), a.forEach(function(e, _) {
                        o.push(function createGetPromise(t, n, E, L) {
                            return new Promise(function(_, e) {
                                invokeGetAPI(t, n, function(e) {
                                    L[E] = is.empty(e) ? t.defaultValue : e, _()
                                }, function() {
                                    A.debug(c, "get cache data error ,type: " + n + ",key data:" + JSON.stringify(t)), e({
                                        message: 'invoke "get" api error,create promise failed'
                                    })
                                })
                            })
                        }({
                            key: e,
                            isGlobal: t,
                            defaultValue: i[_]
                        }, n, _, E))
                    }), o
                }(e, _, t, n, a, E = E || function() {}), Promise.all(L).then(function() {
                    o = !0, E.apply(null, a)
                })["catch"](function(e) {
                    A.debug(c, "get data failed, error:" + e.message), o || E(!1)
                })
            }(e, _, !1, i, t)
        }, _.setting.setShm = function setShm(e, _) {
            ! function commonAsyncSet(e, _, t, n, E) {
                var L, o = !1;
                L = function handleSetPromiseAll(e, _, t, n, E) {
                    var L = [],
                        o = [];
                    return A.assert(is.array(e) || is.object(e), "current data is not object or array"), _ = 1 === _ ? 1 : 0, dataToArray(e, o, "", []), o.forEach(function(e) {
                        L.push(function createSetPromise(t, n) {
                            return new Promise(function(e, _) {
                                invokeSetAPI(t, n, e, function() {
                                    A.debug(c, "get cache data error ,type: " + n + ",key data:" + JSON.stringify(t)), _({
                                        message: 'invoke "set" api error,create promise failed'
                                    })
                                })
                            })
                        }({
                            key: e.key,
                            value: e.value,
                            isGlobal: t,
                            persist: _
                        }, n))
                    }), L
                }(e, _, t, n, E = E || function() {}), Promise.all(L).then(function() {
                    E(o = !0)
                })["catch"](function(e) {
                    A.debug(c, "save data failed,error:" + e.message), o || E(!1)
                })
            }(e, "", !1, i, _)
        }, _.setting.addNoCacheField = function addNoCacheField(e) {
            var _ = [];
            dataToArray(e, _), _.forEach(function(e) {
                u[e] = !0
            })
        }, _.setting.delNoCacheField = function delNoCacheField(e) {
            var _ = [];
            dataToArray(e, _), _.forEach(function(e) {
                u[e] = !1
            })
        }, _.setting.cacheSetting = function cacheSetting(e) {
            G = is.bool(e) ? e : G, _.setting.setGlobal({
                key: KEY_GLOBAL_IS_CACHE,
                value: G
            }, !1)
        }
    }(SF);