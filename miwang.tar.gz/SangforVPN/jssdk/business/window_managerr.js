var EVENT_MAIN_WINDOW_READY = "mainWindowReady",
    EVENT_CHECK_UNAUTH_DATA = "checkUnAuthData",
    EVENT_CLAER_SERVICE_TIMEOUT_TIMER = "clearServiceTimeoutTimer",
    EVENT_AUTO_CONNECT = "autoConnect",
    EVENT_ON_OPEN_CONNECT = "onOpenConnect",
    EVENT_ON_OPEN_CONNECT_HISTORY = "onOpenConnectHistory",
    EVENT_ON_SESSION_CHANGE = "onSessionChange",
    EVENT_ON_SERVICE_SHOW = "onServiceShow",
    EVENT_ON_OPEN_CONNECT_STATUS = "onOpenConnectStatus";
! function(e) {
    "use strict";
    var w = SFLOG,
        c = (SFConfig, "jssdk:windowmgr");
    SFCommon;

    function ecShow(e) {
        is.fn(window.ecShow) && (w.info(c, "ecShow,id:" + e), window.ecShow(e))
    }

    function ecDbginfo(e, n, o) {
        e = e || 0, n = "[web][" + (n = n || "") + "]", window.ecDbginfo && window.ecDbginfo(e, n, o)
    }
    e.windowMgr = e.windowMgr || {}, e.windowMgr.resize = function ecResize(e, n, o) {
        window.ecResize && window.ecResize(e, n, o)
    }, e.windowMgr.moveTo = function ecMoveTo(e, n, o, i) {
        i = !!is.bool(i) && i, w.info(c, "ecMoveTo,id:" + e + ",x:" + n + ",y:" + o + ",isCenter:" + i), i && (n = parseInt((window.screen.width - n) / 2, 10), o = parseInt((window.screen.height - o) / 2, 10)), window.ecMoveTo && window.ecMoveTo(e, n, o)
    }, e.windowMgr.close = function ecClose(e) {
        window.ecClose && (w.info(c, "ecClose,id:" + e), window.ecClose(e))
    }, e.windowMgr.show = ecShow, e.windowMgr.hide = function ecHide(e) {
        is.fn(window.ecHide) && (w.info(c, "ecHide,id:" + e), window.ecHide(e))
    }, e.windowMgr.createWindow = function ecCreateWindow(e, n) {
        return is.fn(window.ecCreateWindow) ? (w.info(c, "ecCreateWindow,type:" + e + ",url:" + n), window.ecCreateWindow(e, n)) : -1
    }, e.windowMgr.redirect = function ecRedirect(e, n, o) {
        o = !is.bool(o) || o, window.ecRedirect && (w.info(c, "ecRedirect,id:" + e + ",url:" + n), window.ecRedirect(e, n), o && ecShow(e))
    }, e.windowMgr.setDragRect = function ecSetDragRect(e, n) {
        window.ecSetDragRect && window.ecSetDragRect(e, n)
    }, e.windowMgr.minimize = function ecMinimize() {
        window.ecMinimize && window.ecMinimize()
    }, e.windowMgr.maximize = function ecMaximize() {
        window.ecMaximize && window.ecMaximize()
    }, e.windowMgr.startTray = function ecStartTray(e) {
        window.ecStartTray && window.ecStartTray(e)
    }, e.windowMgr.closeTray = function ecCloseTray() {
        window.ecCloseTray && (w.info(c, "ecCloseTray"), window.ecCloseTray())
    }, e.windowMgr.logout = function ecLogout() {
        window.ecLogout && (w.info(c, "ecLogout"), window.ecLogout())
    }, e.windowMgr.openBrowser = function ecOpenBrowser(e, n, o) {
        o = o || function() {}, w.info(c, "ecOpenBrowser,url:" + e + ",browserType:" + n), SFAPI.invokeContainerAPI({
            name: "ecOpenBrowser",
            params: {
                url: e,
                browserType: n
            },
            success: function(e) {
                o(e)
            }
        })
    }, e.windowMgr.selectFile = function ecSelectFile(e, n, o) {
        o = o || function() {}, SFAPI.invokeContainerAPI({
            name: "ecSelectFile",
            params: {
                type: e,
                filter: n
            },
            success: function(e) {
                o(e)
            }
        })
    }, e.windowMgr.registEvents = function ecRegistEvents(e, n) {
        n = n || function() {}, w.info(c, "ecRegistEvents,eventName:" + e), SFAPI.invokeContainerAPI({
            name: "ecRegisterEventHandler",
            params: {
                eventName: e
            },
            success: function(e) {
                n(e)
            }
        })
    }, e.windowMgr.exit = function ecExit() {
        window.ecExit && (w.info(c, "ecExit"), window.ecExit())
    }, e.windowMgr.changeTrayStatus = function ecChangeTrayStatus(e) {
        window.ecChangeTrayStatus && window.ecChangeTrayStatus(e)
    }, e.windowMgr.triggerEvent = function ecTriggerEvent(e, n) {
        window.ecTriggerEvent && (w.info(c, "ecTriggerEvent,eventName:" + e), window.ecTriggerEvent(e, n))
    }, e.windowMgr.showTrayState = function ecShowTrayState(e) {
        window.ecShowTrayState && window.ecShowTrayState(e)
    }, e.windowMgr.clearCookie = function ecClearCookie() {
        window.ecClearCookie && window.ecClearCookie()
    }, e.windowMgr.errorLog = function errorLog(e, n) {
        ecDbginfo(3, e, n)
    }, e.windowMgr.warnLog = function warnLog(e, n) {
        ecDbginfo(2, e, n)
    }, e.windowMgr.infoLog = function infoLog(e, n) {
        ecDbginfo(1, e, n)
    }, e.windowMgr.debugLog = function debugLog(e, n) {
        ecDbginfo(0, e, n)
    }, e.windowMgr.isExistWin = function isExistWin(i, w) {
        w = is.fn(w) ? w : function() {}, is.WebClient || 0 === i ? w(!0) : i ? SF.ecConfig.read(SF.ecConfig.key.ALL_ID, [], function(e) {
            var n = !1,
                o = 0;
            if (is.array(e))
                for (o = 0; o < e.length; o++)
                    if (e[o] === i) {
                        n = !0;
                        break
                    }
            w(n)
        }) : w(!1)
    }, e.windowMgr.configGMMode = function ecConfigGMMode(e) {
        var n;
        is.fn(window.ecConfigGMMode) && is.WinClient && (n = {
            enable: e ? 1 : 0,
            exceptionUrlList: ["https://res.wx.qq.com", "https://open.weixin.qq.com", "https://lp.open.weixin.qq.com"]
        }, w.info(c, "set config for connect mode, is gm mode:" + e), window.ecConfigGMMode(n))
    }
}(SF);