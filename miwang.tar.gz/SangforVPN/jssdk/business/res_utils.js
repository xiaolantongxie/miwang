! function(r) {
    "use strict";
    SFAPI, SFLOG, SFCommon;
    var a = {
        getNodeValue: function(r, e, t) {
            var n, a;
            if (void 0 === t) return e;
            for (n = r.split("."), a = 0; a < n.length; a++)
                if (null == (t = t[n[a]])) return e;
            return is.string(t) && is.numeric(t) && "number" == typeof e && (t = parseFloat(t)), t
        },
        buildArray: function(r, e) {
            var t, n = [];
            return t = a.getNodeValue(r, [], e), is.array(t) ? n = t : n.push(t), n
        },
        htmlDecode: function(r) {
            var e = r.toString();
            return e = (e = (e = (e = (e = (e = e.replace(/&quot;/g, "'")).replace(/&apos;/g, "")).replace(/&lt;/g, "<")).replace(/&gt;/g, ">")).replace(/&amp;/g, "&")).replace(/&nbsp;/g, " ")
        },
        extend: function(r, e) {
            var t;
            for (t in e) e.hasOwnProperty(t) && (r[t] = e[t]);
            return r
        }
    };
    r.rc = r.rc || {}, r.rc.utils = a
}(SF);