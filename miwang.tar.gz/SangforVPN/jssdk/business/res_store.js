! function(t) {
    "use strict";
    var s, p = SFLOG,
        i = SFCommon,
        u = SFConfig,
        n = SF.rc.utils,
        c = {},
        h = {
            BALANCE_START: -3e4,
            BALANCE_END: -1e3,
            SPECIAL_START: -999,
            SPECIAL_END: 0
        },
        d = {
            USER_BIND: 8
        },
        f = {
            NONE: 0,
            WEB: 1,
            FILL: 2
        },
        l = {
            WEB: 0,
            APP: 1,
            IP: 2
        },
        E = {
            TCP: 0,
            UDP: 1,
            ICMP: 2,
            IP: 3
        },
        R = {
            HTTP: "http",
            HTTPS: "https",
            FILESHARE: "fileshare",
            REMOTE_APP: "remoteapp",
            TERMINAL_SERVICE: "terminal service",
            DNS: "dns",
            FTP: "ftp"
        };

    function getRcValue(t, s) {
        var r = c.raw;
        return n.getNodeValue(t, s, r)
    }(s = function() {
        this.data = {}
    }).prototype.initData = function(t) {
        var s, r, e, o, a = this;
        for (! function resetData(t) {
                t.defaultRcID = 0, t.data = {
                    hasWebRc: !1,
                    hasTcpRc: !1,
                    hasL3vpnRc: !1,
                    hasRemoteAppRc: !1,
                    hasWebAllNetRc: !1,
                    hasLoadBalanceRc: !1,
                    hasUserBindRc: !1,
                    hasAutoFillSsoRc: !1
                }, c = {
                    raw: {},
                    rcs: [],
                    groups: [],
                    hashRc: {},
                    hashGroup: {},
                    hashEasyLink: {},
                    fileLocks: [],
                    sso: {},
                    webSso: {}
                }
            }(a), c.raw = t, s = n.buildArray("RcGroups.Group", t), r = n.buildArray("Rcs.Rc", t), a.defaultRcID = getRcValue("Other.defaultRcId", 0), e = getRcValue("FileLock.data", "").trim(), c.fileLocks = e.split(";"), function initEasyLinkData(t) {
                n.buildArray("Easylink.ElnkRc", t).forEach(function(t) {
                    var s, r = t.MapAddr;
                    if (!is.set(t.Id)) return !1;
                    is.empty(r) || ("0" === t.Mode ? (s = format("https://{0}:{1}", i.URLParse().hostname, r), t.MapAddr = s, t.isPort = !0) : null === r.match(/https?/i) && (r = "https://" + (r = n.htmlDecode(r)), t.MapAddr = r), c.hashEasyLink[t.Id] = t)
                })
            }(t), function initSsoData(t, s) {
                var r, e;
                n.buildArray("WebSsoInfos.webssoinfo", t).forEach(function(t) {
                    if (t.args = n.buildArray("args", t), is.empty(t.args)) return !1;
                    t.args.forEach(function(t) {
                        t.value = n.htmlDecode(t.value)
                    }), t.rcid = Number(t.rcid), c.webSso[t.rcid] = t
                }), r = getRcValue("Sso.enable", 0), e = getRcValue("Sso.data", ""), r && e && ((e = e.split(";")).forEach(function(t) {
                    var s = t.split(":");
                    c.sso || (c.sso = {}), c.sso[s[0]] = {
                        data: s[1]
                    }, is.set(s[2]) && s[2] && (c.sso[s[0]].mark = s[2])
                }), s.hasAutoFillSsoRc = !0)
            }(t, a.data), s.forEach(function(t) {
                var s = parseInt(t.id, 10);
                t.load_balance = Number(t.load_balance), c.hashGroup[s] = t
            }), r.forEach(function(t) {
                var s, r, e;
                r = (t = function initRcData(t) {
                        var s, r = "WEB全网资源(旧版)",
                            e = "L3VPN全网资源(或服务)",
                            o = parseInt(t.id, 10);
                        t.id = o, t.rc_grp_id = parseInt(t.rc_grp_id, 10), t.isBalance = !1, t.addrRangeStates = [], -99 !== o || t.name !== r && "web全网资源(或服务)" !== t.name || (t.name = tr(r));
                        0 === o && t.name === e && (t.name = tr(e));
                        t.rc_logo = "/por/svpnrcico/" + t.rc_logo, t.type = Number(t.type), t.proto = Number(t.proto), t.attr = Number(t.attr), t.enable_disguise = Number(t.enable_disguise), t.svc = t.svc.toLowerCase(), t.svc.substr(0, 3) === R.FTP && (t.svc = R.FTP);
                        t.svc === R.REMOTE_APP && (t.isRemoteApp = !0);
                        t.app_path = n.htmlDecode(t.app_path), s = n.htmlDecode(t.host).replace(/%([^a-fA-F0-9]|$)/g, "%25$1"), t.ips = function buildIpArray(t) {
                            var r, e, o;
                            return (r = t.split(";")).forEach(function(t, s) {
                                o = t.split("~"), (e = {}).host_from = o[0], e.host_to = is.set(o[1]) ? o[1] : "", r[s] = e
                            }), r
                        }(s), t.ports = function buildPortArray(t) {
                            var r, e, o;
                            return (r = t.split(";")).forEach(function(t, s) {
                                o = t.split("~"), (e = {}).port_from = o[0], e.port_to = is.set(o[1]) ? o[1] : o[0], r[s] = e
                            }), r
                        }(t.port), t.addr_link = [], 0 === t.type ? t.addr_link.push(s) : t.host ? t = function rsIpBuild(t) {
                            var s;
                            for (s = 0; s < t.ips.length; s++) t.addrRangeStates[s] = !1, t.ips[s].host_to = t.ips[s].host_to || "", t.ports[s].port_to === t.ports[s].port_from ? (t.ips[s].host_to && (t.ips[s].host_to = "-" + t.ips[s].host_to, t.addrRangeStates[s] = !0), t.addr_link.push(t.ips[s].host_from + t.ips[s].host_to)) : (t.ips[s].host_to && (t.ips[s].host_to = t.ips[s].host_to + ":"), t.addr_link.push(t.ips[s].host_from + ":" + t.ports[s].port_from + "-" + t.ips[s].host_to + t.ports[s].port_to), t.addrRangeStates[s] = !0);
                            return t
                        }(t) : t.addr_link[0] = "";
                        return t.isShowTips = !1, t.state = !1, t.curState = u.SERVICE_INIT_STATE.LOADING, t.msg = tr("正在启动服务，请稍候"), t
                    }(t)).id, e = t.rc_grp_id,
                    function collectData(t, s, r) {
                        -99 === t.id && (r.hasWebAllNetRc = !0);
                        t.isRemoteApp && (r.hasRemoteAppRc = !0);
                        t.type === l.WEB ? r.hasWebRc = !0 : t.type === l.IP ? r.hasL3vpnRc = !0 : t.type === l.APP && (r.hasTcpRc = !0);
                        t.attr & d.USER_BIND && (r.hasUserBindRc = !0);
                        s.load_balance && t.id > h.BALANCE_START && t.id < h.BALANCE_END ? (r.hasLoadBalanceRc = !0, t.isBalance = !0) : t.isBalance = !1
                    }(t, s = c.hashGroup[e], a.data),
                    function bindSsoDataToRc(t) {
                        var s, r, e = t.id;
                        if (s = c.webSso[e]) {
                            if (!(h.SPECIAL_START < e && e < h.SPECIAL_END)) return t.webSso = s, t.ssoType = f.WEB, !0;
                            p.debug("business:res_store", "special rc not support web sso, rc id is: " + e)
                        }
                        if (r = c.sso[e]) return t.sso = r, t.ssoType = f.FILL, !0;
                        return t.ssoType = f.NONE, !1
                    }(t),
                    function isHideRc(t) {
                        return 0 <= [-100, -98, -97].indexOf(t.id) || 1 & parseInt(t.attr, 10)
                    }(t) || (s.rcs || (s.rcs = []), s.rcs.push(t)), c.hashRc[r] = t
            }), o = s.length - 1; 0 <= o; o--) s[o].rcs || s.splice(o, 1);
        c.groups = s, c.rcs = r
    }, s.prototype.getData = function() {
        return c
    }, s.prototype.getRcs = function() {
        return c.rcs
    }, s.prototype.getRcsHash = function() {
        return c.hashRc
    }, s.prototype.resetRcById = function(t, s) {
        c.hashRc[t] = s
    }, s.prototype.getGroups = function() {
        return c.groups
    }, s.prototype.getGroupsHash = function() {
        return c.hashGroup
    }, s.prototype.getRcById = function(t) {
        return c.hashRc[t]
    }, s.prototype.getGroupById = function(t) {
        return c.hashGroup[t]
    }, s.prototype.getRcsByGroupId = function(t) {
        var s = c.hashGroup[t];
        return s && s.rcs ? s.rcs : {}
    }, s.prototype.getEasyLinkRcById = function(t) {
        return c.hashEasyLink[t]
    }, s.prototype.getConfig = function(t, s) {
        return getRcValue(t, s)
    }, s.prototype.updateRcState = function(s) {
        var r = this;
        c.rcs.forEach(function(t) {
            null !== s && t.type === s && r.initEachRcState(t)
        })
    }, s.prototype.initEachRcState = function(t) {
        var s, r, e, o = !0,
            a = u.SERVICE_INIT_STATE.ENABLE,
            i = [],
            n = " \n",
            c = -99 === t.id;
        if (p.assert(!is.empty(t), "rc is empty when init rc state"), s = t.type === l.WEB || t.svc === R.HTTP || t.svc === R.HTTPS, is.Win() ? t.attr & d.USER_BIND && (t.sso && t.sso.data || (o = !1, i.push(tr("该资源启用了单点登录的主从用户名绑定,但未录制单点登录信息,不允许访问,请联系管理员!") + n))) : s || is.Mac && (t.isRemoteApp || t.svc === R.TERMINAL_SERVICE) || i.push(tr("该资源为{0}资源，请从浏览器或其他应用访问", t.svc) + n), is.Linux && t.isRemoteApp && (o = !1, i.push(tr("远程应用资源：当前系统不支持，请使用Windows访问") + n)), t.type === l.IP && (SF.resConfig.info.isFirstL3vpn || (o = !1, i.push(tr("L3VPN无法使用，当前登录了多个VPN，只有首个登录的VPN才可以使用L3VPN") + n)), SF.resConfig.info.isUseIeProxy ? (i.push(tr("该资源无法使用，请检查浏览器是否启用了代理") + n), o = !1) : SFConfig.isExistEC && !SF.resConfig.info.isL3vpnSuccess && (i.push(tr("L3VPN服务启动失败") + n), a = u.SERVICE_INIT_STATE.LOADING)), t.type === l.APP && SFConfig.isExistEC && !SF.resConfig.info.isTcpSuccess && (i.push(tr("TCP服务启动失败") + n), a = u.SERVICE_INIT_STATE.LOADING), t.type === l.WEB || SFConfig.isExistEC || (o = !1, i.push(tr("您尚未安装EC客户端") + n), i.push(tr("管理员已启用免客户端模式") + n)), t.isBalance && !SFConfig.isExistEC && (o = !1, t.type === l.WEB && (o = !1, i.push(tr("您尚未安装EC客户端") + n)), i.push(tr("管理员已启用免客户端模式") + n)), is.empty(i) || o || i.unshift(tr("该资源无法使用，原因如下：") + n), o && is.array(t.addrRangeStates) && o && s)
            for (r = (e = t.addrRangeStates).length - 1; 0 <= r; r--)
                if (e[r]) {
                    i.push(tr("该资源为地址段或端口段资源，请从浏览器或其他应用访问") + n);
                    break
                }
        return o && c && i.push(tr("该资源为web全网资源，请从全网资源地址栏访问") + n), (o && t.svc === R.DNS || t.proto === E.ICMP && t.type === l.IP) && i.push(tr("该资源类型为{0}，不支持点击访问", t.svc) + n), o || this.data.hasDisabledRc || (this.data.hasDisabledRc = !0), o || (a = u.SERVICE_INIT_STATE.DISABLE), t.state = o, t.curState = a, t.msg = i.join(""), t
    }, t.rc = t.rc || {}, t.rc.Store = s, t.rc.store = new s, t.rc.define = t.rc.define || {}, t.rc.define.rcRange = h, t.rc.define.bitType = d, t.rc.define.ssoType = f, t.rc.define.rcType = l, t.rc.define.rcProto = E, t.rc.define.rcService = R
}(SF);