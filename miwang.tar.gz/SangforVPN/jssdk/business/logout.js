! function(e) {
    "use strict";
    var i = SFAPI,
        c = "business:logout",
        a = SFConfig,
        g = SFLOG,
        S = -100,
        y = 1e4,
        f = 30;

    function logout(t, o) {
        t.success = t.success || function() {}, t.error = t.error || function() {}, t.needQuery = !is.bool(t.needQuery) || t.needQuery, SF.setting.setGlobal({
            key: KEY_GLOBAL_LOGOUT_FROM,
            value: a.container
        }, !1), i.logout({
            byServer: t.byServer,
            success: function(e) {
                if (e.code === ERROR_HTTP_MOVE_REQUEST && SFCommon.checkObjAttrExits(e, "data.NextServiceData.link")) return g.info(c, "logout by redirect ,data:" + JSON.stringify(e)), void t.onRedirect(e);
                t.needQuery ? registLoginStatusEvent({
                    isQueryLogout: !1,
                    expected: [a.LOGIN_STATUS.LOGOUT],
                    byServer: t.byServer,
                    onLogout: function(e) {
                        g.info(c, "logout success"), t.success(e), o()
                    }
                }) : t.success(e)
            },
            error: function(e) {
                SF.setting.setGlobal({
                    key: KEY_GLOBAL_LOGOUT_FROM,
                    value: 0
                }, !1), e = e || {}, g.error(c, "logout error", "error is " + e.msg), t.error(e), o()
            }
        })
    }

    function registLoginStatusEvent(t) {
        var o = (t = t || {}).onLogout || function() {},
            n = t.onOnLine || function() {},
            r = t.onOffLine || function() {},
            u = t.onConnecting || function() {},
            s = t.onUnknown || function() {},
            e = t.onSessionChange || function() {};
        t.curStatus = "undefined" == typeof t.curStatus ? S : t.curStatus, t.queryData = t.queryData || {}, t.timeSpan = t.timeSpan || a.COMMON_TIMESPAN, t.preventOnError = t.preventOnError || !1, t.isQueryLogout = !is.bool(t.isQueryLogout) || t.isQueryLogout, t.expected = t.expected || [], t.queryMax = t.queryMax || 0, i.checkLoginStatus({
            preventOnError: t.preventOnError,
            conCount: t.conCount,
            byServer: t.byServer,
            onSessionChange: e,
            isQueryLogout: t.isQueryLogout,
            success: function(e) {
                t.curStatus = e.code, e.code === a.LOGIN_STATUS.LOGOUT ? (SF.setting.setGlobal({
                        key: KEY_GLOBAL_LOGOUT_REASON,
                        value: e.data.logoutReason
                    }, !1), o(e)) : e.code === a.LOGIN_STATUS.ONLINE ? n(e) : e.code === a.LOGIN_STATUS.OFFLINE ? r(e) : e.code === a.LOGIN_STATUS.CONNECTING ? u(e) : s(e), t.queryData = e.data || {},
                    function isQueryContinue(e, t) {
                        var o;
                        if (is.array(e) && 0 < e.length)
                            for (o = 0; o < e.length; o++)
                                if (e[o] === t) return !1;
                        return !0
                    }(t.expected, e.code) && function queryTimer(e) {
                        var t = registLoginStatusEvent;
                        e.queryData && e.queryData.validTime && e.queryData.validTime >= f ? e.timeSpan = y : e.timeSpan = a.COMMON_TIMESPAN;
                        setTimeout(function() {
                            t(e)
                        }, e.timeSpan)
                    }(t)
            },
            error: function(e) {
                g.error(c, "check login status error,", "network request error"), t.error(e)
            }
        })
    }
    e.logout = function(e, t) {
        new SFCommon.BaseAPI(e, t, logout).invoke()
    }, e.registLoginStatusEvent = function(e, t) {
        new SFCommon.BaseAPI(e, t, registLoginStatusEvent).invoke()
    }, e.getLogoutType = function getLogoutType(t) {
        t.success = t.success || function() {}, t.error = t.error || function() {}, SFAPI.getTempData({
            type: a.CACHE_TYPE.ECAGENT,
            key: a.CACHE_PREFIX + a.LOGOUT_FIELD,
            success: function(e) {
                t.success(e), g.info(c, "get logout type success")
            },
            error: function(e) {
                t.error(e), g.debug(c, " get temp data error ", " error is %s ", e.msg)
            }
        })
    }, e.setLogoutType = function setLogoutType(t) {
        SFAPI.setTempData({
            type: a.CACHE_TYPE.ECAGENT,
            key: a.CACHE_PREFIX + a.LOGOUT_FIELD,
            value: JSON.stringify({
                type: t.type
            }),
            flag: 0,
            success: function(e) {
                t.success(e), g.debug(c, "set ecagent cache success , logout type is " + t.type)
            },
            error: function(e) {
                t.error(e), g.debug(c, "set ecagent cache falied")
            }
        })
    }
}(SF);