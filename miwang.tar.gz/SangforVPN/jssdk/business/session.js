! function(e) {
    "use strict";
    var o = SFLOG,
        u = SF.ecConfig,
        l = "module:session";

    function Session() {
        var n, s, i = this;
        i.init = function(n) {
            u.read([u.key.TWFID, u.key.GUID], ["", ""], function(e, t) {
                i.setTWFID(e), i.setGUID(t), n()
            })
        }, i.getTWFID = function() {
            return s = SF.setting.getGlobal(KEY_GLOBAL_TWFID, "")
        }, i.setTWFID = function(e) {
            var t;
            t = (s = e) + SFConfig.EC_MD5_SALT, n = hex_md5(t), o.info(l, "set twfid,token:" + t), SF.setting.setGlobal({
                key: KEY_GLOBAL_TWFID,
                value: s
            }, !1), SF.setting.setGlobal({
                key: KEY_GLOBAL_EC_TOKEN,
                value: n
            }, !1)
        }, i.getGUID = function() {
            return SF.setting.getGlobal(KEY_GLOBAL_EC_GUID, "")
        }, i.setGUID = function(e) {
            SF.setting.setGlobal({
                KEY: KEY_GLOBAL_EC_GUID,
                value: e
            }, !1)
        }, i.getToken = function() {
            return SF.setting.getGlobal(KEY_GLOBAL_EC_TOKEN, "")
        }, i.syncSession = function(e) {
            var t;
            s = SF.setting.getGlobal(KEY_GLOBAL_TWFID, ""), n = SF.setting.getGlobal(KEY_GLOBAL_EC_TOKEN, ""), t = is.set(s) && 6 < s.length ? s.substr(0, 6) : s, e = e || function() {}, SFCommon.isWeb() || (o.info(l, "sync twfid is " + t + ",ecToken is " + n), u.write([{
                key: u.key.TWFID,
                value: s
            }, {
                key: u.key.TOKEN,
                value: n
            }], e))
        }, i.logout = function() {
            window.ecLogout()
        }
    }
    SF.session = SF.session || {}, SF.session.createInstance = function createInstance() {
        return new Session
    }
}(SF);