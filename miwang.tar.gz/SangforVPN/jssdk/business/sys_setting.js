! function(e) {
    "use strict";
    var n = SFAPI,
        o = SFLOG,
        c = "business: sys_setting",
        r = {},
        s = SFConfig,
        i = {};

    function getSettingData(t) {
        Promise.all([function getResourceInfo() {
            return new Promise(function(t, r) {
                n.getResourceInfo({
                    success: function(e) {
                        t(e)
                    },
                    error: function(e) {
                        o.error(c, "Failed to get preference setting", " network request error "), r(e)
                    }
                })
            })
        }(), function getRemoteApp() {
            return new Promise(function(t, r) {
                n.getRemoteApp({
                    success: function(e) {
                        t(e)
                    },
                    error: function(e) {
                        o.error(c, "Failed to get preference setting", " network request error "), r(e)
                    }
                })
            })
        }(), function getScacheData(e) {
            return new Promise(function(t, r) {
                n.getScacheData({
                    svpnID: e.svpnID,
                    success: function(e) {
                        t(e)
                    },
                    error: function(e) {
                        o.error(c, "Failed to get preference setting", " network request error "), r(e)
                    }
                })
            })
        }(t)]).then(function(e) {
            t.success && t.success(e)
        })["catch"](function(e) {
            t.error && t.error(e)
        })
    }

    function getPrefSetting(t) {
        SFAPI.getTempData({
            type: s.CACHE_TYPE.ECAGENT,
            key: s.CACHE_PREFIX + s.CACHE_FOR_LOCAL,
            success: function(e) {
                e && e.data && (r = e.data), n.getPrefSetting({
                    success: function(e) {
                        i = {
                            cacheForLoaclData: r,
                            data: e
                        }, t.success(i)
                    },
                    error: function(e) {
                        o.error(c, "Failed to get preference setting", " network request error "), t.error(e)
                    }
                })
            },
            error: function(e) {
                o.error(c, "Failed to get preference setting", " network request error "), t.error(e)
            }
        })
    }

    function createShortcut(e) {
        SFAPI.createShortcut({
            success: function() {
                SFCommon.tips({
                    msg: tr("添加桌面快捷方式成功")
                }), o.info(c, "success to create shortcut")
            },
            error: function() {
                SFCommon.tips({
                    type: "error",
                    msg: tr("添加桌面快捷方式失败")
                }), o.error(c, "failed to create shortcut", " network request error or api return error ")
            }
        })
    }

    function setSysSetting(t) {
        Promise.all([function setPrefSetting(e) {
            return new Promise(function(t, r) {
                n.setPrefSetting({
                    pref: e.pref,
                    success: function(e) {
                        t(e)
                    },
                    error: function(e) {
                        o.error(c, "Failed to set preference setting", " network request error "), r(e)
                    }
                })
            })
        }(t), function setResourceInfo(e) {
            return new Promise(function(t, r) {
                e.isSaveResource && e.res.length ? n.setResourceInfo({
                    res: e.res,
                    success: function(e) {
                        t(e)
                    },
                    error: function(e) {
                        o.error(c, "Failed to set resource info", " network request error "), r(e)
                    }
                }) : t()
            })
        }(t), function setRemoteApp(e) {
            return new Promise(function(t, r) {
                e.isSaveApplication ? n.setRemoteApp({
                    rmt: e.rmt,
                    success: function(e) {
                        t(e)
                    },
                    error: function(e) {
                        o.error(c, "Failed to set remote App", " network request error "), r(e)
                    }
                }) : t()
            })
        }(t), function setScacheData(e) {
            return new Promise(function(t, r) {
                e.isSaveAccelerate ? n.setScacheData({
                    scache: e.scache,
                    success: function(e) {
                        t(e)
                    },
                    error: function(e) {
                        o.error(c, "Failed to set scache data", " network request error "), r(e)
                    }
                }) : t()
            })
        }(t)]).then(function(e) {
            t.success && t.success(e)
        })["catch"](function(e) {
            t.error && t.error(e)
        })
    }

    function getSelectedPath(t) {
        n.getSelectedPath({
            id: t.id,
            success: function(e) {
                t.success(e)
            },
            error: function(e) {
                t.error(e), o.error(c, "getSelectedPath is fail", " network request error or api return error  ")
            }
        })
    }

    function clearCache(t) {
        n.clearCache({
            success: function(e) {
                t.success(e)
            },
            error: function(e) {
                t.error(e), SFLOG.error(c, "failed to clear cache", "request network error")
            }
        })
    }
    e.sysSetting = {}, e.sysSetting.getPrefSetting = function(e, t) {
        new SFCommon.BaseAPI(e, t, getPrefSetting).invoke()
    }, e.sysSetting.getSettingData = function(e, t) {
        new SFCommon.BaseAPI(e, t, getSettingData).invoke()
    }, e.sysSetting.createShortcut = function(e, t) {
        new SFCommon.BaseAPI(e, t, createShortcut).invoke()
    }, e.sysSetting.setSysSetting = function(e, t) {
        new SFCommon.BaseAPI(e, t, setSysSetting).invoke()
    }, e.sysSetting.getSelectedPath = function(e, t) {
        new SFCommon.BaseAPI(e, t, getSelectedPath).invoke()
    }, e.sysSetting.clearCache = function(e, t) {
        new SFCommon.BaseAPI(e, t, clearCache).invoke()
    }
}(SF);