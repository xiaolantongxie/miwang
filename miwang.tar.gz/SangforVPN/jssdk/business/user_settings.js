! function(e) {
    "use strict";
    var s = SFAPI,
        r = SFLOG,
        c = SFConfig,
        i = "business: user_settings";

    function setAcountPsw(n) {
        var t, o;
        r.info(i, " start modify psw "), s.setAcountPsw({
            newpsw: n.newPsw || "",
            pripsw: n.priPsw || "",
            svpn_req_randcode: n.svpn_req_randcode || "",
            apitype: n.apitype,
            success: function(e) {
                SF.setting.getGlobal(KEY_GLOBAL_LOGIN_CLIENT_TYPE, "") !== c.CLIENT_TYPE.WEB && 1 === e.code && (t = SF.vpnInfo.createInstance(), (o = t.getLoginInfo()).password = n.newPsw, t.saveLoginInfo(o)), n.success(e)
            },
            error: function(e) {
                e.message = SFCommon.getMessage(e.code), r.error(i, "set acount password error", " error is %s ", e.message), n.error(e)
            }
        })
    }

    function getSettingConfig(n) {
        s.getSettingConfig({
            success: function(e) {
                n.success(e)
            },
            error: function(e) {
                n.error(e), r.error(i, "failed to get setting config", " current environment is not container or not have this api ")
            }
        })
    }

    function getAccountData(n) {
        s.getAccountData({
            apitype: n.apitype,
            success: function(e) {
                n.success(e)
            },
            error: function(e) {
                n.error(e), r.error(i, "failed to get account data", " current environment is not container or not have this api ")
            }
        })
    }

    function getpswPolicy(n) {
        s.getpswPolicy({
            success: function(e) {
                n.success(e)
            },
            error: function(e) {
                n.error(e), r.error(i, "failed to get psw policy", " current environment is not container or not have this api ")
            }
        })
    }

    function setAcountTel(n) {
        s.setAcountTel({
            newTel: n.newTel,
            userRandCode: n.userRandCode,
            success: function(e) {
                n.success(e)
            },
            error: function(e) {
                n.error(e), r.error(i, "failed to set account telephone", " current environment is not container or not have this api ")
            }
        })
    }

    function setAcountDesc(n) {
        s.setAcountDesc({
            newNote: n.newNote,
            success: function(e) {
                n.success(e)
            },
            error: function(e) {
                n.error(e), r.error(i, "failed to set account desc", " current environment is not container or not have this api ")
            }
        })
    }

    function setAcountDesc(n) {
        s.setAcountDesc({
            newNote: n.newNote,
            success: function(e) {
                n.success(e)
            },
            error: function(e) {
                n.error(e), r.error(i, "failed to set account desc", " current environment is not container or not have this api ")
            }
        })
    }

    function setPin(n) {
        s.setPin({
            oldPin: n.oldPin,
            newPin: n.newPin,
            success: function(e) {
                n.success(e)
            },
            error: function(e) {
                n.error(e), r.error(i, "failed to set pin code", " current environment is not container or not have this api ")
            }
        })
    }
    e.userSetting = {}, e.userSetting.setAcountPsw = function(e, n) {
        new SFCommon.BaseAPI(e, n, setAcountPsw).invoke()
    }, e.userSetting.getSettingConfig = function(e, n) {
        new SFCommon.BaseAPI(e, n, getSettingConfig).invoke()
    }, e.userSetting.getAccountData = function(e, n) {
        new SFCommon.BaseAPI(e, n, getAccountData).invoke()
    }, e.userSetting.getpswPolicy = function(e, n) {
        new SFCommon.BaseAPI(e, n, getpswPolicy).invoke()
    }, e.userSetting.setAcountTel = function(e, n) {
        new SFCommon.BaseAPI(e, n, setAcountTel).invoke()
    }, e.userSetting.setAcountDesc = function(e, n) {
        new SFCommon.BaseAPI(e, n, setAcountDesc).invoke()
    }, e.userSetting.setPin = function(e, n) {
        new SFCommon.BaseAPI(e, n, setPin).invoke()
    }
}(SF);