! function(e) {
    "use strict";
    var r = SFAPI,
        o = "BUSINESS:getLinkInfo";

    function getLinkInfo(n) {
        r.getLinkInfo({
            success: function(e) {
                n.success(e)
            },
            error: function(e) {
                n.error(e), SFLOG.error(o, " get link Info error ", "maybe network is fail or not have this api")
            }
        })
    }

    function getAccEffect(n) {
        var o = 1e4;
        ! function time() {
            r.getAccEffect({
                success: function(e) {
                    n.success(e), setTimeout(time, o)
                },
                error: function(e) {
                    n.error(e)
                }
            })
        }()
    }

    function openBrower(n) {
        r.invokeContainerAPI({
            name: "ecOpenBrowser",
            params: {
                url: n.url || ""
            },
            success: function(e) {
                n.success(e)
            },
            error: function(e) {
                n.error(e), SFLOG.error(o, " open brower error ", "maybe network is fail or not have this api")
            }
        })
    }
    e.menu = {}, e.menu.getLinkInfo = function(e, n) {
        new SFCommon.BaseAPI(e, n, getLinkInfo).invoke()
    }, e.menu.openBrower = function(e, n) {
        new SFCommon.BaseAPI(e, n, openBrower).invoke()
    }, e.menu.getAccEffect = function(e, n) {
        new SFCommon.BaseAPI(e, n, getAccEffect).invoke()
    }
}(SF);