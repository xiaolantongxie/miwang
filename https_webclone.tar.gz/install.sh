#!/bin/bash
firewall-cmd --add-port=443/tcp --permanent
systemctl restart firewalld
systemctl restart nginx
